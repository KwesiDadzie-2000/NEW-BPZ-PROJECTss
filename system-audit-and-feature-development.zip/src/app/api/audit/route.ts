import { ensureDatabaseReady } from "@/db/bootstrap";
import { desc, eq, inArray } from "drizzle-orm";
import { db } from "@/db";
import { auditLog, clients } from "@/db/schema";
import { authJson, getSessionUser } from "@/lib/auth";

export const dynamic = "force-dynamic";

const LIMIT = 300;

/**
 * Read-only audit trail. Owners review every entity's control history;
 * other users see only their own entity's events. Newest first.
 */
export async function GET(req: Request) {
  await ensureDatabaseReady();
  const user = await getSessionUser(req);
  if (!user) return authJson(req, { ok: false, error: "Unauthorized" }, { status: 401 });

  const isOwner = user.role === "owner";
  let rows;
  if (isOwner) {
    rows = await db.select().from(auditLog).orderBy(desc(auditLog.timestamp)).limit(LIMIT);
  } else {
    if (user.clientId === null || user.clientId === undefined) {
      rows = await db.select().from(auditLog).where(eq(auditLog.clientId, -1)).limit(0);
    } else {
      rows = await db
        .select()
        .from(auditLog)
        .where(inArray(auditLog.clientId, [user.clientId]))
        .orderBy(desc(auditLog.timestamp))
        .limit(LIMIT);
    }
  }
  return Response.json({
    ok: true,
    events: rows.map((r) => ({
      timestamp: r.timestamp,
      username: r.username,
      action: r.action,
      target: r.target,
      details: r.details,
      clientId: r.clientId,
    })),
  });
}

const CLIENT_ACTIONS = new Set(["RESET_ACCOUNTS", "COA_TAILORED", "COA_DELETED", "SCHEDULE_EDITED", "REPORT_PRINTED"]);

/**
 * Records a control event raised by the workspace (e.g. an account reset or a
 * chart-of-accounts tailoring). Tenant-checked: a user can only log events
 * against entities they may write to; the action vocabulary is closed.
 */
export async function POST(req: Request) {
  await ensureDatabaseReady();
  const user = await getSessionUser(req);
  if (!user) return authJson(req, { ok: false, error: "Unauthorized" }, { status: 401 });
  let body: { action?: string; target?: string; details?: string; clientId?: number };
  try {
    body = await req.json();
  } catch {
    return Response.json({ ok: false, error: "Invalid payload." }, { status: 400 });
  }
  const action = String(body.action || "");
  if (!CLIENT_ACTIONS.has(action)) return Response.json({ ok: false, error: "Unknown audit action." }, { status: 400 });
  const clientId = body.clientId == null ? null : Number(body.clientId);
  if (clientId !== null) {
    const firmWide = user.role === "owner" || ((user.role === "partner" || user.role === "manager") && user.clientId == null);
    if (!firmWide && user.clientId !== clientId) return Response.json({ ok: false, error: "Cross-tenant audit write rejected." }, { status: 403 });
    const known = await db.select().from(clients).where(eq(clients.id, clientId));
    if (!known.length) return Response.json({ ok: false, error: "Unknown entity." }, { status: 400 });
  }
  await db.insert(auditLog).values({
    id: crypto.randomUUID(),
    timestamp: new Date().toISOString(),
    userId: user.username,
    username: user.username,
    action,
    target: String(body.target || "").slice(0, 200),
    details: String(body.details || "").slice(0, 2000),
    clientId,
  });
  return Response.json({ ok: true });
}
