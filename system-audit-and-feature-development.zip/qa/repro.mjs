import puppeteer from 'puppeteer';
const BASE = process.env.BASE || 'http://127.0.0.1:3111';
const USER = process.env.USER_ || 'owner';
const PASS = process.env.PASS || 'BpzOwner2026!';

const browser = await puppeteer.launch({ headless: true, args: ['--no-sandbox','--disable-dev-shm-usage'] });
const page = await browser.newPage();
const logs = [];
page.on('console', m => logs.push(`[console.${m.type()}] ${m.text()}`));
page.on('pageerror', e => logs.push(`[pageerror] ${e.message}`));
page.on('requestfailed', r => logs.push(`[reqfail] ${r.url()} ${r.failure()?.errorText}`));
page.on('response', async r => {
  const u = r.url();
  if (u.includes('/api/')) logs.push(`[api] ${r.status()} ${r.request().method()} ${u.replace(BASE,'')}`);
});

await page.goto(BASE + '/', { waitUntil: 'networkidle2', timeout: 60000 });
await new Promise(r => setTimeout(r, 1500));
const hasLogin = await page.$('input[autocomplete="username"]');
console.log('login form present at start:', !!hasLogin);
if (hasLogin) {
  await page.type('input[autocomplete="username"]', USER);
  await page.type('input[autocomplete="current-password"]', PASS);
  await Promise.all([
    page.click('button[type="submit"]'),
  ]);
}
for (const t of [1000, 2000, 4000, 8000]) {
  await new Promise(r => setTimeout(r, t === 1000 ? 1000 : t - 0));
  const state = await page.evaluate(() => ({
    url: location.href,
    loginVisible: !!document.querySelector('input[autocomplete="username"]'),
    heading: document.querySelector('h1')?.innerText?.slice(0,60) || null,
    bodyStart: document.body.innerText.slice(0, 220).replace(/\n+/g,' | '),
    token: (()=>{try{return sessionStorage.getItem('bpz_session_token_v1')}catch(e){return 'ERR:'+e.message}})(),
  }));
  console.log(`--- after ~${t}ms ---`, JSON.stringify(state, null, 1));
  if (t >= 4000) break;
}
console.log('=== LOGS ===');
console.log(logs.slice(-80).join('\n'));
await browser.close();
