import { useState } from 'react';
import type { BusinessPartner, ClientEntity, SalesInvoice } from '../types/accounting';
import { Card, PageHeader, formatGHS, numCls, rowCls, StatusBadge, thCls } from './ui';
import { computeOutputLevies, taxConfigStore } from '../utils/taxConfig';
import { Plus, Printer } from 'lucide-react';
import { currentYear, nextDocNo, uniqueId } from '../utils/ids';

interface SalesSectionProps {
  currentClient: ClientEntity;
  salesInvoices: SalesInvoice[];
  partners?: BusinessPartner[];
  onAddInvoice: (inv: SalesInvoice) => void;
  onPostSalesToJournal: (inv: SalesInvoice) => boolean;
  onIssueCreditNote?: (inv: SalesInvoice) => boolean;
}

export const SalesSection = ({ currentClient, salesInvoices, partners = [], onAddInvoice, onPostSalesToJournal, onIssueCreditNote }: SalesSectionProps) => {
  const [showModal, setShowModal] = useState(false);
  const [customerName, setCustomerName] = useState('');
  const [revenueStream, setRevenueStream] = useState('');
  const [netRevenue, setNetRevenue] = useState(0);
  const [applyCst, setApplyCst] = useState(false);
  const [applyTourism, setApplyTourism] = useState(false);
  const [confirmedCst, setConfirmedCst] = useState(false);
  const [invoiceForPrint, setInvoiceForPrint] = useState<SalesInvoice | null>(null);
  const [feedback, setFeedback] = useState<string | null>(null);
  const levies = computeOutputLevies(netRevenue, { cst: applyCst, tourism: applyTourism });
  // Appointed VAT-withholding agents deduct 7% of the taxable value at source.
  const customerPartner = partners.find((p) => p.name === customerName);
  const customerWht = customerPartner?.isVatWithholdingAgent
    ? Math.round((netRevenue * (customerPartner.vatWithholdingRate ?? taxConfigStore.rate('VAT_WHT')) / 100) * 100) / 100
    : 0;

  const create = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName || !revenueStream || netRevenue <= 0) return setFeedback('Customer, revenue description and a positive taxable value are required.');
    if (applyCst && !confirmedCst) return setFeedback('CST can only be charged by a notified Class 1 electronic communications service provider. Confirm eligibility first.');
    const inv: SalesInvoice = {
      id: uniqueId('INV'), invNo: nextDocNo(`INV-${currentYear()}`, salesInvoices.map((i) => i.invNo)),
      customerName, revenueStream, netRevenue,
      vatOutput: levies.vat + levies.nhil + levies.getfund,
      cstAmount: levies.cst, tourismLevyAmount: levies.tourism,
      vatWithheldByCustomer: customerWht > 0 ? customerWht : undefined,
      totalReceivable: netRevenue + levies.total, paidAmount: 0, status: 'Draft', date: new Date().toISOString().slice(0, 10),
    };
    onAddInvoice(inv); setShowModal(false); setFeedback(`Invoice ${inv.invNo} created. Issue it to post revenue and tax liabilities.`);
  };

  return <div className="space-y-6">
    <PageHeader kicker={`SD · Sales & Billing · ${currentClient.code}`} title="Sales Invoices & Customer Billing" desc="Revenue invoices with effective-dated VAT/NHIL/GETFund and optional sector levies.">
      <button onClick={() => { setFeedback(null); setShowModal(true); }} className="flex gap-1.5 items-center rounded-lg bg-[#082f4f] px-3.5 py-2 text-xs font-bold text-white"><Plus className="h-4 w-4" /> New invoice</button>
    </PageHeader>
    {feedback && <div className={`rounded border p-3 text-xs font-bold ${feedback.includes('required') || feedback.includes('only') ? 'border-rose-300 bg-rose-50 text-rose-900' : 'border-emerald-300 bg-emerald-50 text-emerald-900'}`}>{feedback}</div>}
    <Card title="Sales invoices" sub="Draft invoices are posted to the journal from the issue action; issued invoices then appear as receivables.">
      <div className="overflow-x-auto"><table className="w-full min-w-[920px] text-xs"><thead><tr className="border-b border-sky-200 bg-sky-50/70"><th className={thCls}>Invoice</th><th className={thCls}>Date</th><th className={thCls}>Customer</th><th className={thCls}>Revenue</th><th className={thCls + ' text-right'}>Taxable</th><th className={thCls + ' text-right'}>VAT stack</th><th className={thCls + ' text-right'}>CST</th><th className={thCls + ' text-right'}>Tourism</th><th className={thCls + ' text-right'}>Gross</th><th className={thCls}>Status</th><th className={thCls + ' text-center'}>Action</th></tr></thead><tbody>{salesInvoices.map(inv => <tr key={inv.id} className={rowCls}><td className="px-3 py-2 font-mono font-bold text-[#855b00]">{inv.invNo}</td><td className="px-3 py-2 font-mono">{inv.date}</td><td className="px-3 py-2 font-bold">{inv.customerName}</td><td className="px-3 py-2">{inv.revenueStream}</td><td className={numCls}>{formatGHS(inv.netRevenue)}</td><td className={numCls}>{formatGHS(inv.vatOutput)}</td><td className={numCls}>{formatGHS(inv.cstAmount || 0)}</td><td className={numCls}>{formatGHS(inv.tourismLevyAmount || 0)}</td><td className={numCls}>{formatGHS(inv.vatWithheldByCustomer || 0)}</td><td className={numCls + ' font-bold text-emerald-800'}>{formatGHS(inv.totalReceivable)}</td><td className="px-3 py-2"><StatusBadge status={inv.status} /></td><td className="px-3 py-2 text-center"><div className="flex gap-1 justify-center">{inv.status === 'Draft' && <button onClick={() => { if (!onPostSalesToJournal(inv)) setFeedback('Invoice posting was rejected. Check the period or duplicate document.'); }} className="rounded bg-[#082f4f] px-2 py-1 text-[11px] font-bold text-white">Issue</button>}{(inv.status === 'Open' || inv.status === 'Partial' || inv.status === 'Paid') && onIssueCreditNote && <button onClick={() => { if (!onIssueCreditNote(inv)) setFeedback('Credit note was rejected. Check the period or duplicate document.'); else setFeedback(`Credit note issued for ${inv.invNo} — revenue and taxes reversed.`); }} className="rounded border border-amber-400 bg-amber-50 px-2 py-1 text-[11px] font-bold text-[#855b00]">Credit note</button>}<button onClick={() => setInvoiceForPrint(inv)} className="rounded border border-sky-300 bg-sky-50 px-2 py-1 text-[11px] font-bold text-[#082f4f]"><Printer className="h-3 w-3 inline mr-1"/>Print</button></div></td></tr>)}</tbody></table></div>
    </Card>
    {showModal && <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4"><form onSubmit={create} className="w-full max-w-xl rounded-xl bg-white p-6 shadow-xl space-y-4 text-xs"><h3 className="text-base font-bold text-[#082f4f] border-b border-sky-100 pb-2">Create sales invoice</h3><label className="block font-bold text-[#355875]">Customer{partners.filter(p => p.type === 'Customer').length ? <select value={customerName} onChange={e => setCustomerName(e.target.value)} className="mt-1 block w-full border border-sky-300 p-2 rounded"><option value="">Select customer</option>{partners.filter(p => p.type === 'Customer').map(p => <option key={p.id} value={p.name}>{p.code} · {p.name}</option>)}</select> : <input value={customerName} onChange={e => setCustomerName(e.target.value)} className="mt-1 block w-full border border-sky-300 p-2 rounded"/>}</label><label className="block font-bold text-[#355875]">Revenue description<input value={revenueStream} onChange={e => setRevenueStream(e.target.value)} className="mt-1 block w-full border border-sky-300 p-2 rounded" /></label><label className="block font-bold text-[#355875]">Taxable value (GH¢)<input type="number" min="0" step="0.01" value={netRevenue || ''} onChange={e => setNetRevenue(Number(e.target.value))} className="mt-1 block w-full border border-sky-300 p-2 rounded font-mono" /></label><div className="rounded bg-sky-50 border border-sky-200 p-3 space-y-2"><label className="flex gap-2"><input type="checkbox" checked={applyCst} onChange={e => setApplyCst(e.target.checked)} /> Apply CST (5%)</label>{applyCst && <label className="flex gap-2 text-amber-900"><input type="checkbox" checked={confirmedCst} onChange={e => setConfirmedCst(e.target.checked)} /> I confirm this entity is a GRA-notified Class 1 electronic communications service provider.</label>}{applyCst && <p className="text-[10.5px] text-[#2d4f6d] pl-5">CST is charged on the service value excluding VAT/NHIL/GETFund and is added to the taxable value before VAT and levies (VAT Act 2025 (Act 1151) s.15.3).</p>}<label className="flex gap-2"><input type="checkbox" checked={applyTourism} onChange={e => setApplyTourism(e.target.checked)} /> Apply tourism levy (1%, hospitality — Tourism Act 817)</label></div><div className="rounded bg-slate-50 border border-slate-200 p-3 font-mono space-y-1"><div>VAT/NHIL/GETFund: {formatGHS(levies.vat + levies.nhil + levies.getfund)}</div><div>CST: {formatGHS(levies.cst)} · Tourism: {formatGHS(levies.tourism)}</div><div className="border-t pt-1 font-bold">Invoice total: {formatGHS(netRevenue + levies.total)}</div></div><div className="flex justify-end gap-2 border-t border-sky-100 pt-3"><button type="button" onClick={() => setShowModal(false)} className="px-3 py-2">Cancel</button><button type="submit" className="rounded bg-[#082f4f] px-4 py-2 text-white font-bold">Create</button></div></form></div>}
    {invoiceForPrint && <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4"><div className="w-full max-w-2xl rounded-xl bg-white p-7 shadow-xl text-[#082f4f] space-y-5"><div className="flex justify-between border-b border-sky-200 pb-3"><div><h2 className="text-lg font-black">{currentClient.name}</h2><div className="text-xs">Tax Invoice · {invoiceForPrint.invNo}</div></div><div className="text-right text-xs">Date: {invoiceForPrint.date}<br/>Currency: {currentClient.currency}</div></div><div className="text-sm"><strong>Billed to:</strong> {invoiceForPrint.customerName}</div><table className="w-full text-xs"><tbody><tr><td>Taxable supply</td><td className="text-right">{formatGHS(invoiceForPrint.netRevenue)}</td></tr><tr><td>VAT/NHIL/GETFund</td><td className="text-right">{formatGHS(invoiceForPrint.vatOutput)}</td></tr><tr><td>CST</td><td className="text-right">{formatGHS(invoiceForPrint.cstAmount || 0)}</td></tr><tr><td>Tourism levy</td><td className="text-right">{formatGHS(invoiceForPrint.tourismLevyAmount || 0)}</td></tr>{invoiceForPrint.vatWithheldByCustomer ? <tr><td>VAT withheld at source (receivable from GRA)</td><td className="text-right">{formatGHS(invoiceForPrint.vatWithheldByCustomer)}</td></tr> : null}<tr className="border-t font-bold"><td>Total</td><td className="text-right">{formatGHS(invoiceForPrint.totalReceivable)}</td></tr></tbody></table><div className="flex justify-end gap-2"><button onClick={() => window.print()} className="rounded bg-[#082f4f] text-white px-4 py-2 text-xs font-bold">Print / Save PDF</button><button onClick={() => setInvoiceForPrint(null)} className="px-4 py-2">Close</button></div></div></div>}
  </div>;
};
