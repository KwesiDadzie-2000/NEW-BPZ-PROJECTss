import { useState } from 'react';
import type { ACDOCALine, BankAccount, ClientEntity, UserAccount } from '../types/accounting';
import { Card, PageHeader, formatGHS, thCls, numCls, rowCls } from './ui';
import { Save } from 'lucide-react';
import { buildDisposalEntries } from '../utils/reports';
import { INITIAL_ASSETS } from '../data/accountingSeed';
import { docSuffix, uniqueId } from '../utils/ids';

interface Props {
  currentClient: ClientEntity;
  currentUser: UserAccount;
  isPeriodClosed: boolean;
  lines: ACDOCALine[];
  bankAccounts?: BankAccount[];
  onAddJournalLines: (lines: ACDOCALine[]) => boolean;
  onBankBalanceChange?: (bankId: number, delta: number) => void;
}

interface Asset {
  id: string;
  assetTag: string;
  name: string;
  classCode: string;
  cost: number;
  accumDep: number;
  usefulLife: string;
  location: string;
  acquired: string;
  disposedDate?: string;
  disposalProceeds?: number;
}

const yearsOf = (life: string): number => {
  const m = life.match(/(\d+(?:\.\d+)?)/);
  return m ? Number(m[1]) : 0;
};

const persist = {
  read(clientId: number): Asset[] {
    try {
      const raw = localStorage.getItem(`bpz_assets_${clientId}`);
      return raw ? JSON.parse(raw) : [];
    } catch { return []; }
  },
  write(clientId: number, items: Asset[]) {
    try { localStorage.setItem(`bpz_assets_${clientId}`, JSON.stringify(items)); } catch { /* ignore */ }
  },
};

export const FixedAssetsSection = ({ currentClient, currentUser, isPeriodClosed, lines, bankAccounts = [], onAddJournalLines, onBankBalanceChange }: Props) => {
  // Register falls back to the seeded asset register (demo entity) so the seeded
  // IAS 16 schedule is visible instead of orphaned seed data.
  const [assets, setAssets] = useState<Asset[]>(() => {
    const stored = persist.read(currentClient.id);
    if (stored.length) return stored;
    return currentClient.id === 2
      ? INITIAL_ASSETS.map((a) => ({ ...a, acquired: '2026-01-01' }))
      : [];
  });
  const [assetTag, setAssetTag] = useState('AST-001');
  const [name, setName] = useState('Heavy Haul Truck #1');
  const [classCode, setClassCode] = useState('Vehicles');
  const [cost, setCost] = useState(0);
  const [usefulLife, setUsefulLife] = useState('5 Years');
  const [location, setLocation] = useState('Tarkwa Site');
  const [acquired, setAcquired] = useState(() => new Date().toISOString().slice(0, 10));
  const [feedback, setFeedback] = useState<string | null>(null);
  const [depPeriod, setDepPeriod] = useState(() => new Date().toISOString().slice(0, 7));
  const [disposeTarget, setDisposeTarget] = useState<Asset | null>(null);
  const [disposeDate, setDisposeDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [proceeds, setProceeds] = useState(0);

  const isRestricted = currentUser.status === 'restricted' || currentUser.status === 'suspended';

  const ledgerCost = lines.filter(l => l.clientId === currentClient.id && l.accountNo === '130000').reduce((n, l) => n + Math.round((l.debit - l.credit) * 100), 0) / 100;
  const ledgerDep = lines.filter(l => l.clientId === currentClient.id && l.accountNo === '139000').reduce((n, l) => n + Math.round((l.credit - l.debit) * 100), 0) / 100;
  const ledgerRou = lines.filter(l => l.clientId === currentClient.id && l.accountNo === '150000').reduce((n, l) => n + Math.round((l.debit - l.credit) * 100), 0) / 100;

  const handleAddAsset = (e: React.FormEvent) => {
    e.preventDefault();
    setFeedback(null);
    if (isPeriodClosed) return setFeedback('Posting blocked. Period is closed.');
    if (isRestricted) return setFeedback('Action blocked. Your account has been restricted.');
    if (!assetTag.trim() || !name.trim() || cost <= 0) return setFeedback('Asset tag, name and positive cost are required.');
    if (currentUser.makerLimit > 0 && cost > currentUser.makerLimit) return setFeedback(`Cost exceeds maker limit ₵${formatGHS(currentUser.makerLimit)}; request approval first.`);

    const period = acquired.slice(0, 7);
    const docNo = `AST-${period}-${docSuffix()}`;
    const lines2Post: ACDOCALine[] = [
      { id: `${uniqueId('JL-FA')}-1`, docNo, period, date: acquired, module: 'FI-AA', docType: 'STAT', accountNo: '130000', accountName: `PPE - ${name}`, costCenter: 'CC-OPS', debit: cost, credit: 0, currency: currentClient.currency, description: `Acquisition of ${assetTag}`, createdBy: currentUser.username, clientId: currentClient.id },
      { id: `${uniqueId('JL-FA')}-2`, docNo, period, date: acquired, module: 'FI-AA', docType: 'STAT', accountNo: '100000', accountName: 'Cash at Bank (Operating)', costCenter: 'CC-OPS', debit: 0, credit: cost, currency: currentClient.currency, description: `Cash payment for ${assetTag}`, createdBy: currentUser.username, clientId: currentClient.id },
    ];
    const ok = onAddJournalLines(lines2Post);
    if (!ok) return setFeedback('Asset record not saved. Check the period, balance and posted lines.');

    // The acquisition credits the operating bank GL — reduce the matching treasury record.
    const funding = bankAccounts.find((b) => b.glAccount === '100000') || bankAccounts.find((b) => b.kind !== 'cash');
    if (funding && onBankBalanceChange) onBankBalanceChange(funding.id, -Math.round(cost * 100) / 100);

    const newAssets = [...assets, { id: uniqueId('ID'), assetTag, name, classCode, cost, accumDep: 0, usefulLife, location, acquired }];
    setAssets(newAssets);
    persist.write(currentClient.id, newAssets);
    setFeedback(`Asset ${assetTag} registered. Cost posted to ACDOCA.`);
  };

  // Monthly straight-line depreciation run: Dr 600000 / Cr 139000 per active asset.
  const handleRunDepreciation = () => {
    if (isPeriodClosed) return setFeedback('Posting blocked. Period is closed.');
    if (isRestricted) return setFeedback('Action blocked. Your account has been restricted.');
    const active = assets.filter((a) => !a.disposedDate);
    if (!active.length) return setFeedback('No active assets to depreciate.');
    let posted = 0;
    let skipped = 0;
    let totalDep = 0;
    const updated = assets.map((a) => {
      if (a.disposedDate) return a;
      const years = yearsOf(a.usefulLife);
      if (years <= 0 || a.cost <= 0 || a.accumDep >= a.cost) { skipped += 1; return a; }
      const monthly = Math.round((a.cost / (years * 12)) * 100) / 100;
      if (monthly <= 0) { skipped += 1; return a; }
      const docNo = `DEP-${a.assetTag}-${depPeriod}`;
      if (lines.some((l) => l.clientId === currentClient.id && l.docNo === docNo)) { skipped += 1; return a; }
      const ok = onAddJournalLines([
        { id: `${uniqueId('JL-DEP')}-${a.id}-1`, docNo, period: depPeriod, date: `${depPeriod}-28`, module: 'FI-AA', docType: 'DEP', accountNo: '600000', accountName: `Depreciation — ${a.name}`, costCenter: 'CC-OPS', debit: monthly, credit: 0, currency: currentClient.currency, description: `Monthly depreciation ${a.assetTag} (${depPeriod})`, createdBy: currentUser.username, clientId: currentClient.id },
        { id: `${uniqueId('JL-DEP')}-${a.id}-2`, docNo, period: depPeriod, date: `${depPeriod}-28`, module: 'FI-AA', docType: 'DEP', accountNo: '139000', accountName: 'Accumulated Depreciation — PPE', costCenter: 'CC-OPS', debit: 0, credit: monthly, currency: currentClient.currency, description: `Accumulated depreciation ${a.assetTag} (${depPeriod})`, createdBy: currentUser.username, clientId: currentClient.id },
      ]);
      if (!ok) { skipped += 1; return a; }
      posted += 1;
      totalDep += monthly;
      return { ...a, accumDep: Math.round((a.accumDep + monthly) * 100) / 100 };
    });
    setAssets(updated);
    persist.write(currentClient.id, updated);
    setFeedback(posted > 0
      ? `Depreciation run for ${depPeriod}: ${posted} asset(s) posted, ${formatGHS(totalDep)} charged to 600000.${skipped ? ` ${skipped} skipped (fully depreciated or already posted).` : ''}`
      : 'No depreciation posted — assets may be fully depreciated or already posted for this period.');
  };

  // Disposal: Dr bank (proceeds) + Dr 139000 (accum. dep. reversal) / Cr 130000 (cost) + gain/loss.
  const handleDispose = (e: React.FormEvent) => {
    e.preventDefault();
    if (!disposeTarget) return;
    if (isPeriodClosed) return setFeedback('Posting blocked. Period is closed.');
    if (isRestricted) return setFeedback('Action blocked. Your account has been restricted.');
    const nbv = Math.round((disposeTarget.cost - disposeTarget.accumDep) * 100) / 100;
    const gain = Math.round((proceeds - nbv) * 100) / 100;
    const entries = buildDisposalEntries(disposeTarget, proceeds, disposeDate, currentClient.currency, currentClient.id, currentUser.username);
    const ok = onAddJournalLines(entries);
    if (!ok) return setFeedback('Disposal was rejected. Check the period, balance and duplicate document number.');
    const funding = bankAccounts.find((b) => b.glAccount === '100000') || bankAccounts.find((b) => b.kind !== 'cash');
    if (funding && onBankBalanceChange && proceeds > 0) onBankBalanceChange(funding.id, proceeds);
    const updated = assets.map((a) => (a.id === disposeTarget.id ? { ...a, disposedDate: disposeDate, disposalProceeds: proceeds } : a));
    setAssets(updated);
    persist.write(currentClient.id, updated);
    setDisposeTarget(null);
    setFeedback(`Asset ${disposeTarget.assetTag} disposed. ${gain >= 0 ? `Gain ${formatGHS(gain)}` : `Loss ${formatGHS(Math.abs(gain))}`} posted.`);
  };

  return (
    <div className="space-y-6">
      <PageHeader
        kicker={`AA · Fixed Assets Register · ${currentClient.code}`}
        title="Fixed Assets & Depreciation (IAS 16)"
        desc="Register an asset, track carrying value, and reconcile to general ledger 130000 / 139000 / 150000."
      />
      {feedback && <div className={`text-xs rounded-lg p-3 ${feedback.startsWith('Asset') ? 'bg-emerald-50 text-emerald-900 border border-emerald-300' : 'bg-rose-50 text-rose-900 border border-rose-300'}`}>{feedback}</div>}

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <Card title="130000 PPE - Cost">
          <div className="font-mono text-2xl font-black text-[#082f4f]">₵{formatGHS(ledgerCost)}</div>
        </Card>
        <Card title="139000 Accumulated Depreciation">
          <div className="font-mono text-2xl font-black text-rose-700">₵{formatGHS(ledgerDep)}</div>
        </Card>
        <Card title="150000 Right-of-Use Assets">
          <div className="font-mono text-2xl font-black text-[#006f98]">₵{formatGHS(ledgerRou)}</div>
        </Card>
      </div>

      <Card title="Register a new fixed asset" sub="Dr 130000 / Cr 100000. Depreciation must be run separately.">
        <form onSubmit={handleAddAsset} className="grid grid-cols-1 sm:grid-cols-6 gap-3 text-xs">
          <input type="date" value={acquired} onChange={e => setAcquired(e.target.value)} className="rounded border border-sky-300 p-2" />
          <input value={assetTag} onChange={e => setAssetTag(e.target.value)} placeholder="Asset Tag" className="rounded border border-sky-300 p-2" required />
          <input value={name} onChange={e => setName(e.target.value)} placeholder="Description" className="rounded border border-sky-300 p-2 sm:col-span-2" required />
          <select value={classCode} onChange={e => setClassCode(e.target.value)} className="rounded border border-sky-300 p-2 font-semibold">
            <option>Heavy Plant</option><option>Vehicles</option><option>IT Equipment</option><option>Office Equipment</option><option>Buildings</option>
          </select>
          <input value={usefulLife} onChange={e => setUsefulLife(e.target.value)} placeholder="Useful Life" className="rounded border border-sky-300 p-2" required />
          <input value={location} onChange={e => setLocation(e.target.value)} placeholder="Location" className="rounded border border-sky-300 p-2" required />
          <input type="number" min="0" step="0.01" value={cost || ''} onChange={e => setCost(Number(e.target.value))} placeholder="Cost" className="rounded border border-sky-300 p-2 font-mono" required />
          <button type="submit" disabled={isPeriodClosed || isRestricted} className="rounded bg-[#082f4f] text-white font-bold text-xs py-2 disabled:opacity-40 disabled:cursor-not-allowed flex items-center justify-center gap-1.5 sm:col-span-2">
            <Save className="h-3.5 w-3.5" /> Register asset
          </button>
        </form>
      </Card>

      <Card title="Monthly depreciation run (IAS 16)" sub="Straight-line: Dr 600000 / Cr 139000 per active asset for the selected period">
        <div className="flex flex-wrap items-end gap-3 text-xs">
          <label className="font-bold text-[#355875]">Depreciation period
            <input type="month" value={depPeriod} onChange={(e) => setDepPeriod(e.target.value)} className="block mt-1 rounded border border-sky-300 p-2 font-mono" />
          </label>
          <button onClick={handleRunDepreciation} disabled={isPeriodClosed || isRestricted} className="rounded bg-[#082f4f] text-white font-bold px-4 py-2 disabled:opacity-40 disabled:cursor-not-allowed flex items-center gap-1.5">
            <Save className="h-3.5 w-3.5" /> Run depreciation
          </button>
          <span className="text-[11px] text-[#2d4f6d]">Each asset depreciates once per period; fully depreciated assets are skipped.</span>
        </div>
      </Card>

      <Card title={`Asset register (${assets.length})`} sub="Newly added assets. Depreciation is not yet scheduled.">
        {assets.length === 0 ? (
          <p className="text-center text-[#355875] py-6">No assets registered in this workspace yet.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[700px] text-xs">
              <thead>
                <tr className="border-b border-sky-200 bg-sky-50/70">
                  <th className={thCls}>Tag</th>
                  <th className={thCls}>Asset</th>
                  <th className={thCls}>Class</th>
                  <th className={thCls}>Useful Life</th>
                  <th className={thCls}>Location</th>
                  <th className={thCls + ' text-right'}>Cost (₵)</th>
                  <th className={thCls + ' text-right'}>Accum. Dep. (₵)</th>
                  <th className={thCls + ' text-right'}>NBV (₵)</th>
                  <th className={thCls}>Status</th>
                  <th className={thCls + ' text-center'}>Action</th>
                </tr>
              </thead>
              <tbody>
                {assets.map(a => (
                  <tr key={a.id} className={rowCls}>
                    <td className="px-3 py-2 font-mono font-bold text-[#855b00]">{a.assetTag}</td>
                    <td className="px-3 py-2 font-bold text-[#082f4f]">{a.name}</td>
                    <td className="px-3 py-2 text-[#2d4f6d]">{a.classCode}</td>
                    <td className="px-3 py-2 text-[#2d4f6d]">{a.usefulLife}</td>
                    <td className="px-3 py-2 text-[#355875]">{a.location}</td>
                    <td className={numCls}>{formatGHS(a.cost)}</td>
                    <td className={numCls + ' text-rose-700'}>({formatGHS(a.accumDep)})</td>
                    <td className={numCls + ' font-black text-emerald-800'}>{formatGHS(a.cost - a.accumDep)}</td>
                    <td className="px-3 py-2">{a.disposedDate
                      ? <span className="rounded bg-slate-200 text-slate-600 px-2 py-0.5 text-[10.5px] font-bold">Disposed {a.disposedDate}</span>
                      : <span className="rounded bg-emerald-100 text-emerald-800 px-2 py-0.5 text-[10.5px] font-bold">Active</span>}</td>
                    <td className="px-3 py-2 text-center">{!a.disposedDate && (
                      <button onClick={() => { setDisposeTarget(a); setProceeds(Math.round((a.cost - a.accumDep) * 100) / 100); setDisposeDate(new Date().toISOString().slice(0, 10)); }} className="rounded border border-rose-300 bg-rose-50 px-2 py-1 text-[11px] font-bold text-rose-800 hover:bg-rose-100">Dispose</button>
                    )}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      {/* Disposal modal */}
      {disposeTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <form onSubmit={handleDispose} className="w-full max-w-md rounded-xl border border-sky-300 bg-white p-6 shadow-xl space-y-4 text-xs">
            <h3 className="text-base font-bold text-[#082f4f] border-b border-sky-100 pb-2">Dispose asset {disposeTarget.assetTag}</h3>
            <div className="rounded bg-sky-50 border border-sky-200 p-3 font-mono space-y-1">
              <div className="flex justify-between"><span>Cost:</span><span>{formatGHS(disposeTarget.cost)}</span></div>
              <div className="flex justify-between"><span>Accumulated depreciation:</span><span>({formatGHS(disposeTarget.accumDep)})</span></div>
              <div className="flex justify-between border-t border-sky-200 pt-1 font-bold"><span>Net book value:</span><span>{formatGHS(disposeTarget.cost - disposeTarget.accumDep)}</span></div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <label className="block font-bold text-[#0a253e]">Disposal date
                <input type="date" value={disposeDate} onChange={(e) => setDisposeDate(e.target.value)} className="mt-1 w-full rounded border border-sky-300 px-3 py-2" required />
              </label>
              <label className="block font-bold text-[#0a253e]">Proceeds
                <input type="number" min="0" step="0.01" value={proceeds} onChange={(e) => setProceeds(Number(e.target.value))} className="mt-1 w-full rounded border border-sky-300 px-3 py-2 font-mono" required />
              </label>
            </div>
            <p className="text-[11px] text-[#2d4f6d]">Posts Dr bank (proceeds) + Dr 139000 (accumulated depreciation reversal) / Cr 130000 (cost), with the gain or loss (492000 / 698000) balancing the entry.</p>
            <div className="flex justify-end gap-2 pt-2 border-t border-sky-100">
              <button type="button" onClick={() => setDisposeTarget(null)} className="rounded px-3 py-1.5 font-semibold text-[#2d4f6d]">Cancel</button>
              <button type="submit" className="rounded bg-rose-700 px-4 py-1.5 font-bold text-white">Post disposal</button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
