import assert from 'node:assert/strict';
import test from 'node:test';

import {
  INITIAL_ACDOCA_LINES,
  INITIAL_CHART_OF_ACCOUNTS,
  INITIAL_CLIENTS,
  INITIAL_PURCHASE_ORDERS,
  INITIAL_SALES_INVOICES,
} from '../src/data/accountingSeed';
import { GROUP_MEMBERS } from '../src/data/initialData';
import { aggregateTrialBalance, buildCostCentreReport, buildCreditNoteEntries, buildDebitNoteEntries, buildDisposalEntries } from '../src/utils/reports';
import { isBalancedDocument } from '../src/utils/transactionMath';

/* ---------- Fixed asset disposal (IAS 16 derecognition) ---------- */

test('asset disposal journal balances with a gain', () => {
  const entries = buildDisposalEntries(
    { assetTag: 'AST-001', name: 'Haul Truck', cost: 100000, accumDep: 20000 },
    90000, '2026-03-20', 'GHS', 2, 'demo'
  );
  assert.equal(isBalancedDocument(entries), true, 'disposal with gain balances');
  const gain = entries.find((l) => l.accountNo === '492000');
  assert.equal(gain?.credit, 10000, 'gain = proceeds 90,000 - NBV 80,000');
});

test('asset disposal journal balances with a loss', () => {
  const entries = buildDisposalEntries(
    { assetTag: 'AST-002', name: 'Drill Rig', cost: 100000, accumDep: 20000 },
    50000, '2026-03-20', 'GHS', 2, 'demo'
  );
  assert.equal(isBalancedDocument(entries), true, 'disposal with loss balances');
  const loss = entries.find((l) => l.accountNo === '698000');
  assert.equal(loss?.debit, 30000, 'loss = NBV 80,000 - proceeds 50,000');
});

test('straight-line depreciation is cost over useful life', () => {
  const cost = 120000;
  const years = 10;
  const monthly = Math.round((cost / (years * 12)) * 100) / 100;
  assert.equal(monthly, 1000);
});

/* ---------- Credit notes (sales returns) ---------- */

test('credit note journal reverses a seeded invoice and balances', () => {
  const inv = INITIAL_SALES_INVOICES.find((i) => i.invNo === 'INV-2026-001')!;
  const entries = buildCreditNoteEntries(inv, '2026-03-25', 'GHS', 2, 'demo');
  assert.equal(isBalancedDocument(entries), true, 'credit note balances');
  const dr = entries.reduce((n, l) => n + l.debit, 0);
  assert.equal(dr, inv.totalReceivable, 'debits equal the reversed receivable');
  assert.ok(entries.some((l) => l.accountNo === '400000' && l.debit === inv.netRevenue), 'revenue reversed');
  assert.ok(entries.some((l) => l.accountNo === '220000' && l.debit === inv.vatOutput), 'output VAT reversed');
});

/* ---------- Vendor debit notes (purchase returns) ---------- */

test('debit note journal reverses a purchase order and balances', () => {
  const po = INITIAL_PURCHASE_ORDERS.find((p) => p.poNo === 'PO-2026-088')!;
  const entries = buildDebitNoteEntries(po, '2026-03-26', 'GHS', 2, 'demo');
  assert.equal(isBalancedDocument(entries), true, 'debit note balances');
  assert.ok(entries.some((l) => l.accountNo === '200000' && l.debit === po.totalAmount), 'payable reversed');
  assert.ok(entries.some((l) => l.accountNo === po.glAccount && l.credit === po.netAmount), 'GL charge reversed');
  assert.ok(entries.some((l) => l.accountNo === '125000' && l.credit === po.vatRecoverable), 'input VAT reversed');
  // Non-VAT vendor PO: no VAT line.
  const nonVat = buildDebitNoteEntries({ ...po, vatRecoverable: 0, totalAmount: po.netAmount! }, '2026-03-26', 'GHS', 2, 'demo');
  assert.equal(nonVat.some((l) => l.accountNo === '125000'), false, 'no VAT line for non-VAT bills');
  assert.equal(isBalancedDocument(nonVat), true);
});

/* ---------- Cost-centre P&L ---------- */

test('cost-centre report reconciles to entity profit (residual zero)', () => {
  const lines2 = INITIAL_ACDOCA_LINES.filter((l) => l.clientId === 2);
  const report = buildCostCentreReport(lines2, INITIAL_CHART_OF_ACCOUNTS, '2026-01-01', '2026-03-31');
  assert.equal(report.residual, 0, 'cost-centre nets reconcile to entity profit');
  assert.equal(report.totalNet, report.profit);
  assert.ok(report.rows.length > 0, 'cost centres present');
  assert.ok(report.rows.some((r) => r.code === 'CC-SLS' && r.income === 375000), 'sales centre carries the revenue');
});

/* ---------- Computed consolidated trial balance ---------- */

test('consolidated group trial balance aggregates each entity’s own journal and balances', () => {
  const memberIds = new Set(GROUP_MEMBERS.map((m) => m.clientId));
  const groupLines = INITIAL_ACDOCA_LINES.filter((l) => memberIds.has(l.clientId));
  const consolidated = aggregateTrialBalance(groupLines, INITIAL_CHART_OF_ACCOUNTS);
  const dr = consolidated.reduce((n, r) => n + r.dr, 0) / 100;
  const cr = consolidated.reduce((n, r) => n + r.cr, 0) / 100;
  assert.equal(dr, cr, 'consolidated trial balance balances');
  // Only the demo entity (client 2) has posted seed lines; others contribute zero.
  for (const client of INITIAL_CLIENTS) {
    const cl = INITIAL_ACDOCA_LINES.filter((l) => l.clientId === client.id);
    const ownDr = cl.reduce((n, l) => n + l.debit, 0);
    const ownCr = cl.reduce((n, l) => n + l.credit, 0);
    assert.equal(ownDr, ownCr, `${client.code} owns a balanced journal`);
  }
});

/* ---------- Statement of changes in equity arithmetic ---------- */

test('IAS 1 equity statement reconciles for the seeded entity', () => {
  const lines2 = INITIAL_ACDOCA_LINES.filter((l) => l.clientId === 2);
  const plResult = (ls: typeof lines2) => aggregateTrialBalance(ls, INITIAL_CHART_OF_ACCOUNTS)
    .filter((r) => r.type === 'Income' || r.type === 'Expense')
    .reduce((n, r) => n - (r.dr - r.cr), 0) / 100;
  const profit = plResult(lines2);
  assert.equal(profit, 259000, 'seeded quarter profit');
  // No equity-account postings in the seed: opening = closing = profit in retained earnings.
  const eqRows = aggregateTrialBalance(lines2, INITIAL_CHART_OF_ACCOUNTS)
    .filter((r) => r.type === 'Equity');
  assert.equal(eqRows.length, 0, 'no direct equity postings in seed');
  assert.equal(profit - 0 - 0, 259000, 'equity movement equals profit (residual zero)');
});
