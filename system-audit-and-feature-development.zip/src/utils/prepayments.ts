import type { PrepaymentRecord, PrepaymentScheduleLine } from '../types/accounting';

export const round2 = (n: number) => Math.round((n + Number.EPSILON) * 100) / 100;
const toCents = (n: number) => Math.round(n * 100);
const fromCents = (n: number) => Math.round(n) / 100;

export const addMonthsToPeriod = (period: string, offset: number): string => {
  const [year, month] = period.split('-').map(Number);
  const d = new Date(Date.UTC(year, month - 1 + offset, 1));
  return `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, '0')}`;
};

export const periodOfDate = (date: string) => date.slice(0, 7);

export const lastDayOfPeriod = (period: string): string => {
  const [year, month] = period.split('-').map(Number);
  const d = new Date(Date.UTC(year, month, 0));
  return d.toISOString().slice(0, 10);
};

export const addDays = (date: string, days: number): string => {
  const d = new Date(`${date}T00:00:00.000Z`);
  d.setUTCDate(d.getUTCDate() + days);
  return d.toISOString().slice(0, 10);
};

export const addMonthsToDate = (date: string, months: number): string => {
  const d = new Date(`${date}T00:00:00.000Z`);
  const day = d.getUTCDate();
  d.setUTCDate(1);
  d.setUTCMonth(d.getUTCMonth() + months);
  const last = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth() + 1, 0)).getUTCDate();
  d.setUTCDate(Math.min(day, last));
  return d.toISOString().slice(0, 10);
};

export const benefitEndDate = (benefitStart: string, termMonths: number): string =>
  addDays(addMonthsToDate(benefitStart, termMonths), -1);

const daysBetweenInclusive = (from: string, to: string): number => {
  const a = new Date(`${from}T00:00:00.000Z`).getTime();
  const b = new Date(`${to}T00:00:00.000Z`).getTime();
  return Math.max(0, Math.floor((b - a) / 86400000) + 1);
};

export interface BuildScheduleInput {
  prepaymentId: string;
  clientId: number;
  totalAmount: number;
  benefitStart: string;
  termMonths: number;
  method: PrepaymentRecord['method'];
}

export function buildPrepaymentSchedule(input: BuildScheduleInput): PrepaymentScheduleLine[] {
  const totalAmount = round2(input.totalAmount);
  if (!Number.isFinite(totalAmount) || totalAmount <= 0) throw new Error('Prepayment amount must be greater than zero.');
  if (!Number.isInteger(input.termMonths) || input.termMonths < 1 || input.termMonths > 240) {
    throw new Error('Benefit term must be between 1 and 240 months.');
  }
  if (!/^\d{4}-\d{2}-\d{2}$/.test(input.benefitStart)) throw new Error('Benefit start date is invalid.');

  const startPeriod = periodOfDate(input.benefitStart);
  const endDate = benefitEndDate(input.benefitStart, input.termMonths);
  const totalCents = toCents(totalAmount);
  const lines: PrepaymentScheduleLine[] = [];

  if (input.method === 'straight_line') {
    const base = Math.floor(totalCents / input.termMonths);
    let opening = totalCents;
    for (let i = 0; i < input.termMonths; i += 1) {
      const period = addMonthsToPeriod(startPeriod, i);
      const cents = i === input.termMonths - 1 ? opening : base;
      const closing = opening - cents;
      lines.push({
        id: `${input.prepaymentId}-S${String(i + 1).padStart(3, '0')}`,
        prepaymentId: input.prepaymentId,
        clientId: input.clientId,
        sequence: i + 1,
        period,
        recognitionDate: i === input.termMonths - 1 ? endDate : lastDayOfPeriod(period),
        openingBalance: fromCents(opening),
        amount: fromCents(cents),
        closingBalance: fromCents(closing),
        status: 'scheduled',
      });
      opening = closing;
    }
    return lines;
  }

  const totalDays = daysBetweenInclusive(input.benefitStart, endDate);
  let opening = totalCents;
  let allocated = 0;
  for (let i = 0; i < input.termMonths; i += 1) {
    const period = addMonthsToPeriod(startPeriod, i);
    const monthStart = i === 0 ? input.benefitStart : `${period}-01`;
    const monthEnd = i === input.termMonths - 1 ? endDate : lastDayOfPeriod(period);
    const days = daysBetweenInclusive(monthStart, monthEnd);
    const cents = i === input.termMonths - 1
      ? opening
      : Math.round((totalCents * days) / totalDays);
    allocated += cents;
    const closing = opening - cents;
    lines.push({
      id: `${input.prepaymentId}-S${String(i + 1).padStart(3, '0')}`,
      prepaymentId: input.prepaymentId,
      clientId: input.clientId,
      sequence: i + 1,
      period,
      recognitionDate: monthEnd,
      openingBalance: fromCents(opening),
      amount: fromCents(cents),
      closingBalance: fromCents(closing),
      status: 'scheduled',
    });
    opening = closing;
  }
  return lines;
}

export function summarizePrepayment(record: PrepaymentRecord, schedule: PrepaymentScheduleLine[], runPeriod: string) {
  const recognized = round2(schedule.filter(l => l.status === 'posted').reduce((n, l) => n + l.amount, 0));
  const scheduledTotal = round2(schedule.reduce((n, l) => n + l.amount, 0));
  const unrecognized = round2(record.totalAmount - recognized);
  const dueLines = schedule.filter(l => l.status === 'scheduled' && l.period <= runPeriod);
  const overdueLines = schedule.filter(l => l.status === 'scheduled' && l.period < runPeriod);
  const dueAmount = round2(dueLines.reduce((n, l) => n + l.amount, 0));
  return {
    recognized,
    unrecognized,
    scheduledTotal,
    scheduleVariance: round2(scheduledTotal - record.totalAmount),
    dueLines,
    overdueLines,
    dueAmount,
    postedCount: schedule.filter(l => l.status === 'posted').length,
    totalCount: schedule.length,
    percentRecognized: record.totalAmount > 0 ? Math.round((recognized / record.totalAmount) * 1000) / 10 : 0,
    nextLine: schedule.find(l => l.status === 'scheduled'),
  };
}

export function validateSchedule(record: PrepaymentRecord, schedule: PrepaymentScheduleLine[]): string | null {
  if (!schedule.length) return 'Schedule has no recognition lines.';
  const total = round2(schedule.reduce((n, l) => n + l.amount, 0));
  if (Math.abs(total - record.totalAmount) > 0.009) {
    return `Schedule total ${total.toFixed(2)} does not equal prepayment amount ${record.totalAmount.toFixed(2)}.`;
  }
  if (schedule.some(l => !Number.isFinite(l.amount) || l.amount < 0)) return 'Schedule contains an invalid amount.';
  const sequences = schedule.map(l => l.sequence).sort((a, b) => a - b);
  if (sequences.some((seq, idx) => seq !== idx + 1)) return 'Schedule sequence is incomplete or duplicated.';
  return null;
}
