import assert from 'node:assert/strict';
import test from 'node:test';

import { INITIAL_ACDOCA_LINES, INITIAL_CHART_OF_ACCOUNTS, INITIAL_CLIENTS, INITIAL_BUSINESS_PARTNERS } from '../src/data/accountingSeed';
import {
  buildGeneralLedger,
  balanceLabel,
  validateDocumentLines,
  deriveWhtDeductions,
  deriveWhtCredits,
  deriveVatOutput,
  deriveVatInput,
  mergeScheduleRows,
  scheduleTotals,
  splitVatStack,
  periodRemitted,
  liabilityBalanceThrough,
} from '../src/utils/ledger';
import { buildReportHtml } from '../src/utils/printReport';
import { toPrintEntity } from '../src/utils/printEntity';
import type { ACDOCALine, TaxScheduleEntry } from '../src/types/accounting';

const client2 = INITIAL_CLIENTS.find((c) => c.id === 2)!;
const fmt = (n: number) => n.toFixed(2);
const rates = { vat: 15, nhil: 2.5, getfund: 2.5, covid: 0 };

const mk = (over: Partial<ACDOCALine>): ACDOCALine => ({
  id: `T-${Math.random().toString(36).slice(2)}`, docNo: 'DOC-1', period: '2026-03', date: '2026-03-10', module: 'FI', docType: 'JE',
  accountNo: '600000', accountName: 'Operating Expenses', debit: 0, credit: 0, currency: 'GHS', description: 'test', createdBy: 'tester', clientId: 2,
  ...over,
});

test('general ledger: every account closes at opening + debits − credits in its normal direction', () => {
  const ledgers = buildGeneralLedger(INITIAL_ACDOCA_LINES, INITIAL_CHART_OF_ACCOUNTS, client2.id, '2026-01-01', '2026-12-31');
  assert.ok(ledgers.length > 0, 'seeded entity has ledger accounts');
  for (const l of ledgers) {
    const sign = l.type === 'Asset' || l.type === 'Expense' ? 1 : -1;
    const expected = Math.round((l.opening + sign * (l.totalDebit - l.totalCredit)) * 100) / 100;
    assert.equal(l.closing, expected, `${l.accountNo} closing balance`);
    // Running balance of the last entry equals the closing balance.
    if (l.entries.length) assert.equal(l.entries[l.entries.length - 1].balance, l.closing);
  }
  // Sum of all closing balances in debit/credit terms nets to zero (double entry).
  const net = ledgers.reduce((n, l) => n + (l.type === 'Asset' || l.type === 'Expense' ? l.closing : -l.closing), 0);
  assert.ok(Math.abs(net) < 0.01, `ledger nets to zero (got ${net})`);
});

test('general ledger: opening balance carries prior-period movement forward', () => {
  const lines = [
    mk({ docNo: 'A', date: '2026-01-05', period: '2026-01', accountNo: '100000', debit: 1000 }),
    mk({ docNo: 'A', date: '2026-01-05', period: '2026-01', accountNo: '300000', credit: 1000 }),
    mk({ docNo: 'B', date: '2026-02-05', period: '2026-02', accountNo: '100000', credit: 250 }),
    mk({ docNo: 'B', date: '2026-02-05', period: '2026-02', accountNo: '600000', debit: 250 }),
  ];
  const [cash] = buildGeneralLedger(lines, INITIAL_CHART_OF_ACCOUNTS, 2, '2026-02-01', '2026-02-28', { accountNo: '100000' });
  assert.equal(cash.opening, 1000);
  assert.equal(cash.entries.length, 1);
  assert.equal(cash.closing, 750);
  assert.equal(balanceLabel(cash.closing, cash.type, fmt), '750.00 Dr');
  const [capital] = buildGeneralLedger(lines, INITIAL_CHART_OF_ACCOUNTS, 2, '2026-01-01', '2026-12-31', { accountNo: '300000' });
  assert.equal(balanceLabel(capital.closing, capital.type, fmt), '1000.00 Cr');
});

test('document validation enforces double entry and chart membership', () => {
  const known = new Set(['100000', '600000']);
  assert.equal(validateDocumentLines([{ accountNo: '600000', debit: 100, credit: 0 }, { accountNo: '100000', debit: 0, credit: 100 }], known), null);
  assert.match(validateDocumentLines([{ accountNo: '600000', debit: 100, credit: 0 }, { accountNo: '100000', debit: 0, credit: 90 }], known)!, /not balanced/);
  assert.match(validateDocumentLines([{ accountNo: '999999', debit: 100, credit: 0 }, { accountNo: '100000', debit: 0, credit: 100 }], known)!, /does not exist/);
  assert.match(validateDocumentLines([{ accountNo: '600000', debit: 100, credit: 100 }, { accountNo: '100000', debit: 0, credit: 0 }], known)!, /debit OR a credit/);
  assert.match(validateDocumentLines([{ accountNo: '600000', debit: 100, credit: 0 }], known)!, /at least two/);
});

test('WHT schedule derives payee, rate, gross and VAT withheld from a settlement document', () => {
  const lines = [
    mk({ docNo: 'PAY-001', accountNo: '200000', accountName: 'Trade Payables (Acme Ltd)', debit: 1150, description: 'Settlement of PO-001' }),
    mk({ docNo: 'PAY-001', accountNo: '100000', accountName: 'Cash at Bank', credit: 1005, description: 'bank transfer payment for PO-001' }),
    mk({ docNo: 'PAY-001', accountNo: '209000', accountName: 'Income Withholding Tax Payable', credit: 75, description: 'Income WHT 7.5% on PO-001' }),
    mk({ docNo: 'PAY-001', accountNo: '221000', accountName: 'VAT Withholding Payable', credit: 70, description: 'VAT withholding on PO-001' }),
    mk({ docNo: 'STAT-209000-2026-03', accountNo: '209000', debit: 75, description: 'Statutory remittance: WHT to GRA' }),
    mk({ docNo: 'STAT-209000-2026-03', accountNo: '100000', credit: 75, description: 'remittance' }),
  ];
  const rows = deriveWhtDeductions(lines, 2, '2026-03', []);
  assert.equal(rows.length, 1, 'one WHT row (remittances are excluded)');
  assert.equal(rows[0].partyName, 'Acme Ltd');
  assert.equal(rows[0].rate, 7.5);
  assert.equal(rows[0].taxAmount, 75);
  assert.equal(rows[0].grossAmount, 1000);
  assert.equal(rows[0].levyAmount, 70);
  assert.equal(periodRemitted(lines, 2, '2026-03', '209000'), 75);
  assert.equal(liabilityBalanceThrough(lines, 2, '2026-03', '209000'), 0);
});

test('WHT credits schedule captures tax withheld at source by customers', () => {
  const lines = [
    mk({ docNo: 'REC-001', accountNo: '100000', debit: 930, description: 'bank transfer receipt for INV-001' }),
    mk({ docNo: 'REC-001', accountNo: '110000', accountName: 'Trade Receivables (Big Customer Plc)', credit: 1000, description: 'receipt for INV-001' }),
    mk({ docNo: 'REC-001', accountNo: '115000', debit: 70, description: 'VAT withheld at source by Big Customer Plc on INV-001' }),
  ];
  const rows = deriveWhtCredits(lines, 2, null, []);
  assert.equal(rows.length, 1);
  assert.equal(rows[0].partyName, 'Big Customer Plc');
  assert.equal(rows[0].taxAmount, 70);
  assert.equal(rows[0].nature, 'VAT withheld by agent');
});

test('VAT schedules split the tax stack into VAT and levies and reconcile to the ledger', () => {
  const { vat, levies } = splitVatStack(200, 1000, rates);
  assert.equal(vat, 150);
  assert.equal(levies, 50);
  const lines = [
    mk({ docNo: 'INV-2026-0001', module: 'SD', docType: 'INV', accountNo: '110000', accountName: 'Trade Receivables (Kofi & Sons)', debit: 1200 }),
    mk({ docNo: 'INV-2026-0001', module: 'SD', docType: 'INV', accountNo: '400000', credit: 1000 }),
    mk({ docNo: 'INV-2026-0001', module: 'SD', docType: 'INV', accountNo: '220000', credit: 200 }),
    mk({ docNo: 'PO-2026-0001', module: 'MM', docType: 'PO', accountNo: '621000', debit: 500 }),
    mk({ docNo: 'PO-2026-0001', module: 'MM', docType: 'PO', accountNo: '125000', debit: 100 }),
    mk({ docNo: 'PO-2026-0001', module: 'MM', docType: 'PO', accountNo: '200000', accountName: 'Trade Payables (Supplies Ltd)', credit: 600 }),
  ];
  const out = deriveVatOutput(lines, 2, '2026-03', [], [], rates);
  assert.equal(out.length, 1);
  assert.equal(out[0].partyName, 'Kofi & Sons');
  assert.equal(out[0].grossAmount, 1000);
  assert.equal(out[0].taxAmount, 150);
  assert.equal(out[0].levyAmount, 50);
  const inp = deriveVatInput(lines, 2, '2026-03', [], [], rates);
  assert.equal(inp.length, 1);
  assert.equal(inp[0].partyName, 'Supplies Ltd');
  assert.equal(inp[0].grossAmount, 500);
  assert.equal(inp[0].taxAmount, 75);
  assert.equal(inp[0].levyAmount, 25);
  const t = scheduleTotals(out);
  assert.deepEqual(t, { gross: 1000, tax: 150, levy: 50, count: 1 });
});

test('seeded entity schedules derive without error and totals tie to the ledger accounts', () => {
  const out = deriveVatOutput(INITIAL_ACDOCA_LINES, client2.id, null, [], INITIAL_BUSINESS_PARTNERS, rates);
  const stack = out.reduce((n, r) => n + r.taxAmount + r.levyAmount, 0);
  const ledger = INITIAL_ACDOCA_LINES.filter((l) => l.clientId === client2.id && l.accountNo === '220000' && !l.docNo.startsWith('STAT-')).reduce((n, l) => n + l.credit - l.debit, 0);
  assert.ok(Math.abs(stack - ledger) < 0.05, `output VAT schedule (${stack}) ties to ledger 220000 (${ledger})`);
  const wht = deriveWhtDeductions(INITIAL_ACDOCA_LINES, client2.id, null, INITIAL_BUSINESS_PARTNERS);
  for (const r of wht) assert.ok(r.taxAmount > 0 && r.docNo);
});

test('schedule overrides replace derived values and manual rows are appended; orphans are dropped', () => {
  const derived = deriveVatOutput([
    mk({ docNo: 'INV-9', module: 'SD', docType: 'INV', accountNo: '110000', accountName: 'Trade Receivables (X)', debit: 120 }),
    mk({ docNo: 'INV-9', module: 'SD', docType: 'INV', accountNo: '400000', credit: 100 }),
    mk({ docNo: 'INV-9', module: 'SD', docType: 'INV', accountNo: '220000', credit: 20 }),
  ], 2, null, [], [], rates);
  const base = { clientId: 2, kind: 'vat_output' as const, period: '2026-03', date: '2026-03-10', partyTin: 'C0001', nature: 'Standard-rated supply', grossAmount: 100, rate: 15, taxAmount: 15, levyAmount: 5, reference: '', status: 'Filed', createdBy: 't', updatedAt: 'now' };
  const entries: TaxScheduleEntry[] = [
    { ...base, id: 'o1', source: 'ledger', sourceKey: 'vat_output:INV-9', docNo: 'INV-9', partyName: 'X Limited' },
    { ...base, id: 'o2', source: 'ledger', sourceKey: 'vat_output:GONE', docNo: 'GONE', partyName: 'Orphan' },
    { ...base, id: 'm1', source: 'manual', docNo: 'IMP-1', partyName: 'Customs', nature: 'Import', grossAmount: 50, taxAmount: 7.5, levyAmount: 2.5 },
  ];
  const merged = mergeScheduleRows(derived, entries, 'vat_output', 2, null);
  assert.equal(merged.length, 2);
  const edited = merged.find((r) => r.docNo === 'INV-9')!;
  assert.equal(edited.edited, true);
  assert.equal(edited.partyName, 'X Limited');
  assert.equal(edited.partyTin, 'C0001');
  assert.equal(edited.status, 'Filed');
  assert.ok(merged.some((r) => r.source === 'manual' && r.docNo === 'IMP-1'));
  assert.ok(!merged.some((r) => r.docNo === 'GONE'));
});

test('print document is self-contained, escapes HTML and carries the entity letterhead', () => {
  const html = buildReportHtml({
    title: 'Trial balance', entity: toPrintEntity(client2, { legalName: 'Gold Coast Mines Ltd', tin: 'C0094812201', address: 'Tarkwa <HQ>' }),
    periodLabel: 'Through 2026-03-31', preparedBy: 'owner',
    sections: [{ columns: [{ key: 'a', label: 'Account' }, { key: 'v', label: 'Amount', numeric: true }], rows: [{ a: '100000 <script>', v: 1234.5 }], totals: { a: 'TOTAL', v: 1234.5 } }],
  });
  assert.ok(html.startsWith('<!doctype html>'));
  assert.ok(html.includes('Gold Coast Mines Ltd'));
  assert.ok(html.includes('TIN C0094812201'));
  assert.ok(html.includes('Tarkwa &lt;HQ&gt;'));
  assert.ok(html.includes('100000 &lt;script&gt;'), 'cell content is escaped');
  assert.ok(!html.includes('<script>'), 'no raw script tags');
  assert.ok(html.includes('1,234.50'), 'numeric cells are formatted');
  assert.ok(!html.includes('app-shell'), 'nothing from the workspace shell is printed');
});
