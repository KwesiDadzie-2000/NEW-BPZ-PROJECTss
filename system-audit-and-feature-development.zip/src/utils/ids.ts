/**
 * Collision-safe identifier and document-number generation.
 *
 * Fixes three classes of bug in the original components:
 *  1. Integer primary keys (clients, bank_accounts, employees) were assigned
 *     `Date.now()` (~1.7 × 10¹²), which overflows PostgreSQL `integer`
 *     (max 2 147 483 647) — every new client, bank account or employee made the
 *     server state sync fail with "value out of range for type integer".
 *  2. Journal-line ids such as `JL-PRE-${Date.now()}-1` collided when several
 *     documents were posted in the same millisecond (e.g. "Post all due"
 *     prepayments), violating the journal_lines primary key and rolling back the
 *     whole sync.
 *  3. Document numbers like `INV-2026-${random 1000–9999}` could repeat; the
 *     server then rejected the sync ("already posted with different content").
 */

const INT32_MAX = 2_147_483_647;
const INT_ID_FLOOR = 100_000_000; // well above seeded ids (1, 2, 3 …)

function randomInt(min: number, maxExclusive: number): number {
  const span = maxExclusive - min;
  try {
    const buf = new Uint32Array(1);
    globalThis.crypto.getRandomValues(buf);
    return min + (buf[0] % span);
  } catch {
    return min + Math.floor(Math.random() * span);
  }
}

/**
 * New integer id that fits a PostgreSQL `integer` column and does not clash
 * with ids already present. Random in a high range so ids created by different
 * tenants (who cannot see each other's rows) are also practically unique.
 */
export function nextIntId(existing: ReadonlyArray<{ id: number }>): number {
  const taken = new Set(existing.map((row) => row.id));
  for (let attempt = 0; attempt < 50; attempt += 1) {
    const candidate = randomInt(INT_ID_FLOOR, INT32_MAX);
    if (!taken.has(candidate)) return candidate;
  }
  // Practically unreachable; fall back to max + 1 within range.
  const max = Math.max(0, ...existing.map((row) => row.id));
  return Math.min(max + 1, INT32_MAX);
}

let sequence = 0;

/** Globally unique text id, unique even when called many times per millisecond. */
export function uniqueId(prefix: string): string {
  sequence = (sequence + 1) % 1_000_000;
  const time = Date.now().toString(36);
  const rand = randomInt(0, 36 ** 4).toString(36).padStart(4, "0");
  return `${prefix}-${time}-${sequence.toString(36)}${rand}`;
}

/**
 * Next sequential document number for a prefix, e.g. `nextDocNo("INV-2026", ["INV-2026-0007"])`
 * → `INV-2026-0008`. Numbers never repeat within the supplied list.
 */
export function nextDocNo(prefix: string, existing: ReadonlyArray<string | null | undefined>, width = 4): string {
  let max = 0;
  const lead = `${prefix}-`;
  for (const value of existing) {
    if (!value || !value.startsWith(lead)) continue;
    const n = Number.parseInt(value.slice(lead.length), 10);
    if (Number.isFinite(n) && n > max) max = n;
  }
  return `${prefix}-${String(max + 1).padStart(width, "0")}`;
}

/** Current calendar year (kept here so render code stays pure). */
export function currentYear(): number {
  return new Date().getFullYear();
}

/** Suggested company registration number for a new-client form. */
export function suggestRegNumber(): string {
  return `GH-${randomInt(10_000, 100_000)}`;
}

/** Short unique suffix for document numbers (replaces `Date.now() % N`, which repeats). */
export function docSuffix(): string {
  sequence = (sequence + 1) % 1_000_000;
  return (Date.now().toString(36).slice(-5) + sequence.toString(36) + randomInt(0, 36 ** 2).toString(36)).toUpperCase();
}
