import React, { useState, useMemo } from 'react';
import {
  ClientEntity,
  EmployeeProfile,
  MonthlyPayrollRecord,
  PayrollDeductionConfig,
  ACDOCALine,
  UserAccount,
} from '../types/accounting';
import { Card, PageHeader, Stat, formatGHS, thCls, numCls, rowCls } from './ui';
import {
  computeEmployeeMonthlyPayroll,
  round2,
} from '../utils/payrollCalculator';
import { persistentStorage } from '../utils/persistentStorage';
import {
  Plus,
  Play,
  Printer,
  Edit3,
  Calendar,
  Save,
  Trash2,
  Download,
  CheckCircle,
} from 'lucide-react';
import { nextIntId, uniqueId } from '../utils/ids';
import { COST_CENTRES, costCentreName, defaultCostCentreForDepartment } from '../data/costCentres';

interface PayrollSectionProps {
  currentClient: ClientEntity;
  employees: EmployeeProfile[];
  lines: ACDOCALine[];
  currentUser: UserAccount;
  isPeriodClosed: boolean;
  onAddEmployee: (emp: EmployeeProfile) => void;
  onPostMonthlyPayroll: (period: string, journalLines: ACDOCALine[], records: MonthlyPayrollRecord[]) => boolean;
}

export const PayrollSection: React.FC<PayrollSectionProps> = ({
  currentClient,
  employees,
  lines,
  currentUser,
  isPeriodClosed,
  onAddEmployee,
  onPostMonthlyPayroll,
}) => {
  // Selected Payroll Month / Period (e.g. 2026-03)
  const [selectedPeriod, setSelectedPeriod] = useState<string>(() => new Date().toISOString().slice(0, 7));

  // Month-specific payroll records state (loaded from persistent storage or computed from employee profiles)
  const [savedPayrollRuns, setSavedPayrollRuns] = useState<MonthlyPayrollRecord[]>(() =>
    persistentStorage.getPayrollRecords()
  );

  // Temporary monthly overrides for the selected period: employeeId -> partial overrides
  const [monthlyOverrides, setMonthlyOverrides] = useState<
    Record<
      number,
      {
        basicSalary?: number;
        allowances?: number;
        bonusAdditions?: number;
        taxRelief?: number;
        reliefType?: string;
        isResident?: boolean;
        exemptTier1?: boolean;
        exemptTier2?: boolean;
        ssnitExempt?: boolean;
        ssnitExemptionReason?: string;
        deductions?: PayrollDeductionConfig[];
      }
    >
  >({});

  // Modals state
  const [showAddEmpModal, setShowAddEmpModal] = useState(false);
  const [editingEmployee, setEditingEmployee] = useState<EmployeeProfile | null>(null);
  const [selectedPayslipRecord, setSelectedPayslipRecord] = useState<MonthlyPayrollRecord | null>(null);
  const [payrollSuccessMsg, setPayrollSuccessMsg] = useState<string | null>(null);

  // New Employee Form State
  const [empName, setEmpName] = useState('');
  const [empRole, setEmpRole] = useState('');
  const [empDept, setEmpDept] = useState('Operations');
  // Every employee is charged to a cost centre so the payroll journal allocates
  // staff cost by responsibility centre instead of lumping it all into CC-HR.
  const [empCostCentre, setEmpCostCentre] = useState(defaultCostCentreForDepartment('Operations'));
  const [empBasic, setEmpBasic] = useState(12000);
  const [empAllowances, setEmpAllowances] = useState(1500);
  const [empResident, setEmpResident] = useState(true);
  const [empExemptT1, setEmpExemptT1] = useState(false);
  const [empExemptT2, setEmpExemptT2] = useState(false);
  const [empSsnitExempt, setEmpSsnitExempt] = useState(false);
  const [empSsnitExemptionReason, setEmpSsnitExemptionReason] = useState('');
  const [empRelief, setEmpRelief] = useState(0);
  const [empReliefType, setEmpReliefType] = useState('Standard Personal Relief');
  const [empDeductions, setEmpDeductions] = useState<PayrollDeductionConfig[]>([]);

  // Check if this month has already been posted to Universal Journal (ACDOCA)
  const isPeriodPostedInJournal = useMemo(() => {
    return lines.some(
      (l) =>
        l.clientId === currentClient.id &&
        l.period === selectedPeriod &&
        (l.docNo.startsWith('PAYROLL') || l.docType === 'STAT' && l.accountNo === '510000')
    );
  }, [lines, currentClient.id, selectedPeriod]);

  // Compute live payroll rows for all active employees for the selected period
  const activeEmployees = employees.filter((e) => e.status === 'active');

  const currentMonthRecords: MonthlyPayrollRecord[] = useMemo(() => {
    // Check if we already have saved posted records for this period
    const existingForPeriod = savedPayrollRuns.filter((r) => r.period === selectedPeriod && r.clientId === currentClient.id);
    const existingMap = new Map(existingForPeriod.map((r) => [r.employeeId, r]));

    return activeEmployees.map((emp) => {
      if (existingMap.has(emp.id) && isPeriodPostedInJournal) {
        return existingMap.get(emp.id)!;
      }
      const override = monthlyOverrides[emp.id] || {};
      return computeEmployeeMonthlyPayroll({
        employee: emp,
        period: selectedPeriod,
        basicSalary: override.basicSalary,
        allowances: override.allowances,
        bonusAdditions: override.bonusAdditions,
        taxRelief: override.taxRelief,
        reliefType: override.reliefType,
        isResident: override.isResident,
        exemptTier1: override.exemptTier1,
        exemptTier2: override.exemptTier2,
        ssnitExempt: override.ssnitExempt,
        ssnitExemptionReason: override.ssnitExemptionReason,
        deductions: override.deductions,
      });
    });
  }, [activeEmployees, selectedPeriod, savedPayrollRuns, monthlyOverrides, isPeriodPostedInJournal, currentClient.id]);

  // Payroll Aggregated Totals
  const totalGrossWageBill = currentMonthRecords.reduce((s, r) => s + r.grossPay, 0);
  const totalEmployeeSSNIT = currentMonthRecords.reduce((s, r) => s + r.ssnitTier1Employee + r.ssnitTier2Employee, 0);
  const totalPAYETax = currentMonthRecords.reduce((s, r) => s + r.payeTax, 0);
  const totalOtherDeductions = currentMonthRecords.reduce((s, r) => s + r.totalCustomDeductions, 0);
  const totalNetSalariesPayable = currentMonthRecords.reduce((s, r) => s + r.netSalary, 0);
  const totalEmployerSSNITCost = currentMonthRecords.reduce((s, r) => s + r.ssnitEmployerCost, 0);
  // Statutory remittance split of the combined 18.5%: 5% → Tier 2 trustee (206100),
  // remainder (13.5%) → SSNIT Tier 1 incl. NHIA (206000). The residual method keeps
  // the journal exactly balanced even with per-employee rounding or exemptions.
  const totalTier2Payable = round2(currentMonthRecords.reduce((s, r) => s + (r.ssnitTier2Allocation || 0), 0));
  const totalTier1Payable = round2(totalEmployeeSSNIT + totalEmployerSSNITCost - totalTier2Payable);

  // Available periods list
  // Post / Run Payroll for the Selected Month into Universal Journal
  const handleRunAndPostPayroll = () => {
    if (activeEmployees.length === 0 || isPeriodPostedInJournal || isPeriodClosed ||
        currentUser.status === 'restricted' || currentUser.status === 'suspended' ||
        currentUser.permissions?.canRunPayroll === false ||
        currentMonthRecords.some(r => !Number.isFinite(r.netSalary) || r.netSalary < 0)) return;

    const docNo = `PAYROLL-${selectedPeriod}`;
    const today = new Date().toISOString().split('T')[0];

    // Staff cost is analysed by COST CENTRE: one expense line per centre so the
    // management accounts show where the payroll cost was incurred. Rounding
    // residuals are absorbed by the largest centre to keep Dr = Cr exact.
    const centreOf = (employeeId: number) =>
      employees.find((e) => e.id === employeeId)?.costCenter || 'CC-HR';
    const splitByCentre = (pick: (r: typeof currentMonthRecords[number]) => number, total: number) => {
      const buckets = new Map<string, number>();
      for (const r of currentMonthRecords) {
        const centre = centreOf(r.employeeId);
        buckets.set(centre, round2((buckets.get(centre) ?? 0) + pick(r)));
      }
      const rows = [...buckets.entries()].filter(([, amount]) => Math.abs(amount) >= 0.005);
      if (!rows.length) return [] as { centre: string; amount: number }[];
      const allocated = round2(rows.reduce((n, [, amount]) => n + amount, 0));
      const residual = round2(total - allocated);
      if (Math.abs(residual) >= 0.005) {
        rows.sort((a, b) => b[1] - a[1]);
        rows[0] = [rows[0][0], round2(rows[0][1] + residual)];
      }
      return rows.map(([centre, amount]) => ({ centre, amount }));
    };
    const grossByCentre = splitByCentre((r) => r.grossPay, round2(totalGrossWageBill));
    const employerSsnitByCentre = splitByCentre((r) => r.ssnitEmployerCost, round2(totalEmployerSSNITCost));

    const generatedLines: ACDOCALine[] = [
      // 1. Dr Gross Wages & Salaries (510000) — split per cost centre
      ...grossByCentre.map((row, index) => ({
        id: `${uniqueId('JL-PR')}-1-${index}`,
        docNo,
        period: selectedPeriod,
        date: today,
        module: 'HR' as const,
        docType: 'STAT' as const,
        accountNo: '510000',
        accountName: 'Salaries, Allowances & Staff Wages Expense',
        costCenter: row.centre,
        debit: row.amount,
        credit: 0,
        currency: currentClient.currency,
        description: `Gross staff wage bill ${selectedPeriod} — ${costCentreName(row.centre)}`,
        createdBy: currentUser.username,
        checkedBy: currentUser.canCheck ? currentUser.username : undefined,
        clientId: currentClient.id,
      })),
      // 2. Dr Employer SSNIT Contribution Expense (511000) — split per cost centre
      ...employerSsnitByCentre.map((row, index) => ({
        id: `${uniqueId('JL-PR')}-2-${index}`,
        docNo,
        period: selectedPeriod,
        date: today,
        module: 'HR' as const,
        docType: 'STAT' as const,
        accountNo: '511000',
        accountName: 'Employer SSNIT Statutory Contribution Expense (13%)',
        costCenter: row.centre,
        debit: row.amount,
        credit: 0,
        currency: currentClient.currency,
        description: `Employer mandatory pension contribution ${selectedPeriod} — ${costCentreName(row.centre)}`,
        createdBy: currentUser.username,
        checkedBy: currentUser.canCheck ? currentUser.username : undefined,
        clientId: currentClient.id,
      })),
      // 3. Cr Net Salaries Payable (205000)
      {
        id: `${uniqueId('JL-PR')}-3`,
        docNo,
        period: selectedPeriod,
        date: today,
        module: 'HR' as const,
        docType: 'STAT' as const,
        accountNo: '205000',
        accountName: 'Net Salaries Payable (Bank Disbursement Liability)',
        costCenter: 'CC-HR',
        debit: 0,
        credit: round2(totalNetSalariesPayable),
        currency: currentClient.currency,
        description: `Net salaries payable to employees for ${selectedPeriod}`,
        createdBy: currentUser.username,
        checkedBy: currentUser.canCheck ? currentUser.username : undefined,
        clientId: currentClient.id,
      },
      // 4a. Cr SSNIT Tier 1 Payable (206000) — 13.5% of insurable basic (incl. 2.5% → NHIA).
      // Registered as a payable the moment payroll posts; remitted at the Payment Desk by the 14th.
      ...(totalTier1Payable > 0
        ? [
            {
              id: `${uniqueId('JL-PR')}-4`,
              docNo,
              period: selectedPeriod,
              date: today,
              module: 'HR' as const,
              docType: 'STAT' as const,
              accountNo: '206000',
              accountName: 'SSNIT Tier 1 Payable (13.5% incl. NHIA 2.5%)',
              costCenter: 'CC-HR',
              debit: 0,
              credit: round2(totalTier1Payable),
              currency: currentClient.currency,
              description: `SSNIT Tier 1 13.5% remittance payable for ${selectedPeriod} (incl. 2.5% forwarded to NHIA) — due 14th of following month`,
              createdBy: currentUser.username,
              checkedBy: currentUser.canCheck ? currentUser.username : undefined,
              clientId: currentClient.id,
            },
          ]
        : []),
      // 4b. Cr Tier 2 Occupational Pension Payable (206100) — mandatory 5% to the licensed trustee.
      ...(totalTier2Payable > 0
        ? [
            {
              id: `${uniqueId('JL-PR')}-4b`,
              docNo,
              period: selectedPeriod,
              date: today,
              module: 'HR' as const,
              docType: 'STAT' as const,
              accountNo: '206100',
              accountName: 'Tier 2 Occupational Pension Payable (5%)',
              costCenter: 'CC-HR',
              debit: 0,
              credit: round2(totalTier2Payable),
              currency: currentClient.currency,
              description: `Mandatory Tier 2 5% remittance payable to approved trustee for ${selectedPeriod} — due 14th of following month`,
              createdBy: currentUser.username,
              checkedBy: currentUser.canCheck ? currentUser.username : undefined,
              clientId: currentClient.id,
            },
          ]
        : []),
      // 5. Cr GRA PAYE Withholding Payable (207000)
      ...(totalPAYETax > 0
        ? [
            {
              id: `${uniqueId('JL-PR')}-5`,
              docNo,
              period: selectedPeriod,
              date: today,
              module: 'HR' as const,
              docType: 'STAT' as const,
              accountNo: '207000',
              accountName: 'GRA PAYE Income Tax Withholding Payable',
              costCenter: 'CC-HR',
              debit: 0,
              credit: round2(totalPAYETax),
              currency: currentClient.currency,
              description: `Income Tax Act 896 PAYE monthly tax remittance for ${selectedPeriod}`,
              createdBy: currentUser.username,
              checkedBy: currentUser.canCheck ? currentUser.username : undefined,
              clientId: currentClient.id,
            },
          ]
        : []),
      // 6. Cr Other Custom Deductions / Staff Loan Recovery (208000)
      ...(totalOtherDeductions > 0
        ? [
            {
              id: `${uniqueId('JL-PR')}-6`,
              docNo,
              period: selectedPeriod,
              date: today,
              module: 'HR' as const,
              docType: 'STAT' as const,
              accountNo: '208000',
              accountName: 'Staff Loan Recoveries, Welfare & Other Payables',
              costCenter: 'CC-HR',
              debit: 0,
              credit: round2(totalOtherDeductions),
              currency: currentClient.currency,
              description: `Custom payroll deductions recovery for period ${selectedPeriod}`,
              createdBy: currentUser.username,
              checkedBy: currentUser.canCheck ? currentUser.username : undefined,
              clientId: currentClient.id,
            },
          ]
        : []),
    ];

    // Mark current records as Posted only after a balanced journal has been accepted.
    const updatedRecords = currentMonthRecords.map((r) => ({
      ...r,
      clientId: currentClient.id,
      status: 'Posted' as const,
      docNo,
      postedDate: today,
    }));

    if (!onPostMonthlyPayroll(selectedPeriod, generatedLines, updatedRecords)) {
      setPayrollSuccessMsg('Posting blocked. Verify ledger balance, period lock and previous payroll runs.');
      return;
    }
    const allRecordsFiltered = savedPayrollRuns.filter((r) => !(r.period === selectedPeriod && r.clientId === currentClient.id));
    const newSaved = [...allRecordsFiltered, ...updatedRecords];
    setSavedPayrollRuns(newSaved);
    persistentStorage.savePayrollRecords(newSaved);

    setPayrollSuccessMsg(
      `Payroll for ${selectedPeriod} posted (Doc: ${docNo}). Statutory payables are now live at the Expenses & Statutory desk and the Payment Desk: PAYE ₵${formatGHS(totalPAYETax)} (GRA, due 15th), SSNIT Tier 1 13.5% ₵${formatGHS(totalTier1Payable)} and Tier 2 5% ₵${formatGHS(totalTier2Payable)} (due 14th). Net salaries ₵${formatGHS(totalNetSalariesPayable)} await release at the Payment Desk.`
    );
    setTimeout(() => setPayrollSuccessMsg(null), 12000);
  };

  // Export Master Payroll Sheet (CSV)
  const handleExportPayrollCsv = () => {
    let csv = `BPZ CONSULT — MONTHLY PAYROLL REGISTER\n`;
    csv += `Client,${currentClient.name},ClientCode,${currentClient.code},Period,${selectedPeriod}\n\n`;
    csv += `EmployeeCode,FullName,Department,Role,Status,Resident,InsurableBasic,BasicSalary,Allowances,Bonus,GrossPay,TaxRelief,SSNITTier1_5p5pct,SSNITTier2Alloc_5pct,TaxableIncome,PAYETax,CustomDeductions,TotalDeductions,NetSalary,EmployerSSNIT_13pct\n`;

    currentMonthRecords.forEach((r) => {
      csv += `"${r.bpNo}","${r.name}","${r.department}","${r.role}","${r.status}","${
        r.isResident ? 'Resident' : 'Non-Resident'
      }",${r.ssnitInsurableBase},${r.basicSalary},${r.allowances},${r.bonusAdditions},${r.grossPay},${r.taxRelief},${
        r.ssnitTier1Employee
      },${r.ssnitTier2Allocation},${r.taxableIncome},${r.payeTax},${r.totalCustomDeductions},${
        r.totalEmployeeDeductions
      },${r.netSalary},${r.ssnitEmployerCost}\n`;
    });

    csv += `\n"TOTALS","","","","","","",${currentMonthRecords.reduce(
      (s, r) => s + r.basicSalary,
      0
    )},${currentMonthRecords.reduce((s, r) => s + r.allowances, 0)},${currentMonthRecords.reduce(
      (s, r) => s + r.bonusAdditions,
      0
    )},${totalGrossWageBill},${currentMonthRecords.reduce(
      (s, r) => s + r.taxRelief,
      0
    )},${currentMonthRecords.reduce(
      (s, r) => s + r.ssnitTier1Employee,
      0
    )},${currentMonthRecords.reduce(
      (s, r) => s + r.ssnitTier2Allocation,
      0
    )},${currentMonthRecords.reduce(
      (s, r) => s + r.taxableIncome,
      0
    )},${totalPAYETax},${totalOtherDeductions},${currentMonthRecords.reduce(
      (s, r) => s + r.totalEmployeeDeductions,
      0
    )},${totalNetSalariesPayable},${totalEmployerSSNITCost}\n`;

    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${currentClient.code}_Payroll_Master_${selectedPeriod}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  // Add Employee Form Handler
  const handleCreateEmployee = (e: React.FormEvent) => {
    e.preventDefault();
    if (!empName) return;

    const newEmp: EmployeeProfile = {
      id: nextIntId(employees),
      bpNo: `E00${employees.length + 1}`,
      name: empName.trim(),
      role: empRole.trim(),
      department: empDept,
      costCenter: empCostCentre || defaultCostCentreForDepartment(empDept),
      jurisdiction: currentClient.jurisdiction,
      basicSalary: empBasic,
      allowances: empAllowances,
      ssnitNumber: `C${Math.floor(1000000000 + Math.random() * 9000000000)}`,
      tin: `P00${Math.floor(1000000 + Math.random() * 9000000)}`,
      status: 'active',
      isResident: empResident,
      exemptTier1: empExemptT1,
      exemptTier2: empExemptT2,
      ssnitExempt: empSsnitExempt,
      ssnitExemptionReason: empSsnitExemptionReason || undefined,
      taxRelief: empRelief,
      reliefType: empReliefType,
      deductions: empDeductions,
    };

    onAddEmployee(newEmp);
    setShowAddEmpModal(false);
    setEmpName('');
    setEmpRole('');
    setEmpBasic(12000);
    setEmpAllowances(1500);
    setEmpRelief(0);
    setEmpDeductions([]);
    setEmpCostCentre(defaultCostCentreForDepartment(empDept));
  };

  return (
    <div className="space-y-6">
      <PageHeader
        kicker={`HR · COMPREHENSIVE PAYROLL DESK · ${currentClient.code}`}
        title="Payroll Desk & Statutory Benefits"
        desc="Edit monthly pay and review calculated deductions. Demo tax assumptions require independent verification before use."
      >
        <div className="flex flex-wrap items-center gap-2">
          {/* Month / Period Selector */}
          <div className="flex items-center gap-1.5 rounded-lg border border-sky-300 bg-white px-3 py-1.5 shadow-xs">
            <Calendar className="h-4 w-4 text-[#855b00]" />
            <span className="text-xs font-bold text-[#355875]">Payroll Month:</span>
            <input type="month" value={selectedPeriod} onChange={e => setSelectedPeriod(e.target.value)} className="bg-transparent font-mono text-xs font-black text-[#082f4f] outline-none" />
          </div>

          <button
            onClick={handleExportPayrollCsv}
            className="flex items-center gap-1.5 rounded-lg border border-sky-300 bg-white px-3.5 py-2 text-xs font-bold text-[#082f4f] hover:bg-sky-50 transition shadow-xs"
          >
            <Download className="h-4 w-4 text-emerald-700" />
            <span>Export Register (CSV)</span>
          </button>

          <button
            onClick={() => setShowAddEmpModal(true)}
            className="flex items-center gap-1.5 rounded-lg border border-sky-300 bg-white px-3.5 py-2 text-xs font-bold text-[#082f4f] hover:bg-sky-50 transition shadow-xs"
          >
            <Plus className="h-4 w-4" />
            <span>Add Employee Master</span>
          </button>

          <button
            onClick={handleRunAndPostPayroll}
            disabled={isPeriodPostedInJournal || isPeriodClosed || currentUser.permissions?.canRunPayroll === false || currentUser.status === 'restricted'}
            className="flex items-center gap-1.5 rounded-lg bg-[#082f4f] px-4 py-2 text-xs font-bold text-white hover:bg-[#0c3f68] transition shadow-xs disabled:cursor-not-allowed disabled:opacity-40"
          >
            <Play className="h-3.5 w-3.5" />
            <span>Post {selectedPeriod} Payroll to Journal</span>
          </button>
        </div>
      </PageHeader>

      {payrollSuccessMsg && (
        <div className="rounded-xl border border-emerald-300 bg-emerald-50 p-4 text-xs font-bold text-emerald-900 flex items-center gap-2 shadow-xs">
          <CheckCircle className="h-5 w-5 text-emerald-700 shrink-0" />
          <span>{payrollSuccessMsg}</span>
        </div>
      )}

      {/* Selected Month Status & KPI Indicators */}
      <div className="grid grid-cols-2 gap-3 xl:grid-cols-4">
        <Stat
          label={`Gross Wage Bill (${selectedPeriod})`}
          value={`₵${formatGHS(totalGrossWageBill)}`}
          sub={`${activeEmployees.length} active employees`}
        />
        <Stat
          label="Total Net Salaries"
          value={`₵${formatGHS(totalNetSalariesPayable)}`}
          tone="text-emerald-800"
          sub="Disbursement to Bank (205000)"
        />
        <Stat
          label="GRA Monthly PAYE Tax"
          value={`₵${formatGHS(totalPAYETax)}`}
          tone="text-rose-800"
          sub="Act 896 Progressive / Non-Res"
        />
        <Stat
          label="Statutory SSNIT (18.5% of basic)"
          value={`₵${formatGHS(totalEmployeeSSNIT + totalEmployerSSNITCost)}`}
          tone="text-[#006f98]"
          sub={`Tier 1 13.5% ₵${formatGHS(totalTier1Payable)} → 206000 · Tier 2 5% ₵${formatGHS(totalTier2Payable)} → 206100`}
        />
      </div>

      {/* Official Statutory GRA Monthly PAYE Tax Bands Table (Active Rates) */}
      <div className="rounded-xl border border-sky-200 bg-sky-50/70 p-4 shadow-xs space-y-2.5">
        <div className="flex items-center justify-between">
          <span className="font-bold text-[#082f4f] text-xs uppercase tracking-wider">
            Ghana Revenue Authority (GRA) Statutory Monthly PAYE Graduated Tax Bands
          </span>
          <span className="font-mono text-[10.5px] font-bold text-emerald-800 bg-emerald-100 px-2.5 py-0.5 rounded border border-emerald-300">
            GRA · Income Tax (Amendment) Act 2026 (Act 1178)
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2 text-center text-xs">
          <div className="rounded-lg bg-white p-2 border border-sky-200 shadow-2xs">
            <div className="text-[10px] text-slate-500 font-bold uppercase">FIRST</div>
            <div className="font-mono font-bold text-[#082f4f] text-[11px]">₵588.00</div>
            <div className="font-mono font-black text-emerald-700 text-sm">0.00%</div>
          </div>
          <div className="rounded-lg bg-white p-2 border border-sky-200 shadow-2xs">
            <div className="text-[10px] text-slate-500 font-bold uppercase">NEXT</div>
            <div className="font-mono font-bold text-[#082f4f] text-[11px]">₵80.00</div>
            <div className="font-mono font-black text-[#855b00] text-sm">5.00%</div>
          </div>
          <div className="rounded-lg bg-white p-2 border border-sky-200 shadow-2xs">
            <div className="text-[10px] text-slate-500 font-bold uppercase">NEXT</div>
            <div className="font-mono font-bold text-[#082f4f] text-[11px]">₵100.00</div>
            <div className="font-mono font-black text-[#855b00] text-sm">10.00%</div>
          </div>
          <div className="rounded-lg bg-white p-2 border border-sky-200 shadow-2xs">
            <div className="text-[10px] text-slate-500 font-bold uppercase">NEXT</div>
            <div className="font-mono font-bold text-[#082f4f] text-[11px]">₵2,900.00</div>
            <div className="font-mono font-black text-[#855b00] text-sm">17.50%</div>
          </div>
          <div className="rounded-lg bg-white p-2 border border-sky-200 shadow-2xs">
            <div className="text-[10px] text-slate-500 font-bold uppercase">NEXT</div>
            <div className="font-mono font-bold text-[#082f4f] text-[11px]">₵16,000.00</div>
            <div className="font-mono font-black text-rose-700 text-sm">25.00%</div>
          </div>
          <div className="rounded-lg bg-white p-2 border border-sky-200 shadow-2xs">
            <div className="text-[10px] text-slate-500 font-bold uppercase">NEXT</div>
            <div className="font-mono font-bold text-[#082f4f] text-[11px]">₵30,332.00</div>
            <div className="font-mono font-black text-rose-700 text-sm">30.00%</div>
          </div>
          <div className="rounded-lg bg-white p-2 border border-sky-200 shadow-2xs">
            <div className="text-[10px] text-slate-500 font-bold uppercase">EXCEEDING</div>
            <div className="font-mono font-bold text-[#082f4f] text-[11px]">₵50,000.00</div>
            <div className="font-mono font-black text-rose-800 text-sm">35.00%</div>
          </div>
        </div>
      </div>

      {/* Official SSNIT Statutory Contribution Framework (Act 766 as amended; official SSNIT rates) */}
      <div className="rounded-xl border border-emerald-200 bg-emerald-50/70 p-4 shadow-xs space-y-2.5">
        <div className="flex items-center justify-between">
          <span className="font-bold text-[#082f4f] text-xs uppercase tracking-wider">
            SSNIT Mandatory Pension — 18.5% of Basic Salary (Tier 1 &amp; Tier 2)
          </span>
          <span className="font-mono text-[10.5px] font-bold text-emerald-800 bg-emerald-100 px-2.5 py-0.5 rounded border border-emerald-300">
            Official SSNIT rates · 2026 insurable band ₵587.80 – ₵69,000
          </span>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center text-xs">
          <div className="rounded-lg bg-white p-2 border border-emerald-200 shadow-2xs">
            <div className="text-[10px] text-slate-500 font-bold uppercase">Employee Deduction</div>
            <div className="font-mono font-black text-[#082f4f] text-sm">5.5% of basic</div>
            <div className="text-[10px] text-[#2d4f6d]">Withheld from salary (Tier 1)</div>
          </div>
          <div className="rounded-lg bg-white p-2 border border-emerald-200 shadow-2xs">
            <div className="text-[10px] text-slate-500 font-bold uppercase">Employer Cost</div>
            <div className="font-mono font-black text-[#082f4f] text-sm">13.0% of basic</div>
            <div className="text-[10px] text-[#2d4f6d]">Paid on top of wages (not deducted)</div>
          </div>
          <div className="rounded-lg bg-white p-2 border border-emerald-200 shadow-2xs">
            <div className="text-[10px] text-slate-500 font-bold uppercase">Remittance → Tier 1 (SSNIT)</div>
            <div className="font-mono font-black text-[#006f98] text-sm">13.5% of basic</div>
            <div className="text-[10px] text-[#2d4f6d]">Incl. 2.5% forwarded to NHIA health cover</div>
          </div>
          <div className="rounded-lg bg-white p-2 border border-emerald-200 shadow-2xs">
            <div className="text-[10px] text-slate-500 font-bold uppercase">Remittance → Tier 2 (Trustee)</div>
            <div className="font-mono font-black text-emerald-800 text-sm">5.0% of basic</div>
            <div className="text-[10px] text-[#2d4f6d]">Mandatory occupational scheme — funded inside the 18.5%</div>
          </div>
        </div>
        <p className="text-[10.5px] leading-relaxed text-[#2d4f6d]">
          The combined 18.5% (5.5% worker + 13% employer) is remitted within 14 days after month end: 13.5% to SSNIT
          for the mandatory Tier 1 scheme — of which 2.5% is forwarded to the NHIA — and the mandatory 5% to the
          worker&rsquo;s Tier 2 privately-managed occupational scheme. The Tier 2 5% is part of the 18.5% and is never a
          separate deduction from the worker&rsquo;s pay. Contributions are computed on <strong>basic salary</strong>
          (allowances and bonuses excluded), within the 2026 insurable band of ₵587.80 (minimum) to ₵69,000 (maximum) per month.
        </p>
      </div>

      {/* Monthly Payroll Preparation & Editing Sheet */}
      <Card
        title={`Monthly Payroll Master Sheet — ${selectedPeriod}`}
        sub={`Editable payroll schedule for ${currentClient.name} (${currentClient.currency})`}
        action={
          <div className="flex items-center gap-2">
            <span
              className={`rounded px-2.5 py-1 text-xs font-bold ${
                isPeriodPostedInJournal
                  ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                  : 'bg-amber-100 text-[#855b00] border border-amber-300'
              }`}
            >
              {isPeriodPostedInJournal ? `✓ Posted to ACDOCA (Period ${selectedPeriod})` : `Draft / Unposted (${selectedPeriod})`}
            </span>
          </div>
        }
      >
        <div className="overflow-x-auto">
          <table className="w-full min-w-[1050px] text-xs">
            <thead>
              <tr className="border-b border-sky-200 bg-sky-50/70">
                <th className={thCls}>Staff Code</th>
                <th className={thCls}>Employee Name</th>
                <th className={thCls}>Status / Exemption</th>
                <th className={thCls + ' text-right'}>Basic (₵)</th>
                <th className={thCls + ' text-right'}>Allowances (₵)</th>
                <th className={thCls + ' text-right'}>Gross Pay (₵)</th>
                <th className={thCls + ' text-right'}>Tax Relief (₵)</th>
                <th className={thCls + ' text-right'} title="5.5% of insurable basic salary — the worker's mandatory SSNIT deduction">SSNIT T1 (₵)</th>
                <th className={thCls + ' text-right'} title="Mandatory 5% Tier 2 allocation — funded inside the combined 18.5% remittance, not deducted from the worker">SSNIT T2 (₵)</th>
                <th className={thCls + ' text-right'}>Taxable (₵)</th>
                <th className={thCls + ' text-right'}>PAYE Tax (₵)</th>
                <th className={thCls + ' text-right'}>Other Ded. (₵)</th>
                <th className={thCls + ' text-right'}>Net Salary (₵)</th>
                <th className={thCls + ' text-center'}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {currentMonthRecords.map((r) => (
                <tr key={r.employeeId} className={rowCls}>
                  <td className="px-3 py-2 font-mono font-bold text-[#855b00]">{r.bpNo}</td>
                  <td className="px-3 py-2 font-bold text-[#082f4f]">
                    {r.name}
                    <div className="text-[10.5px] font-normal text-[#2d4f6d]">
                      {r.role} ({r.department}) · <span className="font-mono font-bold text-[#855b00]">{employees.find((e) => e.id === r.employeeId)?.costCenter || 'CC-HR'}</span>
                    </div>
                  </td>
                  <td className="px-3 py-2 text-[10.5px]">
                    <div className="flex flex-wrap gap-1">
                      <span
                        className={`rounded px-1.5 py-0.2 font-bold ${
                          r.isResident ? 'bg-sky-100 text-[#006f98]' : 'bg-purple-100 text-[#6d3fb3]'
                        }`}
                      >
                        {r.isResident ? 'Resident' : 'Non-Resident (20%)'}
                      </span>
                      {r.exemptTier1 && (
                        <span className="rounded bg-rose-100 text-rose-800 px-1 py-0.2 font-mono">
                          No T1
                        </span>
                      )}
                      {r.exemptTier2 && (
                        <span className="rounded bg-rose-100 text-rose-800 px-1 py-0.2 font-mono">
                          No T2
                        </span>
                      )}
                    </div>
                  </td>
                  <td className={numCls}>{formatGHS(r.basicSalary)}</td>
                  <td className={numCls}>{formatGHS(r.allowances)}</td>
                  <td className={numCls + ' font-bold text-[#082f4f]'}>{formatGHS(r.grossPay)}</td>
                  <td className={numCls + ' text-emerald-700'}>
                    {r.taxRelief > 0 ? `(${formatGHS(r.taxRelief)})` : '—'}
                  </td>
                  <td className={numCls + ' text-[#2d4f6d]'} title="5.5% of basic (insurable band ₵587.80 – ₵69,000)">{formatGHS(r.ssnitTier1Employee)}</td>
                  <td className={numCls + ' text-[#2d4f6d]'} title="Mandatory Tier 2 5% — allocated from the 18.5% combined remittance to the Tier 2 trustee">{formatGHS(r.ssnitTier2Allocation)}</td>
                  <td className={numCls + ' font-bold text-[#006f98]'}>{formatGHS(r.taxableIncome)}</td>
                  <td className={numCls + ' text-rose-700 font-bold'}>{formatGHS(r.payeTax)}</td>
                  <td className={numCls + ' text-[#855b00]'}>
                    {r.totalCustomDeductions > 0 ? `(${formatGHS(r.totalCustomDeductions)})` : '—'}
                  </td>
                  <td className={numCls + ' font-black text-emerald-800 text-sm'}>
                    ₵{formatGHS(r.netSalary)}
                  </td>
                  <td className="px-3 py-2 text-center">
                    <div className="flex items-center justify-center gap-1.5">
                      <button
                        onClick={() => {
                          const baseEmp = employees.find((e) => e.id === r.employeeId);
                          if (baseEmp) setEditingEmployee(baseEmp);
                        }}
                        disabled={isPeriodPostedInJournal || isPeriodClosed}
                        className="rounded border border-sky-300 bg-sky-50 px-2 py-1 text-[11px] font-bold text-[#082f4f] hover:bg-sky-100 transition disabled:opacity-40"
                        title="Edit Monthly Pay, Reliefs & Deductions"
                      >
                        <Edit3 className="h-3 w-3 inline mr-1" />
                        <span>Edit</span>
                      </button>
                      <button
                        onClick={() => setSelectedPayslipRecord(r)}
                        className="rounded border border-sky-300 bg-white px-2 py-1 text-[11px] font-bold text-[#082f4f] hover:bg-sky-50 transition"
                        title="Print / View Official Payslip"
                      >
                        <Printer className="h-3 w-3 inline mr-1" />
                        <span>Payslip</span>
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
              <tr className="bg-sky-100 font-bold border-t-2 border-sky-300">
                <td colSpan={3} className="px-3 py-2.5 text-[#082f4f]">
                  Total Payroll Expenditure for Period {selectedPeriod}
                </td>
                <td className="px-3 py-2.5 text-right font-mono font-bold">
                  ₵{formatGHS(currentMonthRecords.reduce((s, r) => s + r.basicSalary, 0))}
                </td>
                <td className="px-3 py-2.5 text-right font-mono font-bold">
                  ₵{formatGHS(currentMonthRecords.reduce((s, r) => s + r.allowances, 0))}
                </td>
                <td className="px-3 py-2.5 text-right font-mono font-black text-[#082f4f]">
                  ₵{formatGHS(totalGrossWageBill)}
                </td>
                <td className="px-3 py-2.5 text-right font-mono text-emerald-800">
                  (₵{formatGHS(currentMonthRecords.reduce((s, r) => s + r.taxRelief, 0))})
                </td>
                <td className="px-3 py-2.5 text-right font-mono font-bold">
                  ₵{formatGHS(currentMonthRecords.reduce((s, r) => s + r.ssnitTier1Employee, 0))}
                </td>
                <td className="px-3 py-2.5 text-right font-mono font-bold">
                  ₵{formatGHS(currentMonthRecords.reduce((s, r) => s + r.ssnitTier2Allocation, 0))}
                </td>
                <td className="px-3 py-2.5 text-right font-mono font-bold text-[#006f98]">
                  ₵{formatGHS(currentMonthRecords.reduce((s, r) => s + r.taxableIncome, 0))}
                </td>
                <td className="px-3 py-2.5 text-right font-mono font-black text-rose-800">
                  ₵{formatGHS(totalPAYETax)}
                </td>
                <td className="px-3 py-2.5 text-right font-mono text-[#855b00]">
                  (₵{formatGHS(totalOtherDeductions)})
                </td>
                <td className="px-3 py-2.5 text-right font-mono font-black text-emerald-800 text-sm">
                  ₵{formatGHS(totalNetSalariesPayable)}
                </td>
                <td className="px-3 py-2.5 text-center text-xs font-mono font-bold text-[#2d4f6d]">
                  ₵{formatGHS(totalEmployerSSNITCost)} Er
                </td>
              </tr>
            </tbody>
          </table>
        </div>
        <p className="mt-2 text-[10.5px] text-[#355875]">
          SSNIT columns are on basic salary (2026 insurable band ₵587.80 – ₵69,000). T1 = the worker&rsquo;s 5.5% deduction;
          T2 = the mandatory 5% Tier 2 allocation funded inside the combined 18.5% (13.5% → SSNIT incl. 2.5% → NHIA; 5% →
          Tier 2 trustee). The employer&rsquo;s 13% is an on-cost shown in the totals row and is never deducted from the worker.
        </p>
      </Card>

      {/* Edit Monthly Payroll Overrides Modal */}
      {editingEmployee && (
        <EditMonthlyEmployeeModal
          employee={editingEmployee}
          period={selectedPeriod}
          initialOverride={monthlyOverrides[editingEmployee.id]}
          onSave={(updatedOverride) => {
            setMonthlyOverrides({
              ...monthlyOverrides,
              [editingEmployee.id]: updatedOverride,
            });
            setEditingEmployee(null);
          }}
          onClose={() => setEditingEmployee(null)}
        />
      )}

      {/* Official Printable Payslip Modal */}
      {selectedPayslipRecord && (
        <PrintablePayslipModal
          record={selectedPayslipRecord}
          client={currentClient}
          onClose={() => setSelectedPayslipRecord(null)}
        />
      )}

      {/* Add Employee Master Modal */}
      {showAddEmpModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 overflow-y-auto">
          <form
            onSubmit={handleCreateEmployee}
            className="w-full max-w-lg rounded-xl border border-sky-300 bg-white p-6 shadow-xl space-y-4 text-xs"
          >
            <h3 className="text-base font-bold text-[#082f4f] border-b border-sky-100 pb-2">
              Enroll New Employee Master
            </h3>

            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-[#0a253e] mb-1">Employee Full Name</label>
                  <input
                    type="text"
                    value={empName}
                    onChange={(e) => setEmpName(e.target.value)}
                    className="w-full rounded border border-sky-300 px-3 py-1.5 outline-none font-bold text-[#082f4f]"
                    required
                  />
                </div>
                <div>
                  <label className="block font-bold text-[#0a253e] mb-1">Designation / Role</label>
                  <input
                    type="text"
                    value={empRole}
                    onChange={(e) => setEmpRole(e.target.value)}
                    className="w-full rounded border border-sky-300 px-3 py-1.5 outline-none font-bold text-[#082f4f]"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-[#0a253e] mb-1">Department</label>
                  <select
                    value={empDept}
                    onChange={(e) => { setEmpDept(e.target.value); setEmpCostCentre(defaultCostCentreForDepartment(e.target.value)); }}
                    className="w-full rounded border border-sky-300 px-2 py-1.5 outline-none font-semibold text-[#082f4f]"
                  >
                    <option value="Operations">Operations / Site</option>
                    <option value="Finance">Finance &amp; Admin</option>
                    <option value="Logistics">Logistics &amp; Transport</option>
                    <option value="Engineering">Plant &amp; Engineering</option>
                    <option value="Executive">Executive / Management</option>
                  </select>
                </div>
                <div>
                  <label className="block font-bold text-[#0a253e] mb-1">Cost Centre (payroll cost allocation)</label>
                  <select
                    value={empCostCentre}
                    onChange={(e) => setEmpCostCentre(e.target.value)}
                    className="w-full rounded border border-sky-300 px-2 py-1.5 outline-none font-semibold text-[#082f4f]"
                    required
                  >
                    {COST_CENTRES.map((c) => (
                      <option key={c.code} value={c.code}>{c.code} · {c.name}</option>
                    ))}
                  </select>
                  <span className="mt-1 block text-[10.5px] font-semibold text-[#355875]">
                    Gross pay, employer SSNIT and provisions for this employee are charged to this centre.
                  </span>
                </div>
                <div>
                  <label className="block font-bold text-[#0a253e] mb-1">Residency Status</label>
                  <select
                    value={empResident ? 'resident' : 'non-resident'}
                    onChange={(e) => setEmpResident(e.target.value === 'resident')}
                    className="w-full rounded border border-sky-300 px-2 py-1.5 outline-none font-semibold text-[#082f4f]"
                  >
                    <option value="resident">Resident (Ghana Progressive PAYE)</option>
                    <option value="non-resident">Non-Resident (Flat 20% Tax)</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-[#0a253e] mb-1">Monthly Basic Salary (₵)</label>
                  <input
                    type="number"
                    min="1"
                    step="0.01"
                    value={empBasic}
                    onChange={(e) => setEmpBasic(Number(e.target.value))}
                    className="w-full rounded border border-sky-300 px-3 py-1.5 outline-none font-mono font-bold text-[#082f4f]"
                    required
                  />
                </div>
                <div>
                  <label className="block font-bold text-[#0a253e] mb-1">Allowances (₵)</label>
                  <input
                    type="number"
                    min="0"
                    step="0.01"
                    value={empAllowances}
                    onChange={(e) => setEmpAllowances(Number(e.target.value))}
                    className="w-full rounded border border-sky-300 px-3 py-1.5 outline-none font-mono font-bold text-[#082f4f]"
                  />
                </div>
              </div>

              {/* Statutory Exemption Toggles */}
              <div className="rounded-lg bg-sky-50 p-3 border border-sky-200 space-y-2">
                <span className="block font-bold text-[#082f4f] text-[11px] uppercase tracking-wider">
                  Statutory Pension Exemptions:
                </span>
                <div className="flex items-center gap-6">
                  <label className="flex items-center gap-2 cursor-pointer font-semibold text-[#2d4f6d]">
                    <input
                      type="checkbox"
                      checked={empExemptT1}
                      onChange={(e) => setEmpExemptT1(e.target.checked)}
                      className="rounded border-sky-300 text-[#082f4f]"
                    />
                    <span>Exempt Tier 1 (5.5%)</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer font-semibold text-[#2d4f6d]">
                    <input
                      type="checkbox"
                      checked={empExemptT2}
                      onChange={(e) => setEmpExemptT2(e.target.checked)}
                      className="rounded border-sky-300 text-[#082f4f]"
                    />
                    <span>Exempt Tier 2 (5.0%)</span>
                  </label>
                </div>
                <label className="flex items-center gap-2 cursor-pointer font-semibold text-[#2d4f6d]">
                  <input
                    type="checkbox"
                    checked={empSsnitExempt}
                    onChange={(e) => setEmpSsnitExempt(e.target.checked)}
                    className="rounded border-sky-300 text-[#082f4f]"
                  />
                  <span>Exempt from SSNIT (all tiers)</span>
                </label>
                {empSsnitExempt && (
                  <input
                    type="text"
                    value={empSsnitExemptionReason}
                    onChange={(e) => setEmpSsnitExemptionReason(e.target.value)}
                    placeholder="Documented exemption reason"
                    className="w-full rounded border border-sky-300 px-3 py-1.5 outline-none"
                  />
                )}
              </div>

              {/* Monthly Tax Relief */}
              <div className="grid grid-cols-2 gap-3 bg-sky-50 p-3 rounded-lg border border-sky-200">
                <div>
                  <label className="block font-bold text-[#0a253e] mb-1">Monthly Tax Relief (₵)</label>
                  <input
                    type="number"
                    min="0"
                    step="0.01"
                    value={empRelief}
                    onChange={(e) => setEmpRelief(Number(e.target.value))}
                    placeholder="e.g. 200.00"
                    className="w-full rounded border border-sky-300 px-3 py-1.5 outline-none font-mono font-bold text-[#082f4f]"
                  />
                </div>
                <div>
                  <label className="block font-bold text-[#0a253e] mb-1">Relief Type</label>
                  <select
                    value={empReliefType}
                    onChange={(e) => setEmpReliefType(e.target.value)}
                    className="w-full rounded border border-sky-300 px-2 py-1.5 outline-none font-semibold text-[#082f4f]"
                  >
                    <option value="Marriage & Child Relief">Marriage &amp; Child Relief</option>
                    <option value="Elderly / Old Age Relief">Elderly / Old Age (60+ yrs)</option>
                    <option value="Disability Relief">Disability Relief</option>
                    <option value="Standard Personal Relief">Standard Personal Relief</option>
                  </select>
                </div>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-sky-100">
              <button
                type="button"
                onClick={() => setShowAddEmpModal(false)}
                className="rounded px-3 py-1.5 font-semibold text-[#2d4f6d]"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="rounded bg-[#082f4f] px-4 py-1.5 font-bold text-white hover:bg-[#0c3f68]"
              >
                Enroll Employee
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};

/**
 * Interactive Modal for editing an individual employee's monthly payroll:
 * - Overrides Basic, Allowances, and Bonus additions for that specific month.
 * - Toggles Resident vs Non-Resident.
 * - Toggles Tier 1 & Tier 2 SSNIT exemptions.
 * - Sets allowable tax relief (e.g. Marriage, Child, Disability, etc.).
 * - Configures custom deductions calculated on Gross, Basic, or Net.
 */
function EditMonthlyEmployeeModal({
  employee,
  period,
  initialOverride,
  onSave,
  onClose,
}: {
  employee: EmployeeProfile;
  period: string;
  initialOverride?: {
    basicSalary?: number;
    allowances?: number;
    bonusAdditions?: number;
    taxRelief?: number;
    reliefType?: string;
    isResident?: boolean;
    exemptTier1?: boolean;
    exemptTier2?: boolean;
    ssnitExempt?: boolean;
    ssnitExemptionReason?: string;
    deductions?: PayrollDeductionConfig[];
  };
  onSave: (override: any) => void;
  onClose: () => void;
}) {
  const [basic, setBasic] = useState(initialOverride?.basicSalary ?? employee.basicSalary);
  const [allowances, setAllowances] = useState(initialOverride?.allowances ?? employee.allowances);
  const [bonus, setBonus] = useState(initialOverride?.bonusAdditions ?? 0);
  const [isResident, setIsResident] = useState(initialOverride?.isResident ?? employee.isResident ?? true);
  const [exemptT1, setExemptT1] = useState(initialOverride?.exemptTier1 ?? employee.exemptTier1 ?? false);
  const [exemptT2, setExemptT2] = useState(initialOverride?.exemptTier2 ?? employee.exemptTier2 ?? false);
  const [ssnitExempt, setSsnitExempt] = useState(initialOverride?.ssnitExempt ?? employee.ssnitExempt ?? false);
  const [ssnitExemptionReason, setSsnitExemptionReason] = useState(initialOverride?.ssnitExemptionReason ?? employee.ssnitExemptionReason ?? '');
  const [relief, setRelief] = useState(initialOverride?.taxRelief ?? employee.taxRelief ?? 0);
  const [reliefType, setReliefType] = useState(initialOverride?.reliefType ?? employee.reliefType ?? 'Marriage & Child Relief');
  const [deductions, setDeductions] = useState<PayrollDeductionConfig[]>(
    initialOverride?.deductions ?? employee.deductions ?? []
  );

  // New deduction form input
  const [newDedName, setNewDedName] = useState('');
  const [newDedBase, setNewDedBase] = useState<'gross' | 'basic' | 'net'>('basic');
  const [newDedPct, setNewDedPct] = useState<number>(0);
  const [newDedFixed, setNewDedFixed] = useState<number>(0);

  // Live preview calculation
  const livePreview = computeEmployeeMonthlyPayroll({
    employee,
    period,
    basicSalary: basic,
    allowances,
    bonusAdditions: bonus,
    taxRelief: relief,
    reliefType,
    isResident,
    exemptTier1: exemptT1,
    exemptTier2: exemptT2,
    ssnitExempt,
    ssnitExemptionReason,
    deductions,
  });

  const handleAddDeduction = () => {
    if (!newDedName) return;
    const newD: PayrollDeductionConfig = {
      id: `${uniqueId('D')}`,
      name: newDedName.trim(),
      base: newDedBase,
      ratePct: newDedPct > 0 ? newDedPct : undefined,
      fixedAmount: newDedFixed || 0,
    };
    setDeductions([...deductions, newD]);
    setNewDedName('');
    setNewDedPct(0);
    setNewDedFixed(0);
  };

  const handleRemoveDeduction = (id: string) => {
    setDeductions(deductions.filter((d) => d.id !== id));
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      basicSalary: Number(basic),
      allowances: Number(allowances),
      bonusAdditions: Number(bonus),
      taxRelief: Number(relief),
      reliefType,
      isResident,
      exemptTier1: exemptT1,
      exemptTier2: exemptT2,
      ssnitExempt,
      ssnitExemptionReason,
      deductions,
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 overflow-y-auto">
      <form
        onSubmit={handleSave}
        className="w-full max-w-2xl rounded-2xl bg-white p-6 shadow-2xl space-y-5 text-xs text-[#0a253e]"
      >
        <div className="flex items-center justify-between border-b border-sky-200 pb-3">
          <div>
            <h3 className="text-base font-extrabold text-[#082f4f]">
              Edit Monthly Payroll — {employee.name} ({employee.bpNo})
            </h3>
            <span className="text-[11px] text-[#2d4f6d]">
              Fiscal Month: <strong className="font-mono text-[#855b00]">{period}</strong> · Role: {employee.role}
            </span>
          </div>
          <button type="button" onClick={onClose} className="text-slate-400 hover:text-black text-xl font-bold p-1">
            &times;
          </button>
        </div>

        {/* Live Calculation Preview Banner */}
        <div className="rounded-xl border border-sky-300 bg-sky-50/70 p-4 grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
          <div>
            <span className="text-[10px] uppercase font-bold text-[#355875] block">Gross Earnings</span>
            <span className="font-mono text-base font-black text-[#082f4f]">₵{formatGHS(livePreview.grossPay)}</span>
          </div>
          <div>
            <span className="text-[10px] uppercase font-bold text-[#355875] block">PAYE Income Tax</span>
            <span className="font-mono text-base font-black text-rose-700">₵{formatGHS(livePreview.payeTax)}</span>
          </div>
          <div>
            <span className="text-[10px] uppercase font-bold text-[#355875] block">Total Deductions</span>
            <span className="font-mono text-base font-black text-[#855b00]">₵{formatGHS(livePreview.totalEmployeeDeductions)}</span>
          </div>
          <div>
            <span className="text-[10px] uppercase font-bold text-[#355875] block">Net Pay to Disburse</span>
            <span className="font-mono text-base font-black text-emerald-800">₵{formatGHS(livePreview.netSalary)}</span>
          </div>
        </div>

        {/* Earnings Inputs */}
        <div className="space-y-3">
          <span className="block font-bold text-[#082f4f] uppercase tracking-wider text-[11px]">
            1. Monthly Gross Earnings
          </span>
          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block font-semibold mb-1 text-[#2d4f6d]">Basic Salary (₵)</label>
              <input
                type="number"
                step="0.01"
                value={basic}
                onChange={(e) => setBasic(Number(e.target.value))}
                className="w-full rounded border border-sky-300 px-3 py-1.5 outline-none font-mono font-bold text-[#082f4f]"
                required
              />
            </div>
            <div>
              <label className="block font-semibold mb-1 text-[#2d4f6d]">Allowances (₵)</label>
              <input
                type="number"
                step="0.01"
                value={allowances}
                onChange={(e) => setAllowances(Number(e.target.value))}
                className="w-full rounded border border-sky-300 px-3 py-1.5 outline-none font-mono font-bold text-[#082f4f]"
              />
            </div>
            <div>
              <label className="block font-semibold mb-1 text-[#2d4f6d]">Bonus / Overtime (₵)</label>
              <input
                type="number"
                step="0.01"
                value={bonus}
                onChange={(e) => setBonus(Number(e.target.value))}
                className="w-full rounded border border-sky-300 px-3 py-1.5 outline-none font-mono font-bold text-[#082f4f]"
              />
            </div>
          </div>
        </div>

        {/* Statutory Residency, Exemptions & Reliefs */}
        <div className="space-y-3">
          <span className="block font-bold text-[#082f4f] uppercase tracking-wider text-[11px]">
            2. Statutory Regime, Exemptions &amp; Tax Reliefs
          </span>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold mb-1 text-[#2d4f6d]">Tax Residency Status</label>
              <select
                value={isResident ? 'resident' : 'non_resident'}
                onChange={(e) => setIsResident(e.target.value === 'resident')}
                className="w-full rounded border border-sky-300 px-2 py-1.5 outline-none font-bold text-[#082f4f]"
              >
                <option value="resident">Resident Individual (Ghana Progressive PAYE)</option>
                <option value="non_resident">Non-Resident Individual (Flat 20% on Gross)</option>
              </select>
            </div>
            <div className="flex items-center gap-4 pt-5">
              <label className="flex items-center gap-1.5 cursor-pointer font-semibold text-[#2d4f6d]">
                <input
                  type="checkbox"
                  checked={exemptT1}
                  onChange={(e) => setExemptT1(e.target.checked)}
                  className="rounded border-sky-300"
                />
                <span>Exempt Tier 1 (5.5%)</span>
              </label>
              <label className="flex items-center gap-1.5 cursor-pointer font-semibold text-[#2d4f6d]">
                <input
                  type="checkbox"
                  checked={exemptT2}
                  onChange={(e) => setExemptT2(e.target.checked)}
                  className="rounded border-sky-300"
                />
                <span>Exempt Tier 2 (5.0%)</span>
              </label>
            </div>
            <label className="flex items-center gap-2 cursor-pointer font-semibold text-[#2d4f6d]">
              <input
                type="checkbox"
                checked={ssnitExempt}
                onChange={(e) => setSsnitExempt(e.target.checked)}
                className="rounded border-sky-300"
              />
              <span>Exempt from SSNIT for this payroll month (all tiers)</span>
            </label>
            {ssnitExempt && (
              <input
                type="text"
                value={ssnitExemptionReason}
                onChange={(e) => setSsnitExemptionReason(e.target.value)}
                placeholder="Documented SSNIT exemption reason"
                className="w-full rounded border border-sky-300 px-3 py-1.5 outline-none"
              />
            )}
          </div>

          {isResident && (
            <div className="grid grid-cols-2 gap-3 bg-sky-50 p-3 rounded-lg border border-sky-200">
              <div>
                <label className="block font-semibold mb-1 text-[#2d4f6d]">Allowable Tax Relief (₵/month)</label>
                <input
                  type="number"
                  step="0.01"
                  value={relief}
                  onChange={(e) => setRelief(Number(e.target.value))}
                  placeholder="e.g. 250.00"
                  className="w-full rounded border border-sky-300 px-3 py-1.5 outline-none font-mono font-bold text-[#082f4f]"
                />
              </div>
              <div>
                <label className="block font-semibold mb-1 text-[#2d4f6d]">Relief Category / Type</label>
                <select
                  value={reliefType}
                  onChange={(e) => setReliefType(e.target.value)}
                  className="w-full rounded border border-sky-300 px-2 py-1.5 outline-none font-semibold text-[#082f4f]"
                >
                  <option value="Marriage & Child Relief">Marriage &amp; Child Education Relief</option>
                  <option value="Elderly / Old Age Relief">Elderly / Old Age Relief (60+ years)</option>
                  <option value="Disability Relief">Disability Exemption Relief</option>
                  <option value="Cost of Training">Cost of Professional Training Relief</option>
                  <option value="Custom Personal Relief">Custom Personal Relief</option>
                </select>
              </div>
            </div>
          )}
        </div>

        {/* Deductions Configured on Gross, Basic, or Net */}
        <div className="space-y-3">
          <span className="block font-bold text-[#082f4f] uppercase tracking-wider text-[11px]">
            3. Voluntary &amp; Non-Statutory Deductions (Configurable on Gross, Basic, or Net)
          </span>

          {deductions.length > 0 && (
            <div className="space-y-1.5 border border-sky-200 rounded-lg p-2.5 bg-white">
              {deductions.map((d) => (
                <div
                  key={d.id}
                  className="flex items-center justify-between bg-sky-50 px-3 py-1.5 rounded text-[11.5px]"
                >
                  <div>
                    <strong className="text-[#082f4f]">{d.name}</strong>{' '}
                    <span className="text-[#355875]">
                      (Deducted on <strong className="uppercase">{d.base}</strong>: {d.ratePct ? `${d.ratePct}%` : ''} {d.fixedAmount ? `+ ₵${d.fixedAmount}` : ''})
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => handleRemoveDeduction(d.id)}
                    className="text-rose-600 hover:text-rose-800 p-1"
                    title="Remove Deduction"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>
              ))}
            </div>
          )}

          {/* Add New Deduction Form Strip */}
          <div className="p-3 bg-sky-50/70 border border-sky-200 rounded-lg space-y-2">
            <span className="font-bold text-[#355875] text-[10.5px] uppercase">Add New Deduction Component:</span>
            <div className="grid grid-cols-4 gap-2">
              <input
                type="text"
                placeholder="Name (e.g. Staff Loan)"
                value={newDedName}
                onChange={(e) => setNewDedName(e.target.value)}
                className="rounded border border-sky-300 px-2 py-1 outline-none"
              />
              <select
                value={newDedBase}
                onChange={(e) => setNewDedBase(e.target.value as any)}
                className="rounded border border-sky-300 px-1.5 py-1 outline-none font-bold"
              >
                <option value="basic">On Basic Salary</option>
                <option value="gross">On Gross Pay</option>
                <option value="net">On Net Salary</option>
              </select>
              <input
                type="number"
                step="0.1"
                placeholder="Rate %"
                value={newDedPct || ''}
                onChange={(e) => setNewDedPct(Number(e.target.value))}
                className="rounded border border-sky-300 px-2 py-1 outline-none font-mono"
              />
              <div className="flex gap-1.5">
                <input
                  type="number"
                  step="0.01"
                  placeholder="Fixed (₵)"
                  value={newDedFixed || ''}
                  onChange={(e) => setNewDedFixed(Number(e.target.value))}
                  className="rounded border border-sky-300 px-2 py-1 outline-none font-mono flex-1"
                />
                <button
                  type="button"
                  onClick={handleAddDeduction}
                  className="rounded bg-[#082f4f] px-2.5 py-1 text-white font-bold"
                >
                  Add
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Modal Action Buttons */}
        <div className="flex justify-end gap-2 pt-3 border-t border-sky-100">
          <button
            type="button"
            onClick={onClose}
            className="rounded px-4 py-2 font-semibold text-[#2d4f6d] hover:bg-sky-50"
          >
            Cancel
          </button>
          <button
            type="submit"
            className="flex items-center gap-1.5 rounded-lg bg-[#082f4f] px-5 py-2 font-bold text-white hover:bg-[#0c3f68]"
          >
            <Save className="h-4 w-4" />
            <span>Apply &amp; Save for {period}</span>
          </button>
        </div>
      </form>
    </div>
  );
}

/**
 * Official Printable Payslip Modal
 */
function PrintablePayslipModal({
  record,
  client,
  onClose,
}: {
  record: MonthlyPayrollRecord;
  client: ClientEntity;
  onClose: () => void;
}) {
  const companyProfile = persistentStorage.getCompanyProfiles()[client.id] || {
    legalName: client.name,
    address: 'Accra, Ghana',
    tin: 'P0094812201',
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 overflow-y-auto">
      <div className="w-full max-w-xl rounded-2xl bg-white p-6 sm:p-8 shadow-2xl space-y-6 text-[#082f4f]">
        {/* Action Bar */}
        <div className="flex items-center justify-between border-b border-sky-200 pb-3 no-print">
          <span className="text-xs font-bold uppercase tracking-wider text-[#355875]">Official Monthly Payslip</span>
          <div className="flex gap-2">
            <button
              onClick={() => window.print()}
              className="flex items-center gap-1.5 rounded-lg bg-[#082f4f] px-3.5 py-1.5 text-xs font-bold text-white hover:bg-[#0c3f68]"
            >
              <Printer className="h-4 w-4" />
              <span>Print Payslip</span>
            </button>
            <button
              onClick={onClose}
              className="rounded-lg border border-sky-300 px-3 py-1.5 text-xs font-bold text-[#2d4f6d] hover:bg-sky-50"
            >
              Close
            </button>
          </div>
        </div>

        {/* Payslip Header */}
        <div className="flex justify-between items-start border-b border-sky-200 pb-4">
          <div>
            <h2 className="text-base font-black text-[#082f4f]">{companyProfile.legalName}</h2>
            <p className="text-xs text-[#2d4f6d]">{companyProfile.address}</p>
            <div className="text-[11px] font-mono text-[#355875]">TIN: {companyProfile.tin}</div>
          </div>
          <div className="text-right">
            <div className="inline-block rounded bg-sky-100 text-[#006f98] font-bold text-xs uppercase px-2 py-0.5 mb-1">
              PAYSLIP
            </div>
            <div className="font-mono text-sm font-extrabold text-[#082f4f]">Period: {record.period}</div>
            <div className="text-xs text-[#2d4f6d]">Status: {record.status}</div>
          </div>
        </div>

        {/* Employee Info Box */}
        <div className="grid grid-cols-2 gap-3 bg-sky-50 p-3.5 rounded-xl border border-sky-200 text-xs">
          <div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-[#355875] block">Employee Name:</span>
            <strong className="text-sm text-[#082f4f]">{record.name}</strong>
            <div className="text-[11px] text-[#2d4f6d] font-mono">Code: {record.bpNo}</div>
          </div>
          <div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-[#355875] block">Designation / Role:</span>
            <strong className="text-sm text-[#082f4f]">{record.role}</strong>
            <div className="text-[11px] text-[#2d4f6d]">Department: {record.department}</div>
          </div>
        </div>

        {/* Earnings & Deductions Tables */}
        <div className="grid grid-cols-2 gap-4 text-xs">
          {/* Earnings */}
          <div className="space-y-2 border border-sky-200 rounded-xl p-3 bg-white">
            <span className="font-bold text-[#082f4f] uppercase tracking-wider text-[11px] block border-b border-sky-100 pb-1">
              Gross Earnings
            </span>
            <div className="space-y-1 font-mono text-[11.5px]">
              <div className="flex justify-between">
                <span>Basic Salary:</span>
                <span>₵{formatGHS(record.basicSalary)}</span>
              </div>
              <div className="flex justify-between">
                <span>Allowances:</span>
                <span>₵{formatGHS(record.allowances)}</span>
              </div>
              {record.bonusAdditions > 0 && (
                <div className="flex justify-between">
                  <span>Bonus Additions:</span>
                  <span>₵{formatGHS(record.bonusAdditions)}</span>
                </div>
              )}
              <div className="flex justify-between border-t border-sky-200 pt-1 font-bold text-[#082f4f]">
                <span>Total Gross Pay:</span>
                <span>₵{formatGHS(record.grossPay)}</span>
              </div>
            </div>
          </div>

          {/* Deductions */}
          <div className="space-y-2 border border-sky-200 rounded-xl p-3 bg-white">
            <span className="font-bold text-rose-800 uppercase tracking-wider text-[11px] block border-b border-sky-100 pb-1">
              Deductions
            </span>
            <div className="space-y-1 font-mono text-[11.5px]">
              <div className="flex justify-between" title="Mandatory 5.5% of insurable basic salary (2026 band ₵587.80 – ₵69,000)">
                <span>SSNIT Pension (5.5% of basic):</span>
                <span>₵{formatGHS(record.ssnitTier1Employee)}</span>
              </div>
              <div className="flex justify-between text-[10.5px] text-[#355875]">
                <span>Tier 2 (5%) → trustee:</span>
                <span>₵{formatGHS(record.ssnitTier2Allocation)} (in 18.5%)</span>
              </div>
              <div className="flex justify-between text-rose-700 font-bold">
                <span>PAYE Income Tax:</span>
                <span>₵{formatGHS(record.payeTax)}</span>
              </div>
              {record.customDeductions.map((d) => (
                <div key={d.id} className="flex justify-between text-[#855b00]">
                  <span>{d.name}:</span>
                  <span>₵{formatGHS(d.amount)}</span>
                </div>
              ))}
              <div className="flex justify-between border-t border-sky-200 pt-1 font-bold text-rose-800">
                <span>Total Deductions:</span>
                <span>(₵{formatGHS(record.totalEmployeeDeductions)})</span>
              </div>
            </div>
          </div>
        </div>

        {/* Statutory pension remittance note */}
        <div className="rounded-lg bg-emerald-50 border border-emerald-200 p-3 text-[10.5px] text-[#2d4f6d] leading-relaxed">
          <strong className="text-[#082f4f]">Statutory pension remittance (18.5% of basic ₵{formatGHS(record.ssnitInsurableBase)}):</strong>{' '}
          Employee 5.5% ₵{formatGHS(record.ssnitTier1Employee)} + Employer 13% ₵{formatGHS(record.ssnitEmployerCost)}.
          Remitted within 14 days after month end: 13.5% (₵{formatGHS(record.ssnitTier1Allocation)}) to SSNIT Tier 1 —
          incl. 2.5% (₵{formatGHS(record.nhiaRemittance)}) forwarded to NHIA — and the mandatory 5% (₵{formatGHS(record.ssnitTier2Allocation)}) to the Tier 2 occupational trustee.
          The Tier 2 5% is part of the 18.5% and is not a separate deduction from this salary.
        </div>

        {/* Net Take-Home Pay Box */}
        <div className="rounded-xl bg-emerald-50 border-2 border-emerald-300 p-4 flex items-center justify-between">
          <div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-900 block">
              Net Take-Home Salary (Disbursed to Bank):
            </span>
            <span className="text-xs text-emerald-800 font-medium">Direct Bank Electronic Transfer</span>
          </div>
          <div className="font-mono text-2xl font-black text-emerald-900">
            ₵{formatGHS(record.netSalary)}
          </div>
        </div>

        {/* Signatures */}
        <div className="grid grid-cols-2 gap-6 pt-4 border-t border-sky-200 text-center text-xs">
          <div className="border-t border-slate-300 pt-1">
            <span className="block text-[10px] text-[#355875] uppercase font-bold">Prepared By Payroll Officer</span>
          </div>
          <div className="border-t border-slate-300 pt-1">
            <span className="block text-[10px] text-[#355875] uppercase font-bold">Employee Signature &amp; Date</span>
          </div>
        </div>
      </div>
    </div>
  );
}
