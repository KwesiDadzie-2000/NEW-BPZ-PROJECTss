import { scrypt as _scrypt, randomBytes, timingSafeEqual } from "node:crypto";
import { promisify } from "node:util";

/**
 * Server-side password storage.
 *
 * ITGC requirement (Big Four / SOC 2 / ISO 27001): credentials must be protected
 * by a deliberately slow, memory-hard key-derivation function — a bare SHA-256
 * digest is GPU-brute-forceable and is a reportable control deficiency.
 *
 * Current scheme:  scrypt(N=16384, r=8, p=1, 64-byte key), per-user 16-byte salt.
 * Stored hash format: `s2$<hex key>`.
 *
 * Legacy scheme:   bare SHA-256(password + salt) hex, written by earlier builds.
 * These verify successfully and are transparently re-hashed to scrypt on the
 * next successful login (see `needsRehash`), so no user is ever locked out.
 */

const scrypt = promisify(_scrypt) as (
  password: string,
  salt: string,
  keylen: number,
) => Promise<Buffer>;

export const SCRYPT_PREFIX = "s2$";
const KEY_LEN = 64;

async function scryptHex(password: string, salt: string): Promise<string> {
  const key = await scrypt(password, salt, KEY_LEN);
  return key.toString("hex");
}

/** Hashes a password with the current (scrypt) scheme. */
export async function hashPassword(password: string, salt: string): Promise<string> {
  return `${SCRYPT_PREFIX}${await scryptHex(password, salt)}`;
}

export function newSalt(): string {
  return randomBytes(16).toString("hex");
}

/** Legacy digest kept only so historic hashes can still be verified. */
async function legacySha256(password: string, salt: string): Promise<string> {
  const data = new TextEncoder().encode(password + salt);
  const hash = await crypto.subtle.digest("SHA-256", data);
  return Array.from(new Uint8Array(hash))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

function constantTimeEqual(a: string, b: string): boolean {
  const bufA = Buffer.from(a, "utf8");
  const bufB = Buffer.from(b, "utf8");
  if (bufA.length !== bufB.length) return false;
  return timingSafeEqual(bufA, bufB);
}

/** True when a stored hash uses the superseded scheme and should be upgraded. */
export function needsRehash(expectedHash: string): boolean {
  return !expectedHash.startsWith(SCRYPT_PREFIX);
}

/** Verifies a password against either the current or the legacy stored hash. */
export async function verifyPassword(
  password: string,
  salt: string,
  expectedHash: string,
): Promise<boolean> {
  if (!password || !salt || !expectedHash) return false;
  if (expectedHash.startsWith(SCRYPT_PREFIX)) {
    return constantTimeEqual(await scryptHex(password, salt), expectedHash.slice(SCRYPT_PREFIX.length));
  }
  return constantTimeEqual(await legacySha256(password, salt), expectedHash);
}

/* ============================================================================
 * Password policy — enforced wherever a credential is set or changed.
 * ========================================================================== */
export const PASSWORD_MIN_LENGTH = 10;

export function passwordPolicyError(password: string): string | null {
  if (password.length < PASSWORD_MIN_LENGTH) return `Password must be at least ${PASSWORD_MIN_LENGTH} characters.`;
  if (!/[a-z]/.test(password)) return "Password must contain a lowercase letter.";
  if (!/[A-Z]/.test(password)) return "Password must contain an uppercase letter.";
  if (!/[0-9]/.test(password)) return "Password must contain a digit.";
  if (!/[^A-Za-z0-9]/.test(password)) return "Password must contain a symbol.";
  return null;
}
