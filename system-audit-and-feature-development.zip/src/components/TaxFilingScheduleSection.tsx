import { useState } from 'react';
import type { AccountMaster, ACDOCALine, ClientEntity, UserAccount } from '../types/accounting';
import { Card, PageHeader, Stat, formatGHS, thCls, numCls, rowCls } from './ui';
import { Calculator, Printer } from 'lucide-react';
import { aggregateTrialBalance, computeCit, sectorCitRate } from '../utils/reports';
import { uniqueId } from '../utils/ids';
import { printReport } from '../utils/printReport';
import { toPrintEntity } from '../utils/printEntity';
import { persistentStorage } from '../utils/persistentStorage';

export const TaxFilingScheduleSection = ({ currentClient, currentUser, lines, accounts = [], onAddJournalLines, isPeriodClosed = false, onOpenSchedules }: {
  currentClient: ClientEntity;
  currentUser?: UserAccount;
  lines: ACDOCALine[];
  accounts?: AccountMaster[];
  onAddJournalLines?: (lines: ACDOCALine[]) => boolean;
  isPeriodClosed?: boolean;
  onOpenSchedules?: () => void;
}) => {
  const [period, setPeriod] = useState(() => new Date().toISOString().slice(0, 7));
  const [citMsg, setCitMsg] = useState<string | null>(null);
  const entries = lines.filter(l => l.clientId === currentClient.id && l.period === period);
  const totals = (account: string) => entries.filter(l => l.accountNo === account).reduce((n, l) => n + Math.round((l.credit - l.debit) * 100), 0) / 100;
  const output = totals('220000');
  const input = -totals('125000');
  const wht = totals('209000');
  const paye = totals('207000');
  const pension = totals('206000');
  const tier2 = totals('206100');
  const categories = [
    ['Output VAT (ledger 220000)', output], ['Input VAT (ledger 125000)', input],
    ['Net VAT position', output - input], ['WHT payable (ledger 209000)', wht],
    ['PAYE payable (ledger 207000)', paye], ['SSNIT Tier 1 13.5% payable (ledger 206000)', pension],
    ['Tier 2 pension 5% payable (ledger 206100)', tier2],
  ] as const;

  // CIT working paper: period profit taxed at the sector CIT rate, less WHT credits.
  const rows = aggregateTrialBalance(entries, accounts);
  const profit = rows.filter(r => r.type === 'Income' || r.type === 'Expense').reduce((n, r) => n - (r.dr - r.cr), 0) / 100;
  const { rate, sectorName } = sectorCitRate(currentClient.sector);
  const cit = computeCit(profit, rate, wht);

  const postCitProvision = () => {
    if (!onAddJournalLines || cit.grossCit <= 0) return;
    const docNo = `CIT-${period}`;
    const today = new Date().toISOString().slice(0, 10);
    const ok = onAddJournalLines([
      { id: `${uniqueId('JL-CIT')}-1`, docNo, period, date: today, module: 'FI', docType: 'JE', accountNo: '730000', accountName: 'Income Tax Expense — Current CIT', costCenter: 'CC-ADM', debit: cit.grossCit, credit: 0, currency: currentClient.currency, description: `CIT provision for ${period} at ${rate}% (${sectorName})`, createdBy: currentUser?.username || 'tax_working_paper', clientId: currentClient.id },
      { id: `${uniqueId('JL-CIT')}-2`, docNo, period, date: today, module: 'FI', docType: 'JE', accountNo: '212000', accountName: 'Corporate Income Tax Payable (CIT)', costCenter: 'CC-ADM', debit: 0, credit: cit.grossCit, currency: currentClient.currency, description: `CIT payable for ${period}`, createdBy: currentUser?.username || 'tax_working_paper', clientId: currentClient.id },
    ]);
    setCitMsg(ok
      ? `CIT provision ${docNo} posted: ${formatGHS(cit.grossCit)} at ${rate}%.`
      : `CIT provision rejected. The period may be closed or document ${docNo} already exists.`);
    setTimeout(() => setCitMsg(null), 6000);
  };

  const print = () => printReport({
    kicker: 'Tax working paper', title: 'Statutory ledger reconciliation', subtitle: `Period-specific balances from posted journal entries · ${currentClient.currency}`,
    entity: toPrintEntity(currentClient, persistentStorage.getCompanyProfiles()[currentClient.id]), periodLabel: period, preparedBy: currentUser ? `${currentUser.name} (${currentUser.username})` : 'BPZ Consult',
    stats: [{ label: 'Profit before tax', value: profit }, { label: 'Sector CIT rate', value: `${rate}%` }, { label: 'Gross CIT', value: cit.grossCit }, { label: 'Net CIT payable', value: cit.netPayable }],
    sections: [
      { title: 'Ledger positions', columns: [{ key: 'name', label: 'Account position' }, { key: 'value', label: currentClient.currency, numeric: true, width: '22%' }], rows: categories.map(([name, value]) => ({ name, value })) },
      { title: `Corporate income tax working paper (${sectorName})`, columns: [{ key: 'name', label: 'Line' }, { key: 'value', label: currentClient.currency, numeric: true, width: '22%' }],
        rows: [{ name: 'Period profit before tax', value: profit }, { name: `Taxable profit`, value: cit.taxableProfit }, { name: `Gross CIT at ${rate}%`, value: cit.grossCit }, { name: 'Less: WHT credits (209000)', value: -cit.whtCredits }, { name: 'Net CIT payable', value: cit.netPayable }], emphasise: (i) => i === 4 },
    ],
    footerNote: 'Not a tax return. Verify rates and reconcile with source documents before filing.',
  });

  const exportCsv = () => {
    const csv = ['Account position,Amount', ...categories.map(([name, value]) => `"${name}",${value}`)].join('\r\n');
    const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv' }));
    const link = document.createElement('a'); link.href = url; link.download = `${currentClient.code}-${period}-reconciliation-DRAFT.csv`; link.click(); URL.revokeObjectURL(url);
  };
  return <div className="space-y-5">
    <PageHeader kicker="TAX WORKING PAPER" title="Statutory ledger reconciliation" desc="Period-specific amounts from posted journal entries only." />
    <div role="note" className="rounded border border-amber-400 bg-amber-50 p-3 text-sm text-amber-950">Not a tax return. Account balances do not establish tax eligibility, filing status, taxable turnover or statutory due dates. Verify rates and reconcile with source documents before filing.</div>
    <div className="flex flex-wrap gap-3 items-end bg-white border border-sky-200 p-4 rounded-xl">
      <label className="text-xs font-bold">Reporting month<input type="month" value={period} onChange={e => setPeriod(e.target.value)} className="block mt-1 p-2 border border-sky-300 rounded" /></label>
      <button onClick={exportCsv} className="bg-[#082f4f] text-white text-xs font-bold px-4 py-2 rounded">Export reconciliation (CSV)</button>
      <button onClick={print} className="flex items-center gap-1.5 rounded border border-sky-300 bg-white px-3 py-2 text-xs font-bold text-[#082f4f] hover:bg-sky-50"><Printer className="h-3.5 w-3.5" /> Print working paper</button>
      {onOpenSchedules && <button onClick={onOpenSchedules} className="text-xs underline text-[#082f4f]">Open WHT &amp; VAT schedules</button>}
    </div>
    <Card title={`Ledger positions - ${period}`} sub={`${entries.length} journal lines in this workspace and period`}>
      <table className="w-full text-xs"><thead><tr><th className={thCls}>Account position</th><th className={thCls + ' text-right'}>{currentClient.currency}</th></tr></thead><tbody>{categories.map(([name, value]) => <tr key={name} className={rowCls}><td className="p-3">{name}</td><td className={numCls}>{formatGHS(value)}</td></tr>)}</tbody></table>
    </Card>

    <Card title={`Corporate income tax working paper - ${period}`} sub={`Sector basis: ${sectorName}`} action={
      <button onClick={postCitProvision} disabled={!onAddJournalLines || cit.grossCit <= 0 || isPeriodClosed} className="flex items-center gap-1.5 rounded-lg bg-[#082f4f] px-3.5 py-2 text-xs font-bold text-white hover:bg-[#0c3f68] transition shadow-xs disabled:opacity-40">
        <Calculator className="h-3.5 w-3.5" />
        <span>Post CIT provision</span>
      </button>
    }>
      <div className="space-y-3 text-xs">
        {citMsg && <div className="rounded-lg border border-sky-300 bg-sky-50 p-2.5 font-bold text-[#082f4f]">{citMsg}</div>}
        <div className="grid grid-cols-2 gap-3 xl:grid-cols-4">
          <Stat label="Period profit before tax" value={formatGHS(profit)} sub="Income less expenses, posted lines" />
          <Stat label="Sector CIT rate" value={`${rate}%`} sub={sectorName} />
          <Stat label="Gross CIT" value={formatGHS(cit.grossCit)} sub={`${rate}% of taxable profit`} tone="text-[#082f4f]" />
          <Stat label="Net CIT payable" value={formatGHS(cit.netPayable)} sub={`After WHT credits of ${formatGHS(cit.whtCredits)}`} tone="text-emerald-700" />
        </div>
        <p className="text-[#2d4f6d] leading-relaxed">CIT is computed from posted journal lines at the sector rate for {currentClient.sector}. Withholding tax already deducted from the entity (ledger 209000) is credited against the CIT liability. Posting the provision debits 730000 and credits 212000; it does not file or pay anything.</p>
      </div>
    </Card>
  </div>;
};
