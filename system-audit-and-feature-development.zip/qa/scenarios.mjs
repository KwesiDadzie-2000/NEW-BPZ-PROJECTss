import puppeteer from 'puppeteer';
const BASE = process.env.BASE || 'http://127.0.0.1:3111';

async function snapshot(page) {
  return page.evaluate(() => ({
    loginVisible: !!document.querySelector('input[autocomplete="username"]'),
    heading: document.querySelector('h1')?.innerText?.slice(0, 50) || null,
    notice: document.body.innerText.match(/Your secure session ended[^\n]*/)?.[0]?.slice(0, 80) || null,
    noWorkspace: document.body.innerText.includes('No workspace assigned'),
    body: document.body.innerText.slice(0, 120).replace(/\n+/g, ' | '),
  }));
}

async function signIn(page, user, pass) {
  await page.waitForSelector('input[autocomplete="username"]', { timeout: 20000 });
  await page.type('input[autocomplete="username"]', user);
  await page.type('input[autocomplete="current-password"]', pass);
  await page.click('button[type="submit"]');
  await new Promise(r => setTimeout(r, 2500));
}

const browser = await puppeteer.launch({ headless: true, args: ['--no-sandbox', '--disable-dev-shm-usage'] });

for (const [user, pass] of [['owner', 'BpzOwner2026!'], ['demo', 'BpzDemo2026!'], ['manager_ama', 'BpzAma2026!'], ['checker_kofi', 'BpzKofi2026!'], ['agro_accountant', 'BpzAgro2026!']]) {
  const page = await browser.newPage();
  const errs = [];
  page.on('pageerror', e => errs.push('pageerror: ' + e.message));
  page.on('response', r => { if (r.url().includes('/api/') && r.status() >= 400) errs.push(`${r.status()} ${r.request().method()} ${r.url().replace(BASE, '')}`); });
  await page.goto(BASE + '/', { waitUntil: 'networkidle2', timeout: 60000 });
  await signIn(page, user, pass);
  const after = await snapshot(page);
  // RELOAD — the classic "does the session survive a refresh" test
  await page.reload({ waitUntil: 'networkidle2', timeout: 60000 });
  await new Promise(r => setTimeout(r, 3000));
  const reloaded = await snapshot(page);
  console.log(`\n### ${user}\n  after login : ${JSON.stringify(after)}\n  after reload: ${JSON.stringify(reloaded)}\n  errors      : ${errs.length ? errs.join(' ; ') : 'none'}`);
  await page.close();
}

// Two tabs, same browser profile (shared sessionStorage? no — separate per tab)
const p1 = await browser.newPage();
await p1.goto(BASE + '/', { waitUntil: 'networkidle2' });
await signIn(p1, 'owner', 'BpzOwner2026!');
console.log('\n### tab1 signed in:', JSON.stringify(await snapshot(p1)));
const p2 = await browser.newPage();
await p2.goto(BASE + '/', { waitUntil: 'networkidle2' });
await new Promise(r => setTimeout(r, 2500));
console.log('### tab2 (new tab, same profile):', JSON.stringify(await snapshot(p2)));
await signIn(p2, 'demo', 'BpzDemo2026!');
console.log('### tab2 signed in as demo:', JSON.stringify(await snapshot(p2)));
await new Promise(r => setTimeout(r, 2000));
console.log('### tab1 after tab2 login   :', JSON.stringify(await snapshot(p1)));

await browser.close();
