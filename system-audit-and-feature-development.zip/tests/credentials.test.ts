import test from 'node:test';
import assert from 'node:assert/strict';
import {
  hashPassword,
  verifyPassword,
  newSalt,
  needsRehash,
  passwordPolicyError,
  SCRYPT_PREFIX,
} from '../src/lib/password';

test('passwords are stored with the scrypt KDF, never a bare digest', async () => {
  const salt = newSalt();
  const hash = await hashPassword('BpzOwner2026!', salt);
  assert.ok(hash.startsWith(SCRYPT_PREFIX), 'hash must carry the scrypt scheme marker');
  assert.equal(hash.length, SCRYPT_PREFIX.length + 128, 'scrypt key must be 64 bytes (128 hex chars)');
  assert.notEqual(hash, await hashPassword('BpzOwner2026!', newSalt()), 'salts must diversify the hash');
});

test('verification accepts the correct password and rejects wrong ones', async () => {
  const salt = newSalt();
  const hash = await hashPassword('BpzOwner2026!', salt);
  assert.equal(await verifyPassword('BpzOwner2026!', salt, hash), true);
  assert.equal(await verifyPassword('BpzOwner2026', salt, hash), false);
  assert.equal(await verifyPassword('', salt, hash), false);
  assert.equal(await verifyPassword('BpzOwner2026!', newSalt(), hash), false);
});

test('legacy SHA-256 hashes still verify and are flagged for re-hash', async () => {
  const salt = newSalt();
  const data = new TextEncoder().encode('BpzLegacy2026!' + salt);
  const digest = await crypto.subtle.digest('SHA-256', data);
  const legacy = Array.from(new Uint8Array(digest)).map((b) => b.toString(16).padStart(2, '0')).join('');

  assert.equal(await verifyPassword('BpzLegacy2026!', salt, legacy), true, 'no user may be locked out');
  assert.equal(await verifyPassword('wrong', salt, legacy), false);
  assert.equal(needsRehash(legacy), true, 'legacy hash must be upgraded on next login');
  assert.equal(needsRehash(await hashPassword('BpzLegacy2026!', salt)), false);
});

test('password policy blocks weak credentials and accepts the seeded standard', () => {
  assert.ok(passwordPolicyError('short1!A'), 'under the minimum length');
  assert.ok(passwordPolicyError('alllowercase1!'), 'no uppercase');
  assert.ok(passwordPolicyError('ALLUPPERCASE1!'), 'no lowercase');
  assert.ok(passwordPolicyError('NoDigitsHere!!'), 'no digit');
  assert.ok(passwordPolicyError('NoSymbols12345'), 'no symbol');
  for (const pw of ['BpzOwner2026!', 'BpzAma2026!', 'BpzKofi2026!', 'BpzDemo2026!', 'BpzAgro2026!']) {
    assert.equal(passwordPolicyError(pw), null, `${pw} must satisfy the policy`);
  }
});
