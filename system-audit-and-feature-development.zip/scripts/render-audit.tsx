/**
 * Render audit: server-renders every workspace module with realistic props so
 * that any module that crashes on first render is caught in CI instead of in
 * the browser ("This page couldn't load").
 *
 * Run: npx tsx scripts/render-audit.tsx
 */
import React from 'react';
import { renderToString } from 'react-dom/server';

const memory = new Map<string, string>();
const shim = {
  getItem: (k: string) => memory.get(k) ?? null,
  setItem: (k: string, v: string) => { memory.set(k, v); },
  removeItem: (k: string) => { memory.delete(k); },
  clear: () => memory.clear(),
  key: () => null,
  length: 0,
};
Object.defineProperty(globalThis, 'localStorage', { configurable: true, value: shim });
Object.defineProperty(globalThis, 'sessionStorage', { configurable: true, value: shim });
Object.defineProperty(globalThis, 'window', { configurable: true, value: { location: { origin: 'http://localhost:3000' }, localStorage: shim, sessionStorage: shim, addEventListener() {}, removeEventListener() {} } });

async function main() {
  const seed = await import('../src/data/accountingSeed');
  const { persistentStorage } = await import('../src/utils/persistentStorage');
  const C = {
    dashboard: (await import('../src/components/AccountingDashboard')).AccountingDashboard,
    procurement: (await import('../src/components/ProcurementSection')).ProcurementSection,
    sales: (await import('../src/components/SalesSection')).SalesSection,
    business_partners: (await import('../src/components/BusinessPartnersSection')).BusinessPartnersSection,
    opening_balance: (await import('../src/components/OpeningBalanceSection')).OpeningBalanceSection,
    payroll: (await import('../src/components/PayrollSection')).PayrollSection,
    banking: (await import('../src/components/BankingSection')).BankingSection,
    company_profile: (await import('../src/components/CompanyProfileSection')).CompanyProfileSection,
    payment_desk: (await import('../src/components/PaymentDeskSection')).PaymentDeskSection,
    expenses: (await import('../src/components/ExpensesSection')).ExpensesSection,
    inventory: (await import('../src/components/InventorySection')).InventorySection,
    prepayments: (await import('../src/components/PrepaymentsSection')).PrepaymentsSection,
    assets: (await import('../src/components/FixedAssetsSection')).FixedAssetsSection,
    coa_master: (await import('../src/components/ChartOfAccountsSection')).ChartOfAccountsSection,
    general_ledger: (await import('../src/components/GeneralLedgerSection')).GeneralLedgerSection,
    tax_schedules: (await import('../src/components/TaxSchedulesSection')).TaxSchedulesSection,
    manual_journal: (await import('../src/components/ManualJournalSection')).ManualJournalSection,
    standards_desk: (await import('../src/components/ComprehensiveStandardsDesk')).ComprehensiveStandardsDesk,
    loans_desk: (await import('../src/components/LoansAmortisationDesk')).LoansAmortisationDesk,
    financial_reports: (await import('../src/components/FinancialReportsSection')).FinancialReportsSection,
    tax_schedule: (await import('../src/components/TaxFilingScheduleSection')).TaxFilingScheduleSection,
    disclosures: (await import('../src/components/DisclosureNotesDesk')).DisclosureNotesDesk,
    month_end: (await import('../src/components/MonthEndSection')).MonthEndSection,
    adjustments: (await import('../src/components/AdjustmentsDesk')).AdjustmentsDesk,
    clients_management: (await import('../src/components/ClientsManagementSection')).ClientsManagementSection,
    advisory: (await import('../src/components/AdvisorySection')).AdvisorySection,
    user_permissions: (await import('../src/components/UserPermissionsDesk')).UserPermissionsDesk,
    group_consolidation: (await import('../src/components/ConsolidationDesk')).ConsolidationDesk,
    enterprise_sso: (await import('../src/components/SsoDesk')).SsoDesk,
    tax_settings: (await import('../src/components/TaxSettingsDesk')).TaxSettingsDesk,
    global_tax: (await import('../src/components/GlobalTaxDesk')).GlobalTaxDesk,
    soc_dr: (await import('../src/components/SocBackupDesk')).SocBackupDesk,
    realtime_integrations: (await import('../src/components/IntegrationsDesk')).IntegrationsDesk,
    header: (await import('../src/components/AccountingHeader')).AccountingHeader,
    sidebar: (await import('../src/components/AccountingSidebar')).AccountingSidebar,
    approvals: (await import('../src/components/ApprovalsModal')).ApprovalsModal,
    login: (await import('../src/components/LoginScreen')).LoginScreen,
  } as unknown as Record<string, React.ComponentType<Record<string, unknown>>>;

  // Seeded entities plus a brand-new, completely empty entity (the path where
  // "no data yet" crashes usually hide).
  const clients = [
    ...seed.INITIAL_CLIENTS,
    { id: 9901, code: 'CLI-NEW', name: 'Newly Onboarded Entity Ltd', sector: 'Professional Services / Advisory', currency: 'GHS', jurisdiction: 'GH', regNumber: 'NEW-00001-2026', assignedServices: [] },
  ];
  const accounts = seed.INITIAL_CHART_OF_ACCOUNTS;
  const lines = seed.INITIAL_ACDOCA_LINES;
  const user = seed.INITIAL_USERS[0];
  const noop = () => true;
  const noopVoid = () => {};

  let failures = 0;
  for (const client of clients) {
    const base: Record<string, unknown> = {
      currentClient: client,
      currentWorkspace: client,
      clients,
      currentUser: user,
      accounts,
      lines,
      chartOfAccounts: accounts,
      closedPeriods: [],
      isPeriodClosed: false,
      purchaseOrders: seed.INITIAL_PURCHASE_ORDERS.filter((p) => (p.clientId ?? 2) === client.id),
      salesInvoices: seed.INITIAL_SALES_INVOICES.filter((p) => (p.clientId ?? 2) === client.id),
      partners: seed.INITIAL_BUSINESS_PARTNERS.filter((p) => (p.clientId ?? 2) === client.id),
      bankAccounts: seed.INITIAL_BANK_ACCOUNTS.filter((p) => (p.clientId ?? 2) === client.id),
      employees: seed.INITIAL_EMPLOYEES.filter((p) => (p.clientId ?? 2) === client.id),
      notes: persistentStorage.getDisclosureNotes(),
      isOwner: true,
      isOpen: true,
      activeSection: 'dashboard',
      pendingApprovalsCount: 0,
      isBalanced: true,
      totalLines: lines.length,
      totalDocs: 5,
      onAddJournalLines: noop,
      onEditDocument: async () => ({ ok: true }),
      onDeleteDocument: async () => ({ ok: true }),
      onUpdateAccount: () => ({ ok: true }),
      onDeleteAccount: () => ({ ok: true }),
      onResetAccounts: async () => ({ ok: true }),
      onSaveEntry: noopVoid,
      onDeleteEntry: noopVoid,
      entries: [],
      resetPreview: { lines: lines.length, documents: 5, purchaseOrders: 0, salesInvoices: 0, employees: 0, partners: 0, bankAccounts: 0, customAccounts: 0 },
      syncStatus: { state: 'synced', at: new Date().toISOString() },
      onPostYearEndClose: () => ({ net: 0, accounts: 0 }),
      onSettleSupplierInvoice: () => 'posted',
      onReceiveCustomerPayment: () => 'posted',
      onDisburseSalaries: () => 'posted',
      onSettleExpenseBill: () => 'posted',
      onRemitStatutory: () => 'posted',
      onPostPOToJournal: noop,
      onPostSalesToJournal: noop,
      onIssueCreditNote: noop,
      onIssueDebitNote: noop,
      onPostMonthlyPayroll: noop,
      onReverseDocument: noop,
      onApprovePost: noop,
      onAddEmployee: noopVoid,
      onAddPartner: noopVoid,
      onAddPO: noopVoid,
      onAddInvoice: noopVoid,
      onAddBankAccount: noopVoid,
      onAddAccount: noopVoid,
      onAddClient: noopVoid,
      onSwitchClient: noopVoid,
      onSelectClient: noopVoid,
      onSelectSection: noopVoid,
      onNavigate: noopVoid,
      onNavigateSection: noopVoid,
      onUpdateClientName: noopVoid,
      onRefreshAllData: noopVoid,
      onRefreshUsers: noopVoid,
      onUpdateNote: noopVoid,
      onOpenNotesToAccounts: noopVoid,
      onTogglePeriodClose: noopVoid,
      onBankBalanceChange: noopVoid,
      onApprovalSubmitted: noopVoid,
      onApprovalResolved: noopVoid,
      onClose: noopVoid,
      onOpenApprovals: noopVoid,
      onLogin: noopVoid,
      onLoginAsSsoUser: noopVoid,
      onSignOut: noopVoid,
      onSwitchUser: noopVoid,
    };
    for (const [key, Comp] of Object.entries(C)) {
      try {
        renderToString(React.createElement(Comp, base));
      } catch (err) {
        failures += 1;
        console.error(`FAIL  ${key}  (client ${client.code}): ${(err as Error).message}`);
      }
    }
  }
  if (failures) {
    console.error(`\n${failures} module render failure(s).`);
    process.exit(1);
  }
  console.log(`Render audit passed: ${Object.keys(C).length} modules x ${clients.length} entities.`);
}

main().catch((e) => { console.error(e); process.exit(1); });
