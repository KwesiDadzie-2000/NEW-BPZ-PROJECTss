import { ensureDatabaseReady } from "@/db/bootstrap";
import { authJson, getSessionUserByToken, readSessionToken, SESSION_TTL_MS } from "@/lib/auth";

export const dynamic = "force-dynamic";

/**
 * Session probe — the single source of truth for "is this browser signed in?".
 *
 * Two rules make the login portal stop swallowing signed-in users:
 *  1. A database/infrastructure failure answers **503**, never 401. Only a
 *     session the server has actually looked up and rejected answers 401, so a
 *     transient blip can no longer be misread as "signed out".
 *  2. A valid session **re-issues the HttpOnly cookie** and echoes the token,
 *     which repairs a cookie the browser dropped (cross-site iframe, cleared
 *     site data, http→https hop) without asking the user to sign in again.
 */
export async function GET(req: Request) {
  try {
    await ensureDatabaseReady();
  } catch (e) {
    console.error("session probe: database unavailable", e);
    return authJson(req, { ok: false, user: null, error: "database-unavailable" }, { status: 503 });
  }

  const token = readSessionToken(req);
  if (!token) {
    return authJson(req, { ok: false, user: null, error: "no-session" }, { status: 401, clearCookie: true });
  }

  try {
    const user = await getSessionUserByToken(token);
    if (!user) return authJson(req, { ok: false, user: null, error: "invalid-session" }, { status: 401, clearCookie: true });
    // Self-healing: refresh the cookie (and its max-age) on every successful probe.
    return authJson(req, { ok: true, user, token, expiresInSeconds: SESSION_TTL_MS / 1000 }, { token });
  } catch (e) {
    console.error("session probe failed", e);
    return authJson(req, { ok: false, user: null, error: "session-check-failed" }, { status: 503 });
  }
}
