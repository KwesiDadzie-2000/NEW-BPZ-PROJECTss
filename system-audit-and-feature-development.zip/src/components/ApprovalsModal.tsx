import React, { useState } from 'react';
import { ApprovalRequest, ClientEntity, UserAccount } from '../types/accounting';
import { persistentStorage } from '../utils/persistentStorage';
import { formatGHS } from './ui';
import {
  Bell,
  CheckCircle2,
  XCircle,
  AlertTriangle,
} from 'lucide-react';

interface ApprovalsModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserAccount;
  /** The workspace currently open — the queue is scoped to THIS entity only. */
  currentClient: ClientEntity;
  /** Owner / firm-wide reviewers may opt in to the cross-entity queue. */
  allowFirmWide?: boolean;
  onApprovalResolved?: () => void;
  /** Posts the request's proposed journal lines with the approver as independent checker. */
  onApprovePost?: (req: ApprovalRequest) => boolean;
}

export const ApprovalsModal: React.FC<ApprovalsModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  currentClient,
  allowFirmWide = false,
  onApprovalResolved,
  onApprovePost,
}) => {
  const [requests, setRequests] = useState<ApprovalRequest[]>(() =>
    persistentStorage.getApprovalRequests()
  );
  const [filterStatus, setFilterStatus] = useState<'all' | 'pending' | 'approved' | 'rejected'>('pending');
  const [rejectionTargetId, setRejectionTargetId] = useState<string | null>(null);
  const [rejectionReason, setRejectionReason] = useState('');
  const [successToast, setSuccessToast] = useState<string | null>(null);
  // Entity isolation: the queue opens on the active workspace only, so another
  // client's documents are never displayed above a client's own books.
  const [scope, setScope] = useState<'entity' | 'firm'>('entity');

  if (!isOpen) return null;

  const firmWide = allowFirmWide && scope === 'firm';
  const inScope = (r: ApprovalRequest) => firmWide || r.clientId === currentClient.id;

  const canApprove = currentUser.canCheck || currentUser.role === 'owner' || currentUser.role === 'partner' || currentUser.role === 'manager';

  const scopedRequests = requests.filter(inScope);

  const filtered = scopedRequests.filter((r) => {
    if (filterStatus === 'all') return true;
    return r.status === filterStatus;
  });

  const pendingCount = scopedRequests.filter((r) => r.status === 'pending').length;

  const handleApprove = (req: ApprovalRequest) => {
    const updated = persistentStorage.resolveApprovalRequest(req.id, 'approved', currentUser.name);
    if (updated) {
      setRequests(persistentStorage.getApprovalRequests());
      const proposed = req.payload?.lines?.filter((l) => l.debit > 0 || l.credit > 0);
      if (proposed && proposed.length > 0 && onApprovePost) {
        const posted = onApprovePost({ ...req, payload: { lines: proposed } });
        setSuccessToast(
          posted
            ? `Approved and posted: ${req.docNo} (${req.clientCode} · ₵${formatGHS(req.amount)}). Checker of record: ${currentUser.name}.`
            : `Approved: ${req.docNo} signed off, but the journal was NOT posted (period frozen or validation failed). The request stays recorded for follow-up.`
        );
      } else {
        setSuccessToast(`Marked reviewed: ${req.docNo} (${req.clientCode} · ₵${formatGHS(req.amount)}). No journal lines were attached to this request.`);
      }
      setTimeout(() => setSuccessToast(null), 6000);
      if (onApprovalResolved) onApprovalResolved();
    }
  };

  const handleConfirmRejection = (e: React.FormEvent) => {
    e.preventDefault();
    if (!rejectionTargetId) return;

    const targetReq = requests.find((r) => r.id === rejectionTargetId);
    const updated = persistentStorage.resolveApprovalRequest(
      rejectionTargetId,
      'rejected',
      currentUser.name,
      rejectionReason || 'Rejected per audit compliance review'
    );

    if (updated) {
      setRequests(persistentStorage.getApprovalRequests());
      setSuccessToast(`Rejected ${targetReq?.docNo || 'request'} with reviewer feedback.`);
      setTimeout(() => setSuccessToast(null), 4000);
      setRejectionTargetId(null);
      setRejectionReason('');
      if (onApprovalResolved) onApprovalResolved();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 overflow-y-auto">
      <div className="w-full max-w-4xl rounded-2xl bg-white p-6 sm:p-7 shadow-2xl space-y-5 text-xs text-[#0a253e]">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-sky-200 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="rounded-xl bg-amber-100 p-2 text-[#855b00]">
              <Bell className="h-5 w-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-black text-[#082f4f]">
                  Review queue
                </h3>
                {pendingCount > 0 && (
                  <span className="rounded-full bg-rose-600 px-2 py-0.5 text-[10.5px] font-bold text-white">
                    {pendingCount} Pending
                  </span>
                )}
              </div>
              <p className="text-[11px] text-[#2d4f6d]">
                {firmWide
                  ? 'Firm-wide queue (all entities) — switch back to the active workspace to review only this client.'
                  : `Scoped to ${currentClient.code} · ${currentClient.name} — requests raised in other entities are not shown here.`}
                {' '}Approving a request with proposed journal lines posts them with you as the independent checker; the decision is audit-logged.
              </p>
              {allowFirmWide && (
                <button
                  type="button"
                  onClick={() => setScope(firmWide ? 'entity' : 'firm')}
                  className="mt-1.5 rounded border border-sky-300 bg-sky-50 px-2 py-0.5 text-[10.5px] font-bold text-[#082f4f] hover:bg-sky-100"
                >
                  {firmWide ? `Show only ${currentClient.code}` : 'Show all entities (firm-wide)'}
                </button>
              )}
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-black text-xl font-bold p-1"
          >
            &times;
          </button>
        </div>

        {successToast && (
          <div className="rounded-xl border border-emerald-300 bg-emerald-50 p-3 text-xs font-bold text-emerald-900 flex items-center gap-2">
            <CheckCircle2 className="h-4 w-4 text-emerald-700 shrink-0" />
            <span>{successToast}</span>
          </div>
        )}

        {/* Filter Bar */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1 bg-sky-50 p-1 rounded-lg border border-sky-200">
            {(['pending', 'approved', 'rejected', 'all'] as const).map((s) => (
              <button
                key={s}
                onClick={() => setFilterStatus(s)}
                className={`rounded px-3 py-1 font-bold text-[11px] uppercase transition ${
                  filterStatus === s
                    ? 'bg-[#082f4f] text-white shadow-xs'
                    : 'text-[#355875] hover:bg-sky-100'
                }`}
              >
                {s} ({scopedRequests.filter((r) => s === 'all' || r.status === s).length})
              </button>
            ))}
          </div>

          <div className="text-[11px] text-[#355875] font-semibold">
            Reviewer: <strong className="text-[#082f4f]">{currentUser.name}</strong> ({currentUser.role})
          </div>
        </div>

        {/* Requests List */}
        <div className="space-y-3 max-h-[460px] overflow-y-auto pr-1">
          {filtered.length === 0 ? (
            <div className="p-10 text-center text-slate-400 border border-dashed border-sky-200 rounded-xl bg-sky-50/40">
              No approval requests matching status &ldquo;{filterStatus}&rdquo;.
            </div>
          ) : (
            filtered.map((req) => {
              const isPending = req.status === 'pending';
              const isApproved = req.status === 'approved';

              return (
                <div
                  key={req.id}
                  className={`rounded-xl border p-4 space-y-2.5 transition shadow-xs ${
                    isPending
                      ? 'border-amber-300 bg-amber-50/30'
                      : isApproved
                      ? 'border-sky-200 bg-white'
                      : 'border-rose-200 bg-rose-50/20'
                  }`}
                >
                  <div className="flex flex-wrap items-start justify-between gap-2">
                    <div className="space-y-0.5">
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-black text-sm text-[#855b00]">{req.docNo}</span>
                        <span className="rounded bg-sky-100 text-[#006f98] px-1.5 py-0.2 text-[10px] font-mono font-bold">
                          {req.docType}
                        </span>
                        <span className="font-bold text-[#082f4f]">{req.clientName} ({req.clientCode})</span>
                      </div>
                      <div className="text-xs text-[#2d4f6d]">{req.description}</div>
                    </div>

                    <div className="text-right">
                      <div className="font-mono text-base font-black text-[#082f4f]">
                        ₵{formatGHS(req.amount)}
                      </div>
                      <span
                        className={`rounded px-2 py-0.5 text-[10px] font-bold uppercase ${
                          isPending
                            ? 'bg-amber-100 text-[#855b00] border border-amber-300'
                            : isApproved
                            ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                            : 'bg-rose-100 text-rose-800 border border-rose-300'
                        }`}
                      >
                        {req.status}
                      </span>
                    </div>
                  </div>

                  {/* Why prompt is required */}
                  <div className="rounded-lg bg-sky-50/70 border border-sky-200 p-2.5 text-[11px] text-[#082f4f] flex items-start gap-2">
                    <AlertTriangle className="h-3.5 w-3.5 text-[#855b00] shrink-0 mt-0.5" />
                    <div>
                      <strong>Approval Threshold Prompt: </strong>
                      {req.reasonForApproval}
                      <span className="block text-slate-500 text-[10px] mt-0.5">
                        Requested by: <strong>{req.requestedBy}</strong> at {req.requestedAt}
                      </span>
                    </div>
                  </div>

                  {/* Review feedback if rejected or approved */}
                  {req.reviewedBy && (
                    <div className="text-[10.5px] text-[#355875] border-t border-sky-100 pt-1.5 flex justify-between">
                      <span>Reviewed by: <strong className="text-[#082f4f]">{req.reviewedBy}</strong> ({req.reviewedAt})</span>
                      {req.rejectionReason && (
                        <span className="text-rose-700 font-semibold">Feedback: &ldquo;{req.rejectionReason}&rdquo;</span>
                      )}
                    </div>
                  )}

                  {/* Approval Actions */}
                  {isPending && canApprove && (
                    <div className="flex justify-end gap-2 pt-2 border-t border-sky-100">
                      <button
                        type="button"
                        onClick={() => {
                          setRejectionTargetId(req.id);
                          setRejectionReason('Exceeds current period expenditure budget. Revise quote.');
                        }}
                        className="flex items-center gap-1 rounded bg-rose-50 border border-rose-300 px-3 py-1.5 font-bold text-rose-800 hover:bg-rose-100 transition"
                      >
                        <XCircle className="h-3.5 w-3.5" />
                        <span>Reject with Reason</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => handleApprove(req)}
                        className="flex items-center gap-1 rounded-lg bg-[#082f4f] px-4 py-1.5 font-bold text-white hover:bg-[#0c3f68] transition shadow-xs"
                      >
                        <CheckCircle2 className="h-3.5 w-3.5" />
                          <span>{req.payload?.lines?.length ? 'Approve & post journal' : 'Mark reviewed'}</span>
                      </button>
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>

        {/* Modal: Rejection Feedback Prompt */}
        {rejectionTargetId && (
          <div className="fixed inset-0 z-60 flex items-center justify-center bg-black/50 p-4">
            <form
              onSubmit={handleConfirmRejection}
              className="w-full max-w-md rounded-2xl bg-white p-5 shadow-2xl space-y-3 text-xs"
            >
              <h4 className="text-sm font-bold text-rose-800 border-b border-rose-200 pb-2">
                Reject Request &amp; Send Feedback to Maker
              </h4>
              <p className="text-[#2d4f6d]">
                Specify why this document was not signed off so the staff accountant can rectify it.
              </p>
              <textarea
                rows={3}
                value={rejectionReason}
                onChange={(e) => setRejectionReason(e.target.value)}
                placeholder="Enter audit rejection reason..."
                className="w-full rounded border border-rose-300 p-2.5 outline-none font-semibold text-[#082f4f]"
                required
              />
              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setRejectionTargetId(null)}
                  className="rounded px-3 py-1.5 font-semibold text-[#2d4f6d]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="rounded bg-[#b42318] px-4 py-1.5 font-bold text-white hover:bg-rose-800"
                >
                  Confirm Rejection
                </button>
              </div>
            </form>
          </div>
        )}
      </div>
    </div>
  );
};
