import { useState } from 'react';
import { Calculator, Globe, ShieldOff, Receipt } from 'lucide-react';

interface JurisdictionConfig {
  code: string;
  name: string;
  currency: string;
  vatName: string;
  vatRate: number;
  citRate: number;
  payrollDescription: string;
  statutoryBasis: string;
  specialRules: string;
  jurisdictions: string[];
  notes: string;
}

const JURISDICTIONS: JurisdictionConfig[] = [
  {
    code: 'GH',
    name: 'Ghana (Domestic HQ)',
    currency: 'GHS',
    vatName: 'VAT',
    vatRate: 20.0,
    citRate: 25.0,
    payrollDescription: 'Progressive GRA PAYE bands (5% to 35%) + SSNIT Tier 1 & 2',
    statutoryBasis: 'Ghana Income Tax Act 2015 (Act 896 as amended) · VAT Act 2013',
    specialRules: 'Full VAT input credit without cascading · Mining CIT is 35% under Act 729',
    jurisdictions: ['Ghana'],
    notes: 'This is the only jurisdiction whose payroll and tax rules are partially implemented in the demo.',
  },
  {
    code: 'GB',
    name: 'United Kingdom',
    currency: 'GBP',
    vatName: 'VAT',
    vatRate: 20.0,
    citRate: 25.0,
    payrollDescription: 'PAYE RTI + Class 1 National Insurance (13.8% employer / 8% employee)',
    statutoryBasis: 'UK Corporation Tax Act 2009 / 2010 · HMRC VAT Notice 700',
    specialRules: '£250,000 threshold for 25% upper rate · MTD (Making Tax Digital) API compliance',
    jurisdictions: ['United Kingdom'],
    notes: 'Tax bands and thresholds are quoted as reference only. Build server-side rules before producing client returns.',
  },
  {
    code: 'US',
    name: 'United States',
    currency: 'USD',
    vatName: 'Sales Tax (Nexus State)',
    vatRate: 8.875,
    citRate: 21.0,
    payrollDescription: 'Federal income tax · FICA (Social Security 6.2% + Medicare 1.45%) · state payroll taxes',
    statutoryBasis: 'IRS Publication 15 · IRC Subtitle C · State Department of Revenue rules',
    specialRules: 'State-by-state nexus requirements · Multi-state payroll registration per state',
    jurisdictions: ['United States'],
    notes: 'Sales tax and state payroll rates differ in every state. Use the state tax engine, not a single rate.',
  },
  {
    code: 'EU',
    name: 'European Union',
    currency: 'EUR',
    vatName: 'VAT',
    vatRate: 21.0,
    citRate: 25.0,
    payrollDescription: 'Local PAYE + Social Security per member state',
    statutoryBasis: 'VAT Directive 2006/112/EC · Council Directive on common system of VAT',
    specialRules: 'Reverse charge on B2B cross-border supplies · OSS/IOSS for B2C distance sales',
    jurisdictions: ['EU'],
    notes: 'Member state rates differ. Set up separate tenant per country.',
  },
];

const DEMO_DISCLAIMER = 'Reference rates only. Server-side effective-dated rules are required before any client filing.';

export const GlobalTaxDesk: React.FC = () => {
  const [selected, setSelected] = useState<JurisdictionConfig>(JURISDICTIONS[0]);

  return (
    <div className="space-y-6 text-[#0a253e]">
      <div className="rounded-xl border border-amber-400 bg-amber-50 p-4 text-sm text-amber-950 flex items-start gap-2">
        <ShieldOff className="h-5 w-5 mt-0.5 text-amber-700 shrink-0" />
        <div>
          <strong>Reference only.</strong> {DEMO_DISCLAIMER}
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        {JURISDICTIONS.map(j => {
          const active = j.code === selected.code;
          return (
            <button
              key={j.code}
              onClick={() => setSelected(j)}
              className={`text-left rounded-xl border p-4 transition shadow-xs ${active ? 'border-[#006f98] bg-sky-50 ring-1 ring-[#006f98]' : 'border-sky-200 bg-white hover:bg-sky-50'}`}
            >
              <div className="flex items-center justify-between">
                <span className="font-mono text-xs font-black text-[#006f98]">{j.code}</span>
                <span className="rounded bg-sky-100 px-1.5 py-0.5 font-mono text-[10px] text-[#006f98]">{j.currency}</span>
              </div>
              <div className="mt-1 text-sm font-bold text-[#082f4f]">{j.name}</div>
              <div className="mt-2 text-[11px] text-[#2d4f6d]">
                {j.vatName} <span className="text-[#082f4f] font-bold">{j.vatRate}%</span> · CIT <span className="text-[#082f4f] font-bold">{j.citRate}%</span>
              </div>
            </button>
          );
        })}
      </div>

      <div className="rounded-xl border border-sky-200 bg-white p-5 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-sky-200 pb-3">
          <div>
            <h3 className="text-sm font-bold uppercase tracking-wider text-[#082f4f] flex items-center gap-2">
              <Globe className="h-4 w-4 text-[#006f98]" /> {selected.name} — jurisdiction profile
            </h3>
            <p className="text-[11px] text-[#2d4f6d] mt-0.5">{selected.statutoryBasis}</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
          <div className="rounded-lg border border-sky-200 bg-sky-50/40 p-3">
            <div className="text-[10px] font-bold uppercase tracking-wider text-[#355875]">Statutory VAT</div>
            <div className="text-base font-black text-[#082f4f] mt-1">{selected.vatName} {selected.vatRate}%</div>
            <p className="text-[11px] text-[#2d4f6d] mt-1">{selected.specialRules}</p>
          </div>
          <div className="rounded-lg border border-sky-200 bg-sky-50/40 p-3">
            <div className="text-[10px] font-bold uppercase tracking-wider text-[#355875]">Corporate Income Tax</div>
            <div className="text-base font-black text-[#082f4f] mt-1">{selected.citRate}%</div>
            <p className="text-[11px] text-[#2d4f6d] mt-1">Combined with payroll withholding, corporate assessment, and treaty considerations.</p>
          </div>
          <div className="rounded-lg border border-sky-200 bg-sky-50/40 p-3 md:col-span-2">
            <div className="text-[10px] font-bold uppercase tracking-wider text-[#355875]">Payroll withholdings</div>
            <div className="text-sm font-black text-[#082f4f] mt-1">{selected.payrollDescription}</div>
            <p className="text-[11px] text-[#2d4f6d] mt-1">Only the Ghana rules are partially implemented. Other jurisdictions require server-side band lookups, treaties, and statutory-effective date handling.</p>
          </div>
        </div>

        <div className="text-[11px] text-[#355875] bg-sky-50 p-2.5 rounded border border-sky-200">
          <strong>Notes:</strong> {selected.notes}
        </div>
      </div>

      <div className="rounded-xl border border-sky-200 bg-white p-5 shadow-xs space-y-3">
        <h3 className="text-sm font-bold uppercase tracking-wider text-[#082f4f] flex items-center gap-2">
          <Calculator className="h-4 w-4 text-[#006f98]" /> Reference computation
        </h3>
        <p className="text-[11px] text-[#2d4f6d]">
          This is a paper calculation of the selected rate, not a tax return. It is provided to show the
          numbers the server-side engine will eventually compute from posted journals, source documents, and
          statutory rules.
        </p>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 text-xs">
          {[
            { label: `${selected.vatName} rate`, value: `${selected.vatRate}%` },
            { label: 'CIT rate', value: `${selected.citRate}%` },
            { label: 'Reference currency', value: selected.currency },
          ].map(m => (
            <div key={m.label} className="rounded border border-sky-200 bg-sky-50/30 p-3">
              <div className="text-[10px] font-bold uppercase tracking-wider text-[#355875]">{m.label}</div>
              <div className="font-mono text-sm font-black text-[#082f4f] mt-1">{m.value}</div>
            </div>
          ))}
        </div>
        <div className="rounded border border-sky-100 bg-slate-50 p-3 text-[11px] text-[#355875] flex items-start gap-2">
          <Receipt className="h-4 w-4 mt-0.5 text-slate-400" />
          <span>
            When the server-side engine is deployed, the real journal entry for this period will be generated from
            actual posted lines, with the correct effective-dated rate, treaty and reverse-charge treatment.
          </span>
        </div>
      </div>
    </div>
  );
};
