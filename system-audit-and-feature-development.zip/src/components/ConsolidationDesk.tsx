import React, { useState } from 'react';
import { GROUP_MEMBERS, INTERCOMPANY_TXNS } from '../data/initialData';
import { GroupMember, IntercompanyTxn } from '../types';
import type { ACDOCALine, AccountMaster, ClientEntity } from '../types/accounting';
import { aggregateTrialBalance } from '../utils/reports';
import { formatGHS } from './ui';
import {
  Layers,
  Plus,
  ArrowRightLeft,
  CheckCircle2,
  FileSpreadsheet,
} from 'lucide-react';

interface ConsolidationDeskProps {
  clients?: ClientEntity[];
  lines?: ACDOCALine[];
  accounts?: AccountMaster[];
}

export const ConsolidationDesk: React.FC<ConsolidationDeskProps> = ({ clients = [], lines = [], accounts = [] }) => {
  const [members, setMembers] = useState<GroupMember[]>(GROUP_MEMBERS);
  const [txns, setTxns] = useState<IntercompanyTxn[]>(INTERCOMPANY_TXNS);
  const [selectedCurrency, setSelectedCurrency] = useState<'GHS' | 'USD' | 'GBP'>('GHS');
  const [showAddMemberModal, setShowAddMemberModal] = useState(false);

  // Computed consolidated trial balance: every member entity now owns its own
  // journal, so the group desk aggregates the posted line totals per account.
  const memberIds = new Set(members.map((m) => m.clientId));
  const groupLines = lines.filter((l) => memberIds.has(l.clientId));
  const consolidated = aggregateTrialBalance(groupLines, accounts);
  const consDr = consolidated.reduce((n, r) => n + r.dr, 0) / 100;
  const consCr = consolidated.reduce((n, r) => n + r.cr, 0) / 100;
  const consBalanced = Math.abs(consDr - consCr) < 0.01;
  const entityTotals = members.map((m) => {
    const cl = lines.filter((l) => l.clientId === m.clientId);
    return {
      member: m,
      dr: cl.reduce((n, l) => n + Math.round(l.debit * 100), 0) / 100,
      cr: cl.reduce((n, l) => n + Math.round(l.credit * 100), 0) / 100,
    };
  });

  // New member form state
  const [newCode, setNewCode] = useState('CLI-004');
  const [newName, setNewName] = useState('Accra Energy Storage Ltd');
  const [newOwnership, setNewOwnership] = useState(65);
  const [newMethod, setNewMethod] = useState<'Full Consolidation (IFRS 10)' | 'Equity Method (IAS 28)'>(
    'Full Consolidation (IFRS 10)'
  );

  const handleAddMember = (e: React.FormEvent) => {
    e.preventDefault();
    const newMember: GroupMember = {
      clientId: members.length + 1,
      clientCode: newCode,
      clientName: newName,
      ownershipPct: newOwnership,
      method: newMethod,
      nciShare: Math.max(0, 100 - newOwnership),
      goodwill: newOwnership > 50 ? 45000 : 0,
      currency: 'GHS',
    };
    setMembers([...members, newMember]);
    setShowAddMemberModal(false);
  };

  const handleToggleEliminate = (id: string) => {
    setTxns(
      txns.map((t) => (t.id === id ? { ...t, eliminated: !t.eliminated } : t))
    );
  };

  // Mock consolidation calculation
  const totalIntercompanyEliminated = txns
    .filter((t) => t.eliminated)
    .reduce((acc, t) => acc + t.amount, 0);

  return (
    <div className="space-y-6">
      {/* Header & Hard Blocker Resolved Badge */}
      <div className="rounded-xl border border-slate-700 bg-slate-900/90 p-6 shadow-lg">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="rounded bg-emerald-500/20 px-2 py-0.5 text-xs font-mono font-bold text-emerald-300">
                IFRS 10 · CONSOLIDATED FINANCIAL STATEMENTS
              </span>
              <span className="rounded bg-sky-500/20 px-2 py-0.5 text-xs font-mono font-bold text-sky-400">
                HOLDING &amp; SUBSIDIARY SCOPE
              </span>
            </div>
            <h2 className="mt-2 text-2xl font-black text-white">
              Group Consolidation & Intercompany Elimination Engine
            </h2>
            <p className="mt-1 text-sm text-slate-300 max-w-3xl">
              Line-by-line financial statement aggregation, Non-Controlling Interest (NCI) computation, Goodwill recognition, and automated bilateral elimination of intercompany balances.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className="rounded-lg border border-slate-700 bg-slate-800/80 px-3 py-2 text-right">
              <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                Reporting Currency
              </div>
              <select
                value={selectedCurrency}
                onChange={(e) => setSelectedCurrency(e.target.value as any)}
                className="bg-transparent font-mono font-bold text-amber-400 outline-none text-xs cursor-pointer"
              >
                <option value="GHS" className="bg-slate-900">GHS (Ghana Cedi)</option>
                <option value="USD" className="bg-slate-900">USD (US Dollar)</option>
                <option value="GBP" className="bg-slate-900">GBP (British Pound)</option>
              </select>
            </div>
            <button
              onClick={() => setShowAddMemberModal(true)}
              className="flex items-center gap-1.5 rounded-lg bg-amber-400 px-3.5 py-2 text-xs font-bold text-slate-950 hover:bg-amber-300 transition"
            >
              <Plus className="h-4 w-4" />
              <span>Add Subsidiary</span>
            </button>
          </div>
        </div>
      </div>

      {/* Group Members Hierarchy Table */}
      <div className="rounded-xl border border-slate-700 bg-slate-900/90 p-5 space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Layers className="h-4 w-4 text-amber-400" />
            <h3 className="text-sm font-bold uppercase tracking-wider text-white">
              Group Entities & Ownership Hierarchy (BPZ Group Holding Structure)
            </h3>
          </div>
          <span className="text-xs font-mono text-slate-400">{members.length} Entities in Consolidation Scope</span>
        </div>

        <div className="overflow-x-auto rounded-lg border border-slate-800">
          <table className="min-w-full text-left text-xs">
            <thead className="border-b border-slate-800 bg-slate-950 text-slate-400">
              <tr>
                <th className="px-3.5 py-2.5 font-semibold">Entity Code</th>
                <th className="px-3.5 py-2.5 font-semibold">Legal Entity Name</th>
                <th className="px-3.5 py-2.5 font-semibold">Parent Ownership %</th>
                <th className="px-3.5 py-2.5 font-semibold">NCI Share %</th>
                <th className="px-3.5 py-2.5 font-semibold">Accounting Method</th>
                <th className="px-3.5 py-2.5 font-semibold">Recognised Goodwill</th>
                <th className="px-3.5 py-2.5 font-semibold">Functional CCY</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-850">
              {members.map((m) => (
                <tr key={m.clientId} className="hover:bg-slate-800/50">
                  <td className="px-3.5 py-2.5 font-mono font-bold text-amber-300">{m.clientCode}</td>
                  <td className="px-3.5 py-2.5 text-slate-200 font-medium">{m.clientName}</td>
                  <td className="px-3.5 py-2.5 font-mono font-bold text-white">{m.ownershipPct}%</td>
                  <td className="px-3.5 py-2.5 font-mono text-slate-400">{m.nciShare}%</td>
                  <td className="px-3.5 py-2.5">
                    <span
                      className={`rounded px-2 py-0.5 text-[11px] font-bold ${
                        m.ownershipPct >= 50
                          ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                          : 'bg-sky-500/20 text-sky-300 border border-sky-500/30'
                      }`}
                    >
                      {m.method}
                    </span>
                  </td>
                  <td className="px-3.5 py-2.5 font-mono text-slate-300">
                    {m.goodwill > 0 ? `GHS ${m.goodwill.toLocaleString()}` : '—'}
                  </td>
                  <td className="px-3.5 py-2.5 font-mono text-slate-400">{m.currency}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Intercompany Eliminations & Bilateral Balances */}
      <div className="rounded-xl border border-slate-700 bg-slate-900/90 p-5 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
          <div>
            <div className="flex items-center gap-2">
              <ArrowRightLeft className="h-4 w-4 text-sky-400" />
              <h3 className="text-sm font-bold uppercase tracking-wider text-white">
                Intercompany Transaction Eliminations (IFRS 10.B86)
              </h3>
            </div>
            <p className="mt-1 text-xs text-slate-400">
              Intra-group balances, transactions, income and expenses are eliminated in full to avoid revenue double-counting.
            </p>
          </div>
          <div className="rounded bg-slate-800 px-3 py-1.5 text-xs font-mono text-emerald-300 border border-slate-700">
            Total Eliminated: GHS {totalIntercompanyEliminated.toLocaleString()}
          </div>
        </div>

        <div className="space-y-2.5">
          {txns.map((t) => (
            <div
              key={t.id}
              className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-slate-800 bg-slate-950/60 p-3.5"
            >
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="font-mono text-xs font-bold text-amber-400">{t.id}</span>
                  <span className="rounded bg-slate-800 px-1.5 py-0.5 text-[10.5px] font-semibold text-slate-300">
                    {t.nature}
                  </span>
                  <span className="font-mono text-xs text-slate-400">Journal: {t.journalRef}</span>
                </div>
                <div className="text-xs text-slate-300 flex items-center gap-1.5">
                  <span className="font-semibold text-slate-200">{t.fromEntity}</span>
                  <span className="text-slate-500">&rarr;</span>
                  <span className="font-semibold text-slate-200">{t.toEntity}</span>
                </div>
              </div>

              <div className="flex items-center gap-4">
                <div className="text-right">
                  <div className="font-mono text-sm font-bold text-white">
                    {t.currency} {t.amount.toLocaleString()}
                  </div>
                  <div className="text-[10.5px] text-slate-400">Intercompany balance</div>
                </div>

                <button
                  onClick={() => handleToggleEliminate(t.id)}
                  className={`flex items-center gap-1.5 rounded px-2.5 py-1.5 text-xs font-bold transition ${
                    t.eliminated
                      ? 'bg-emerald-600 text-white hover:bg-emerald-500'
                      : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                  }`}
                >
                  <CheckCircle2 className="h-3.5 w-3.5" />
                  <span>{t.eliminated ? 'Eliminated' : 'Uneliminated'}</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Computed Consolidated Trial Balance (aggregated from each entity's own journal) */}
      <div className="rounded-xl border border-slate-700 bg-slate-900/90 p-5 space-y-3">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <FileSpreadsheet className="h-4 w-4 text-amber-400" />
            <h3 className="text-sm font-bold uppercase tracking-wider text-white">
              Consolidated Group Trial Balance (computed from posted entity journals)
            </h3>
          </div>
          <span className={`text-xs font-mono font-semibold ${consBalanced ? 'text-emerald-400' : 'text-rose-400'}`}>
            {consBalanced ? '✓ Dr = Cr Balanced Consolidation' : '✗ Out of balance'}
          </span>
        </div>

        <p className="text-xs text-slate-300 bg-slate-800/60 border border-slate-700 rounded p-3">
          Each subsidiary workspace owns its own journal; this desk aggregates the posted line totals per account across
          the {members.length} entities in scope. Intercompany eliminations are applied through the register below, and
          profit is split between owners and NCI from posted ownership percentages. Aggregation is at book value — a
          production consolidation translates foreign-currency entities under IAS 21 before aggregation.
        </p>

        {/* Per-entity contribution strip */}
        <div className="overflow-x-auto rounded-lg border border-slate-800">
          <table className="min-w-full text-left text-xs">
            <thead className="border-b border-slate-800 bg-slate-950 text-slate-400">
              <tr>
                <th className="px-3.5 py-2.5 font-semibold">Entity</th>
                <th className="px-3.5 py-2.5 font-semibold text-right">Own debits</th>
                <th className="px-3.5 py-2.5 font-semibold text-right">Own credits</th>
                <th className="px-3.5 py-2.5 font-semibold">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {entityTotals.map(({ member: m, dr, cr }) => (
                <tr key={m.clientId}>
                  <td className="px-3.5 py-2.5 text-slate-200 font-medium">{m.clientCode} · {m.clientName}</td>
                  <td className="px-3.5 py-2.5 font-mono text-slate-300 text-right">{formatGHS(dr)}</td>
                  <td className="px-3.5 py-2.5 font-mono text-slate-300 text-right">{formatGHS(cr)}</td>
                  <td className="px-3.5 py-2.5"><span className={`rounded px-2 py-0.5 text-[11px] font-bold ${Math.abs(dr - cr) < 0.01 ? 'bg-emerald-500/20 text-emerald-300' : 'bg-rose-500/20 text-rose-300'}`}>{Math.abs(dr - cr) < 0.01 ? 'Balanced' : 'Out of balance'}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Consolidated trial balance */}
        <div className="overflow-x-auto rounded-lg border border-slate-800">
          <table className="min-w-full text-left text-xs">
            <thead className="border-b border-slate-800 bg-slate-950 text-slate-400">
              <tr>
                <th className="px-3.5 py-2.5 font-semibold">Account</th>
                <th className="px-3.5 py-2.5 font-semibold">Name</th>
                <th className="px-3.5 py-2.5 font-semibold">Type</th>
                <th className="px-3.5 py-2.5 font-semibold text-right">Consolidated Dr</th>
                <th className="px-3.5 py-2.5 font-semibold text-right">Consolidated Cr</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {consolidated.map((r) => (
                <tr key={r.code} className="hover:bg-slate-800/50">
                  <td className="px-3.5 py-2.5 font-mono font-bold text-amber-300">{r.code}</td>
                  <td className="px-3.5 py-2.5 text-slate-200">{r.name}</td>
                  <td className="px-3.5 py-2.5 text-slate-400">{r.type}</td>
                  <td className="px-3.5 py-2.5 font-mono text-slate-300 text-right">{formatGHS(r.dr / 100)}</td>
                  <td className="px-3.5 py-2.5 font-mono text-slate-300 text-right">{formatGHS(r.cr / 100)}</td>
                </tr>
              ))}
              <tr className="bg-slate-950 font-bold">
                <td colSpan={3} className="px-3.5 py-2.5 text-slate-200">Totals</td>
                <td className="px-3.5 py-2.5 font-mono text-white text-right">{formatGHS(consDr)}</td>
                <td className="px-3.5 py-2.5 font-mono text-white text-right">{formatGHS(consCr)}</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Member Modal */}
      {showAddMemberModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
          <form
            onSubmit={handleAddMember}
            className="w-full max-w-lg rounded-xl border border-slate-700 bg-slate-900 p-6 shadow-2xl space-y-4"
          >
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-white">Add Entity to Group Scope</h3>
              <button
                type="button"
                onClick={() => setShowAddMemberModal(false)}
                className="text-slate-400 hover:text-white text-lg font-bold"
              >
                &times;
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Entity Code</label>
                <input
                  type="text"
                  value={newCode}
                  onChange={(e) => setNewCode(e.target.value)}
                  className="w-full rounded border border-slate-700 bg-slate-800 px-3 py-1.5 text-slate-100 outline-none"
                  required
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Company Legal Name</label>
                <input
                  type="text"
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  className="w-full rounded border border-slate-700 bg-slate-800 px-3 py-1.5 text-slate-100 outline-none"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Ownership %</label>
                  <input
                    type="number"
                    min="1"
                    max="100"
                    value={newOwnership}
                    onChange={(e) => {
                      const val = Number(e.target.value);
                      setNewOwnership(val);
                      setNewMethod(val >= 50 ? 'Full Consolidation (IFRS 10)' : 'Equity Method (IAS 28)');
                    }}
                    className="w-full rounded border border-slate-700 bg-slate-800 px-3 py-1.5 text-slate-100 outline-none"
                    required
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Consolidation Method</label>
                  <select
                    value={newMethod}
                    onChange={(e) => setNewMethod(e.target.value as any)}
                    className="w-full rounded border border-slate-700 bg-slate-800 px-2 py-1.5 text-slate-100 outline-none"
                  >
                    <option value="Full Consolidation (IFRS 10)">Full Consolidation (IFRS 10)</option>
                    <option value="Equity Method (IAS 28)">Equity Method (IAS 28)</option>
                  </select>
                </div>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-3 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setShowAddMemberModal(false)}
                className="rounded px-4 py-2 text-xs font-semibold text-slate-400 hover:bg-slate-800"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="rounded bg-amber-400 px-4 py-2 text-xs font-bold text-slate-950 hover:bg-amber-300"
              >
                Add Entity
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
