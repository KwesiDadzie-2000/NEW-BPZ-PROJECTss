import assert from 'node:assert/strict';
import test from 'node:test';
import { INITIAL_ACDOCA_LINES, INITIAL_CHART_OF_ACCOUNTS, INITIAL_PURCHASE_ORDERS } from '../src/data/accountingSeed';
import { computeEmployeeMonthlyPayroll, currentPayeBands } from '../src/utils/payrollCalculator';
import { computeOutputLevies, DEFAULT_GH_TAX_SETTINGS, taxConfigStore } from '../src/utils/taxConfig';
import { buildPrepaymentSchedule, summarizePrepayment, validateSchedule } from '../src/utils/prepayments';
import { INITIAL_PREPAYMENTS, INITIAL_PREPAYMENT_SCHEDULES } from '../src/data/accountingSeed';
import { calculateSupplierSettlement, isBalancedDocument } from '../src/utils/transactionMath';

const memory = new Map<string, string>();
Object.defineProperty(globalThis, 'localStorage', { configurable: true, value: { getItem: (k: string) => memory.get(k) ?? null, setItem: (k: string, v: string) => memory.set(k, v), removeItem: (k: string) => memory.delete(k) } });

test('every seeded journal document balances in cents', () => {
  const grouped = new Map<string, typeof INITIAL_ACDOCA_LINES>();
  for (const line of INITIAL_ACDOCA_LINES) grouped.set(line.docNo, [...(grouped.get(line.docNo) || []), line]);
  for (const [doc, lines] of grouped) assert.equal(isBalancedDocument(lines), true, `${doc} must balance`);
});

test('all seeded purchase orders map to a configured GL and a cost centre', () => {
  const ledger = new Set(INITIAL_CHART_OF_ACCOUNTS.map(a => a.accountNo));
  for (const po of INITIAL_PURCHASE_ORDERS) {
    assert.equal(ledger.has(po.glAccount), true, `${po.poNo} must have a valid GL`);
    assert.ok(po.costCenter.length > 0, `${po.poNo} requires a cost centre`);
    assert.ok(po.itemType === 'material' || po.itemType === 'service');
  }
});

test('2026 Ghana VAT stack and sector levies calculate from tax configuration', () => {
  taxConfigStore.reset();
  const normal = computeOutputLevies(100, { cst: false, tourism: false }, '2026-10-15');
  assert.deepEqual(normal, { vat: 15, nhil: 2.5, getfund: 2.5, cst: 0, tourism: 0, total: 20 });
  // VAT Act 2025 (Act 1151) s.15.3: CST (5) cascades into the VAT/NHIL/GETFund base,
  // so on a GHS 100 telecom bill: VAT 15.75 + NHIL 2.63 + GETFund 2.63 + CST 5 = 26.01.
  const telecom = computeOutputLevies(100, { cst: true, tourism: false }, '2026-10-15');
  assert.deepEqual(telecom, { vat: 15.75, nhil: 2.63, getfund: 2.63, cst: 5, tourism: 0, total: 26.01 });
  // Tourism levy (1%, hospitality) does not cascade into the VAT base.
  const hotel = computeOutputLevies(100, { cst: false, tourism: true }, '2026-10-15');
  assert.deepEqual(hotel, { vat: 15, nhil: 2.5, getfund: 2.5, cst: 0, tourism: 1, total: 21 });
});

test('WHT and VAT withholding partial settlement posts a balanced AP clear-down', () => {
  const settlement = calculateSupplierSettlement({ invoiceGross: 120, invoiceTaxableValue: 100, alreadyPaid: 40, paymentGross: 30, incomeWhtRate: 3, vatWithholdingRate: 7 });
  assert.deepEqual(settlement, { outstanding: 80, taxablePaymentBase: 25, incomeWht: 0.75, vatWithheld: 1.75, cash: 27.5, resultingPaid: 70, resultingOutstanding: 50 });
  assert.equal(isBalancedDocument([{ debit: 30, credit: 0 }, { debit: 0, credit: 0.75 }, { debit: 0, credit: 1.75 }, { debit: 0, credit: 27.5 }]), true);
});

test('SSNIT statutory 18.5% split: 5.5% employee deduction, 13% employer cost, Tier 2 5% funded inside', () => {
  const employee = { id: 1, bpNo: 'E1', name: 'Test', role: 'Staff', department: 'Ops', jurisdiction: 'GH', basicSalary: 10000, allowances: 0, ssnitNumber: '', tin: '', status: 'active' as const, isResident: true, exemptTier1: false, exemptTier2: false };
  const normal = computeEmployeeMonthlyPayroll({ employee, period: '2026-10' });
  // 18.5% of basic (10,000): employee 5.5% + employer 13%.
  assert.equal(normal.ssnitInsurableBase, 10000);
  assert.equal(normal.ssnitTier1Employee, 550);
  assert.equal(normal.ssnitEmployerCost, 1300);
  // The Tier 2 5% is mandatory but funded inside the combined 18.5% remittance —
  // it is allocated to the trustee, never deducted additionally from the worker.
  assert.equal(normal.ssnitTier2Employee, 0);
  assert.equal(normal.ssnitTier2Allocation, 500);
  assert.equal(normal.ssnitTier1Allocation, 1350);
  assert.equal(normal.nhiaRemittance, 250);
  assert.equal(normal.ssnitTier1Allocation + normal.ssnitTier2Allocation, normal.ssnitTier1Employee + normal.ssnitEmployerCost);

  const exempt = computeEmployeeMonthlyPayroll({ employee: { ...employee, exemptTier1: true, exemptTier2: true }, period: '2026-10' });
  assert.equal(exempt.ssnitTier1Employee, 0);
  assert.equal(exempt.ssnitEmployerCost, 0);
  assert.equal(exempt.ssnitTier2Allocation, 0);
  assert.equal(exempt.netSalary > normal.netSalary, true);
});

test('SSNIT insurable band clamps low and high basic salaries to the 2026 statutory limits', () => {
  const mk = (basicSalary: number) => ({ id: 1, bpNo: 'E1', name: 'Test', role: 'Staff', department: 'Ops', jurisdiction: 'GH', basicSalary, allowances: 0, ssnitNumber: '', tin: '', status: 'active' as const, isResident: true });
  const low = computeEmployeeMonthlyPayroll({ employee: mk(300), period: '2026-10' });
  assert.equal(low.ssnitInsurableBase, 587.8);
  assert.equal(low.ssnitTier1Employee, 32.33);
  const high = computeEmployeeMonthlyPayroll({ employee: mk(100000), period: '2026-10' });
  assert.equal(high.ssnitInsurableBase, 69000);
  assert.equal(high.ssnitEmployerCost, 8970);
  assert.equal(high.ssnitTier2Allocation, 3450);
});

test('full SSNIT exemption in a monthly payroll run removes employee and employer SSNIT', () => {
  const employee = { id: 1, bpNo: 'E1', name: 'Test', role: 'Staff', department: 'Ops', jurisdiction: 'GH', basicSalary: 10000, allowances: 0, ssnitNumber: '', tin: '', status: 'active' as const, isResident: true, exemptTier1: false, exemptTier2: false, ssnitExempt: false };
  const exempt = computeEmployeeMonthlyPayroll({ employee, period: '2026-10', ssnitExempt: true, ssnitExemptionReason: 'Approved exemption' });
  assert.equal(exempt.ssnitExempt, true);
  assert.equal(exempt.ssnitTier1Employee, 0);
  assert.equal(exempt.ssnitTier2Employee, 0);
  assert.equal(exempt.ssnitEmployerCost, 0);
});

test('owner tax configuration selects the PAYE band set effective for the payroll period', () => {
  taxConfigStore.save({
    ...DEFAULT_GH_TAX_SETTINGS,
    payeBands: [
      { id: 'future-1', name: 'Future first band', from: 0, to: 1000, rate: 0, effectiveFrom: '2027-01-01', isActive: true },
      { id: 'future-2', name: 'Future excess', from: 1000, to: null, rate: 10, effectiveFrom: '2027-01-01', isActive: true },
    ],
  });
  assert.equal(currentPayeBands('2026-12-31')[0].upper, 588);
  assert.equal(currentPayeBands('2027-01-01')[0].upper, 1000);
  taxConfigStore.reset();
});

test('prepayment straight-line schedule reconciles to the total and tracks due balances', () => {
  const schedule = buildPrepaymentSchedule({
    prepaymentId: 'PRE-TEST', clientId: 2, totalAmount: 100, benefitStart: '2026-01-15', termMonths: 3, method: 'straight_line',
  });
  assert.deepEqual(schedule.map(l => l.amount), [33.33, 33.33, 33.34]);
  assert.equal(schedule[2].closingBalance, 0);
  const record = {
    id: 'PRE-TEST', clientId: 2, code: 'PRE-TEST', title: 'Test', category: 'Insurance' as const, vendorName: 'Vendor', reference: 'REF',
    paymentDate: '2026-01-15', benefitStart: '2026-01-15', benefitEnd: '2026-04-14', termMonths: 3, totalAmount: 100,
    prepaidAccountNo: '116000', prepaidAccountName: 'Prepayments', expenseAccountNo: '630000', expenseAccountName: 'Insurance',
    costCenter: 'CC-OPS', method: 'straight_line' as const, source: 'bank' as const, status: 'active' as const, createdBy: 'owner', createdAt: '2026-01-15T00:00:00.000Z',
  };
  assert.equal(validateSchedule(record, schedule), null);
  const summary = summarizePrepayment(record, schedule, '2026-02');
  assert.equal(summary.dueAmount, 66.66);
  assert.equal(summary.unrecognized, 100);
});

test('daily pro-rata prepayment schedule allocates by benefit days and still reconciles', () => {
  const schedule = buildPrepaymentSchedule({
    prepaymentId: 'PRE-DAILY', clientId: 2, totalAmount: 310, benefitStart: '2026-01-16', termMonths: 2, method: 'daily_prorata',
  });
  assert.equal(Math.round(schedule.reduce((n, l) => n + l.amount, 0) * 100) / 100, 310);
  assert.equal(schedule[1].closingBalance, 0);
  assert.ok(schedule[0].amount < schedule[1].amount);
});

test('seeded prepayment schedules reconcile to their records and posted journals', () => {
  for (const record of INITIAL_PREPAYMENTS) {
    const schedule = INITIAL_PREPAYMENT_SCHEDULES.filter(s => s.prepaymentId === record.id);
    assert.equal(validateSchedule(record, schedule), null, `${record.code} schedule must reconcile`);
    assert.ok(schedule.some(s => s.status === 'posted'), `${record.code} should have posted opening recognition`);
  }
});
